# ACORD corrected legal-clause retrieval retest

Run: `acord-aggregate-20261027T130905Z` · Protocol: `judged-top50-v1`

This report is rebuilt from complete per-query files after independent numerical validation. Final complete status additionally requires the execution-evidence and delivery audit in validation-report.json.

57 queries, 3,931 clauses, 61,988 explicit qrels; 28 configurations and 1,596 formal quality rows. Each configuration gives equal weight to its 57 queries.

## All 28 configurations

| Configuration | nDCG@5 | nDCG@10 | Top-1 | 4★ normalized P@5 | 5★ normalized P@5 (n) | Candidate Recall@50 | Total mean / p50 / p95 ms | Weights GiB |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| f2llm-v2-0.6b__qwen-reranker-4b | 0.686 | 0.729 | 73.68% | 51.87% | 44.77% (29) | 91.64% | 7298.96 / 7231.74 / 10517.96 | 4.581 |
| bge-m3__qwen-reranker-4b | 0.683 | 0.728 | 73.68% | 50.47% | 38.45% (29) | 85.30% | 8763.93 / 8537.30 / 11466.45 | 4.577 |
| qwen-0.6b__qwen-reranker-4b | 0.686 | 0.728 | 73.68% | 51.52% | 41.32% (29) | 90.80% | 6549.83 / 6379.19 / 9196.25 | 4.581 |
| qwen-4b__qwen-reranker-4b | 0.683 | 0.728 | 73.68% | 51.08% | 37.87% (29) | 95.26% | 7204.17 / 7198.69 / 9603.41 | 7.972 |
| qwen-8b__qwen-reranker-4b | 0.685 | 0.726 | 73.68% | 51.08% | 37.87% (29) | 93.73% | 7111.71 / 7127.46 / 9813.55 | 11.480 |
| granite-97m-r2__qwen-reranker-4b | 0.682 | 0.713 | 73.68% | 50.23% | 46.49% (29) | 74.05% | 7112.69 / 7373.97 / 8928.74 | 4.093 |
| qwen-4b__standalone | 0.672 | 0.703 | 68.42% | 50.12% | 38.28% (29) | 95.26% | 45.53 / 43.64 / 61.80 | 3.986 |
| embeddinggemma-2__qwen-reranker-4b | 0.660 | 0.698 | 73.68% | 48.89% | 35.29% (29) | 78.64% | 6246.02 / 6037.51 / 8445.10 | 4.274 |
| qwen-0.6b__qwen-reranker-0.6b | 0.650 | 0.685 | 66.67% | 47.34% | 33.28% (29) | 90.80% | 1240.02 / 1213.09 / 1703.29 | 1.191 |
| qwen-0.6b__bge-reranker | 0.644 | 0.685 | 70.18% | 48.19% | 23.33% (29) | 90.80% | 1019.74 / 1005.99 / 1395.52 | 1.187 |
| qwen-8b__qwen-reranker-0.6b | 0.643 | 0.685 | 66.67% | 45.50% | 33.28% (29) | 93.73% | 1362.00 / 1362.17 / 1818.54 | 8.090 |
| f2llm-v2-0.6b__qwen-reranker-0.6b | 0.649 | 0.684 | 66.67% | 47.25% | 33.28% (29) | 91.64% | 1359.05 / 1339.17 / 1890.23 | 1.191 |
| qwen-4b__qwen-reranker-0.6b | 0.652 | 0.684 | 66.67% | 47.60% | 33.28% (29) | 95.26% | 1365.17 / 1355.81 / 1791.82 | 4.581 |
| bge-m3__qwen-reranker-0.6b | 0.652 | 0.682 | 66.67% | 47.69% | 35.57% (29) | 85.30% | 1595.29 / 1543.15 / 2077.24 | 1.186 |
| f2llm-v2-0.6b__bge-reranker | 0.643 | 0.681 | 70.18% | 48.51% | 26.78% (29) | 91.64% | 1127.32 / 1076.82 / 1652.57 | 1.188 |
| qwen-8b__bge-reranker | 0.642 | 0.679 | 70.18% | 48.27% | 23.33% (29) | 93.73% | 1130.01 / 1121.56 / 1517.33 | 8.086 |
| granite-97m-r2__qwen-reranker-0.6b | 0.655 | 0.678 | 66.67% | 47.34% | 36.72% (29) | 74.05% | 1321.68 / 1343.84 / 1630.25 | 0.702 |
| qwen-4b__bge-reranker | 0.649 | 0.675 | 70.18% | 49.68% | 23.33% (29) | 95.26% | 1134.95 / 1153.29 / 1480.34 | 4.578 |
| qwen-8b__standalone | 0.632 | 0.662 | 70.18% | 42.11% | 36.09% (29) | 93.73% | 54.56 / 53.82 / 57.61 | 7.494 |
| embeddinggemma-2__qwen-reranker-0.6b | 0.632 | 0.661 | 66.67% | 44.71% | 32.41% (29) | 78.64% | 1190.10 / 1143.25 / 1545.81 | 0.884 |
| granite-97m-r2__bge-reranker | 0.651 | 0.658 | 73.68% | 49.30% | 33.10% (29) | 74.05% | 1092.18 / 1101.39 / 1365.53 | 0.699 |
| bge-m3__bge-reranker | 0.634 | 0.652 | 68.42% | 47.49% | 23.33% (29) | 85.30% | 1345.49 / 1318.16 / 1823.90 | 1.183 |
| embeddinggemma-2__bge-reranker | 0.631 | 0.647 | 68.42% | 48.16% | 24.48% (29) | 78.64% | 969.87 / 926.10 / 1271.16 | 0.881 |
| f2llm-v2-0.6b__standalone | 0.626 | 0.646 | 71.93% | 42.87% | 35.57% (29) | 91.64% | 19.98 / 18.82 / 23.20 | 0.596 |
| qwen-0.6b__standalone | 0.595 | 0.623 | 64.91% | 40.64% | 15.98% (29) | 90.80% | 19.53 / 18.32 / 22.79 | 0.595 |
| bge-m3__standalone | 0.568 | 0.572 | 61.40% | 38.25% | 16.44% (29) | 85.30% | 14.48 / 13.88 / 20.24 | 0.591 |
| embeddinggemma-2__standalone | 0.521 | 0.532 | 56.14% | 34.91% | 22.18% (29) | 78.64% | 14.35 / 13.08 / 21.76 | 0.289 |
| granite-97m-r2__standalone | 0.501 | 0.517 | 57.89% | 30.61% | 24.08% (29) | 74.05% | 7.24 / 7.00 / 9.21 | 0.107 |

Main observations: The highest observed nDCG@10 is f2llm-v2-0.6b__qwen-reranker-4b (0.729). Small differences between nearby configurations do not establish a stable winner. Reranking does not always help: inspect the paired changes below. Five-star metrics have only 29 evaluable queries and do not measure legal-answer accuracy.

Weight capacity sums model file sizes; it is not measured RAM. Reliable peak memory is unavailable and remains null. See summary.json and query-results.jsonl for full precision, other metrics, stage timings and valid counts.

## Paired changes after reranking

| Configuration | Δ nDCG@10 | Wins / losses / ties | Δ 4★ normalized P@5 | Δ 5★ normalized P@5 |
|---|---:|---:|---:|---:|
| qwen-4b__bge-reranker | -0.028 | 25 / 31 / 1 | -0.44% | -14.94% |
| qwen-4b__qwen-reranker-0.6b | -0.019 | 22 / 35 / 0 | -2.51% | -5.00% |
| qwen-4b__qwen-reranker-4b | 0.025 | 35 / 22 / 0 | 0.96% | -0.40% |
| qwen-8b__bge-reranker | 0.017 | 29 / 27 / 1 | 6.17% | -12.76% |
| qwen-8b__qwen-reranker-0.6b | 0.023 | 31 / 25 / 1 | 3.39% | -2.82% |
| qwen-8b__qwen-reranker-4b | 0.065 | 38 / 19 / 0 | 8.98% | 1.78% |
| embeddinggemma-2__bge-reranker | 0.116 | 43 / 14 / 0 | 13.25% | 2.30% |
| embeddinggemma-2__qwen-reranker-0.6b | 0.129 | 45 / 12 / 0 | 9.80% | 10.23% |
| embeddinggemma-2__qwen-reranker-4b | 0.166 | 49 / 7 / 1 | 13.98% | 13.10% |
| qwen-0.6b__bge-reranker | 0.062 | 38 / 19 / 0 | 7.54% | 7.36% |
| qwen-0.6b__qwen-reranker-0.6b | 0.062 | 34 / 23 / 0 | 6.70% | 17.30% |
| qwen-0.6b__qwen-reranker-4b | 0.105 | 47 / 10 / 0 | 10.88% | 25.34% |
| bge-m3__bge-reranker | 0.080 | 43 / 14 / 0 | 9.24% | 6.90% |
| bge-m3__qwen-reranker-0.6b | 0.110 | 49 / 8 / 0 | 9.44% | 19.14% |
| bge-m3__qwen-reranker-4b | 0.156 | 49 / 8 / 0 | 12.22% | 22.01% |
| f2llm-v2-0.6b__bge-reranker | 0.035 | 37 / 20 / 0 | 5.64% | -8.79% |
| f2llm-v2-0.6b__qwen-reranker-0.6b | 0.038 | 34 / 23 / 0 | 4.39% | -2.30% |
| f2llm-v2-0.6b__qwen-reranker-4b | 0.083 | 43 / 14 / 0 | 9.01% | 9.20% |
| granite-97m-r2__bge-reranker | 0.141 | 47 / 10 / 0 | 18.68% | 9.02% |
| granite-97m-r2__qwen-reranker-0.6b | 0.161 | 47 / 9 / 1 | 16.73% | 12.64% |
| granite-97m-r2__qwen-reranker-4b | 0.196 | 52 / 5 / 0 | 19.62% | 22.41% |

Percentage differences represent percentage points; the baseline is the same embedder used standalone.

## Candidate limits and ordering within candidates

| Embedder | Candidate Recall@50 | Candidate oracle nDCG@10 | 1 − oracle | Oracle − BGE | Oracle − Qwen 0.6B | Oracle − Qwen 4B |
|---|---:|---:|---:|---:|---:|---:|
| qwen-4b | 95.26% | 0.983 | 0.017 | 0.308 | 0.299 | 0.255 |
| qwen-8b | 93.73% | 0.979 | 0.021 | 0.300 | 0.294 | 0.253 |
| embeddinggemma-2 | 78.64% | 0.902 | 0.098 | 0.255 | 0.242 | 0.205 |
| qwen-0.6b | 90.80% | 0.969 | 0.031 | 0.284 | 0.284 | 0.241 |
| bge-m3 | 85.30% | 0.947 | 0.053 | 0.294 | 0.265 | 0.218 |
| f2llm-v2-0.6b | 91.64% | 0.972 | 0.028 | 0.292 | 0.288 | 0.243 |
| granite-97m-r2 | 74.05% | 0.897 | 0.103 | 0.239 | 0.219 | 0.184 |

The oracle is a post-hoc diagnostic: it ideally orders the fixed candidate set by grade while IDCG still uses full qrels. 1−oracle measures the candidate-limited gap; oracle−observed measures the remaining ordering gap. Grades are never sent to models or used to select candidates.

## Requested paired comparison

Left: `qwen-4b__qwen-reranker-0.6b` · Right: `bge-m3__qwen-reranker-0.6b`

| Metric | Mean left − right | Valid n | Wins / losses / ties |
|---|---:|---:|---:|
| ndcg@5 | -0.000 | 57 | 6 / 6 / 45 |
| ndcg@10 | 0.002 | 57 | 13 / 13 / 31 |
| top1 | 0.000 | 57 | 0 / 0 / 57 |
| mrr@10 | 0.000 | 57 | 0 / 0 / 57 |
| hit@10 | 0.000 | 57 | 0 / 0 / 57 |
| recall@10 | -0.002 | 57 | 6 / 7 / 44 |
| candidate_recall@50 | 0.100 | 57 | 30 / 2 / 25 |
| normalized_p5_grade_ge_2 | -0.004 | 57 | 2 / 4 / 51 |
| normalized_p5_grade_ge_3 | -0.001 | 57 | 2 / 3 / 52 |
| normalized_p5_grade_ge_4 | -0.023 | 29 | 1 / 1 / 27 |

These embedders may supply different candidates, so their difference cannot be attributed solely to the shared reranker. Complete per-query deltas and outcomes are in analysis.json; this article adds no real query examples.

### Official category/type strata (descriptive only)

| Field | Label | n | Δ nDCG@10 | Wins / losses / ties |
|---|---|---:|---:|---:|
| category | Affirmative Covenants | 3 | n < 5 | — |
| category | Governing Law | 2 | n < 5 | — |
| category | IP Ownership/License | 3 | n < 5 | — |
| category | Indemnification | 14 | -0.004 | 1 / 2 / 11 |
| category | Limitation of Liability | 28 | -0.006 | 7 / 9 / 12 |
| category | Liquidated Damages | 1 | n < 5 | — |
| category | Restrictive Covenants | 4 | n < 5 | — |
| category | Term | 1 | n < 5 | — |
| category | third party beneficiary clause | 1 | n < 5 | — |
| type | cuad1 | 15 | 0.023 | 5 / 2 / 8 |
| type | cuad2 | 42 | -0.005 | 8 / 11 / 23 |

Strata with fewer than five queries show counts only. Larger strata remain exploratory descriptions, not stable advantage claims. Only official labels are used; no legal-domain, difficulty or multi-hop labels are invented.

## Protocol and limitations

- Candidate filtering uses knowledge of which pairs have judgments; unknown pairs are removed and explicit grade=0 pairs remain. This is unavailable in ordinary RAG. Judged coverage is necessarily 100% under this protocol, not evidence of improvement.
- nDCG uses linear grade and full-qrels IDCG; binary relevance means grade>=2. Normalized P@5 divides by min(5, full-qrels qualifying count), not a fixed five. Five-star results have 29 evaluable queries; zero denominators remain null and are excluded from means.
- Each configuration times all 57 queries with actual query embedding, full retrieval, evaluation filtering and the selected reranker. Total sums four stages; wall_total separately uses a monotonic clock. Loopback HTTP transport is included in inference stages. Model loading, corpus preparation and warmup are recorded separately. HTTP transport and server queue time cannot be reliably separated and remain included in inference stages; standalone queue timing is null. Quantiles use type7 linear interpolation.
- Verified corpus/query caches may support regression-checked quality preparation; cache reads cannot replace fresh inference timing. Consult source and run manifests.
- These 57 queries may share source dependencies; 28×57 is not 1,596 independent samples. Reliable grouping has not been established, so no bootstrap or confidence intervals are reported. There is no multiple-comparison correction and no significance claim.
- This experiment uses the frozen test subset, Q8_0 GGUF models, seven specified embedders, three specified rerankers and judged Top50. Paper models, splits and pipelines differ (its two-stage example uses BM25 Top100); this is not a replication of the official leaderboard.
- ACORD remains a separate legal task, outside homepage five- or six-task averages. No website publication is performed.
- The launcher and ten models match historical SHA pins; current dynamic-library hashes are additionally frozen. Historical manifests lack all library hashes, so historical byte identity of every library is not claimed.

Data: ACORD, CC BY 4.0, revision `7ba1c6f2e0baaa32e78c78c2b02e9c57b102af4e`. Derived changes concern candidate selection and evaluation; source texts and labels are preserved.

[ACORD paper, C.5 and F.1](https://aclanthology.org/2025.acl-long.1206.pdf) · [Dataset](https://huggingface.co/datasets/theatticusproject/acord)
