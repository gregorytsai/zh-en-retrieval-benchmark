# ACORD judged-top50-v1 修正重測

最後更新：2026-10-27。七個正式批次皆已完成，每批均通過 batch completion、獨立數值驗證及 execution audit。正式結果已離線聚合並重新驗證；品質分析見 REPORT_ZH_TW.md / REPORT_EN.md，完整逐題結果與稽核紀錄在私有交付包。

## 研究範圍與結果摘要

- 固定 ACORD test 子集：57 queries、3,931 clauses、61,988 個 graded qrels（grade 0–4）。28 組設定共 1,596 筆正式 query-result 與 timing rows；另有 399 個候選清單與 59,850 個 reranker pair scores。
- 每組每題均重新做 query embedding、完整語料搜尋、qrels membership filter 和指定 reranker。未知文件先移除，明確 grade 0 保留，再取 Top50。這是使用 qrels judged pool 的診斷協定，不是一般 RAG 可取得的候選流程，也不代表其他 corpus 的檢索效果。
- 獨立總驗證：28/28 configurations、1,596/1,596 rows、399/399 retrievals、2,793 fresh HTTP inference requests、缺漏/重複/錯誤/截斷/非有限數/hash mismatch 均為 0。各批來源檔、guard、GPU 與 execution audit 保留原 run ID 與原始 bytes。
- 最高觀測 nDCG@10 為 F2LLM 0.6B + Qwen 4B reranker：0.7291；和其他搭配 4B reranker 的差距很小，不宣稱穩定優勢。Qwen4 standalone 為 0.7027，搭配 Qwen 0.6B reranker 為 0.6841，這個子集上未提升。
- 指定比較 Qwen4 embedder + Qwen 0.6B reranker 對 BGE-M3 embedder + 同 reranker：平均 nDCG@10 差約 +0.0021，逐題勝/負/平 13/13/31；Top1 57 題皆同分。Qwen4 的 Candidate Recall@50 為 95.26%，BGE-M3 為 85.30%。此結果不能把差異單獨歸因於 reranker，因兩者候選集不同。
- Qwen4 + Qwen 0.6B 的每題 total 中位數約 1.356 秒，BGE-M3 + Qwen 0.6B 約 1.543 秒。Qwen4 + Qwen 4B reranker 的中位數約 7.199 秒；品質分數略高，但本輪一次性測量不能代表 production 負載或冷啟動延遲。

結果限制、評分公式與資料來源差異詳見協定和完整報告。歷史 public ZIP 的 full judged-tail 有69筆 query/embedder 排序差異；其中4筆超過診斷 epsilon 門檻。所有差異都在 Top50 以外；因 ZIP 沒有原始 cosine scores，不能確認其來源，也不把超門檻差異淡化為已知微小誤差。ACORD 為獨立法律專項，不併入其他研究的首頁 macro。此測試沒有新增 query 範例，不是論文方法的完整複製，也沒有 production 壓測或固定30題×3次延遲重測。

## 批次來源與歷史狀態

正式來源 run 位於私有研究封存中的下列相對路徑；公開包只保留核准的結果、來源 artifacts 和必要程式，不含完整執行 logs、模型權重或向量快取。

| 批次 | Embedder | 正式 run 相對路徑 | 結果 |
|---|---|---|---|
| A01 | qwen-4b | runs-v3/A01/segment-01 | 228 rows；4/4 summaries；audit passed |
| A02 | qwen-8b | runs-v3-continuation-20261027-1932/A02/segment-01 | 228 rows；4/4 summaries；audit passed |
| A03 | embeddinggemma-2 | runs-v3-continuation-v2-20261027-2002/A03/segment-01 | 228 rows；4/4 summaries；audit passed |
| A04 | qwen-0.6b | runs-v3-continuation-v2-20261027-2002/A04/segment-01 | 228 rows；4/4 summaries；audit passed |
| A05 | bge-m3 | runs-v3-continuation-v2-20261027-2002/A05/segment-01 | 228 rows；4/4 summaries；audit passed |
| A06 | f2llm-v2-0.6b | runs-v3-continuation-v2-20261027-2002/A06/segment-01 | 228 rows；4/4 summaries；audit passed |
| A07 | granite-97m-r2 | runs-v3-continuation-v2-20261027-2002/A07/segment-01 | 228 rows；4/4 summaries；audit passed |

歷史上有失敗的準備/執行 attempts 及已恢復的 controller schema 問題；它們保留在 failure ledger，與最終 accepted errors=0 分開統計。實際提交的 query rows 只有七個通過稽核的 official runs；pilot、failed attempts 和 cache regression 不混入品質或正式 timing。

## 本機離線驗證

本套件驗證環境為 Python 3.12.14 與 NumPy 2.3.5（見 `requirements-lock.txt`）。測試含 scorer 與 mock runner，需 NumPy；獨立驗證器 `independent_validate` 本身只依賴 Python 標準函式庫。套件不會自動安裝或升級相依套件。

在交付套件根目錄執行：

    python -m unittest discover -s tests -v
    python -m src.independent_validate .

本套件中的測試只覆蓋公開、可重現的 scorer、validator、分析、guard 邊界及 mock execution。需要 ACORD 原始來源檔、Phase 2 外部資料、accepted corpus vectors、私有 run logs 或模型權重的 integration test 不放進公開測試清單；因此這裡不會以 skip 測試冒充完整測試通過。

## 計時與執行邊界

每題依序量測 query embedding、full retrieval、evaluation filter、rerank，另保存 total 與 monotonic wall total。Loopback HTTP transport 在 embedding/rerank 階段之內；無法分離的 transport/queue 另記 null，而不是零。模型載入、索引和 warmup 個別記錄且不計入熱查詢時間。每批使用雙 owned servers 但不並行 inference，受到每秒外部 traffic guard、30 秒 quiet window、全域 lock 和固定 deadline 保護；任何受干擾測量單位作廢重跑並保留 attempt。

測試在單一本機硬體配置以 Q8_0 GGUF 執行。結果是這個候選池、prompt、runtime 和硬體下的一次量測，不代表跨硬體或 production 的吞吐與延遲。launcher 與十個模型符合既有 SHA pins；本輪另外留存 runtime library hash。舊 manifest 沒有所有 library 的歷史 hash，因此不宣稱逐一歷史 byte identity 已核實。

## 重現入口與封存

原始測量來源程式是凍結的 private execution snapshot。實驗使用 sequential controller v2（`src/sequence_controller_v2.py`），不是早期 controller。若在相容的私有 workspace 重跑，可先產生不啟模型的 plan：

    python -m src.sequence_controller_v2 --workspace "$GGUF_ROOT" --phase2-root "$PHASE2_ROOT" --output-root "$OUTPUT_ROOT" --preflight-evidence "$PREFLIGHT_ROOT" --wall-hours 12

只有具備原模型、preflight evidence、資料/cache、guard 權限和全域 benchmark lock 的凍結私有 workspace 才可在該命令尾端明確加上 `--execute`。公開套件不含這些私有執行條件，不能直接發起 inference。此公開套件排除早期 controller 與依賴本機測量路徑的 continuation scripts；公開測試僅驗證 portable controller 的批次順序函式，不依賴私有 raw runs。

聚合與報告是離線工作，無須啟動模型。私有 aggregate 保存原始 source runs 的 manifest 和必要 artifacts byte-exact 副本；public package 為經驗證的 text-only allowlist view，源 manifests 以 sanitized views 呈現並分別計算 SHA。公開 run manifest 另記 post-run analyzer 與 execution-audit tool 的 SHA，與正式 inference source pins 分開。私有 privacy scanner、package builder、包含合成私密字串的測試、完整 traffic/server logs、模型權重與 vectors 均不進公開套件。明確 allowlist 與 scanner audit sidecar 存在包外；建置工具不會上傳內容。

資料：ACORD，CC BY 4.0，revision 7ba1c6f2e0baaa32e78c78c2b02e9c57b102af4e。來源文字和標籤保留；衍生內容改變的是候選選取與評分協定。


## Public package boundary

This sanitized package contains validated aggregate outputs and source artifacts. The exact `runs-v3` raw execution directories, guard/server logs and private package-builder tooling are kept in the private evidence archive. Commands that aggregate raw batch directories apply to that full private archive, not this sanitized public subset. The included independent validator and analysis code can be run on this package.
