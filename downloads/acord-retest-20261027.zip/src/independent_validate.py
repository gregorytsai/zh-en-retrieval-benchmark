#!/usr/bin/env python3
"""Independent ACORD validator. Standard library only; never imports the runner/scorer.

Recomputes candidates, metrics, timing aggregates and paired-input invariants from
saved primitive ranks/scores/qrels. This does not itself attest that inference
happened: frozen execution evidence is also required for final acceptance.
"""
from __future__ import annotations

import argparse
import collections
import dataclasses
import hashlib
import json
import math
import statistics
from pathlib import Path

PROTOCOL = 'judged-top50-v1'
EMBEDDERS = ('qwen-4b', 'qwen-8b', 'embeddinggemma-2', 'qwen-0.6b',
             'bge-m3', 'f2llm-v2-0.6b', 'granite-97m-r2')
RERANKERS = ('standalone', 'bge-reranker', 'qwen-reranker-0.6b', 'qwen-reranker-4b')
STAGES = ('query_embedding', 'retrieval', 'evaluation_filter', 'rerank', 'total', 'wall_total')


class Invalid(ValueError):
    def __init__(self, code, message):
        self.code = code
        super().__init__(message)


def need(test, message, code='error'):
    if not test:
        raise Invalid(code, message)


def finite(value):
    return type(value) in (int, float) and math.isfinite(value)


def canonical_hash(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
        separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def file_hash(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def unique_object(pairs):
    obj = {}
    for k, v in pairs:
        need(k not in obj, f'duplicate JSON property {k}', 'duplicate')
        obj[k] = v
    return obj


def decode(text):
    return json.loads(text, object_pairs_hook=unique_object,
                      parse_constant=lambda v: (_ for _ in ()).throw(Invalid('nonfinite', v)))


def read(path):
    need(Path(path).is_file(), f'missing {Path(path).name}', 'missing')
    return decode(Path(path).read_text(encoding='utf-8'))


def lines(path):
    need(Path(path).is_file(), f'missing {Path(path).name}', 'missing')
    import gzip
    opener = gzip.open if str(path).endswith('.gz') else open
    with opener(path, 'rt', encoding='utf-8') as f:
        for line_no, line in enumerate(f, 1):
            need(bool(line.strip()), f'blank record {Path(path).name}:{line_no}')
            yield decode(line)


def index(records, fields, label):
    result = {}
    for row in records:
        need(all(k in row for k in fields), f'{label} missing key', 'missing')
        key = tuple(row[k] for k in fields)
        need(key not in result, f'{label} duplicate {key}', 'duplicate')
        result[key] = row
    return result


def close(actual, expected, label, tol=1e-10):
    if expected is None:
        need(actual is None, f'{label}: expected null')
    else:
        need(finite(actual), f'{label}: not finite', 'nonfinite')
        need(math.isclose(actual, expected, rel_tol=tol, abs_tol=tol),
             f'{label}: {actual!r} != independently computed {expected!r}')


def quantile(values, fraction):
    """Hyndman-Fan type 7 (NumPy method='linear'), implemented independently."""
    xs = sorted(values)
    need(bool(xs), 'empty quantile')
    p = (len(xs) - 1) * fraction
    lo = math.floor(p)
    hi = math.ceil(p)
    return xs[lo] + (xs[hi] - xs[lo]) * (p - lo)


def recompute(order, judgments, candidates):
    """Primitive independent metric implementation, with explicit unknown rejection."""
    need(bool(order), 'empty final ranking', 'missing')
    need(len(order) == len(set(order)), 'duplicate final ID', 'duplicate')
    need(all(d in judgments for d in order), 'unjudged final ID')
    need(len(candidates) == len(set(candidates)), 'duplicate candidate ID', 'duplicate')
    need(all(d in judgments for d in candidates), 'unjudged candidate ID')
    need(all(type(g) is int and 0 <= g <= 4 for g in judgments.values()), 'invalid grade')
    relevant = {d for d, g in judgments.items() if g >= 2}
    hits = [r for r, d in enumerate(order[:10], 1) if d in relevant]
    ideal = sorted(judgments.values(), reverse=True)
    out = {}
    for cutoff in (5, 10):
        denominator = math.fsum(g / math.log2(r + 1) for r, g in enumerate(ideal[:cutoff], 1))
        numerator = math.fsum(judgments[d] / math.log2(r + 1) for r, d in enumerate(order[:cutoff], 1))
        out[f'ndcg@{cutoff}'] = numerator / denominator if denominator else None
    out.update({'top1': float(order[0] in relevant), 'mrr@10': 1.0 / hits[0] if hits else 0.0,
                'hit@10': float(bool(hits)),
                'recall@10': len(set(order[:10]) & relevant) / len(relevant) if relevant else None,
                'candidate_recall@50': len(set(candidates) & relevant) / len(relevant) if relevant else None})
    for threshold in (2, 3, 4):
        available = sum(g >= threshold for g in judgments.values())
        out[f'normalized_p5_grade_ge_{threshold}'] = (
            sum(judgments[d] >= threshold for d in order[:5]) / min(5, available) if available else None)
    return out


@dataclasses.dataclass(frozen=True)
class Scope:
    embedders: tuple = EMBEDDERS
    rerankers: tuple = RERANKERS
    registry_embedders: tuple | None = None
    queries: int = 57
    corpus: int = 3931
    judgments: int = 61988
    candidates: int = 50
    judged_range: tuple = (421, 1342)
    five_star_queries: int = 29


def verify_data(data, scope):
    corpus = index(data['corpus'], ('id',), 'corpus')
    queries = index(data['queries'], ('id',), 'queries')
    need(len(corpus) == scope.corpus and len(queries) == scope.queries, 'dataset counts differ', 'missing')
    need(all(isinstance(k[0], str) and k[0] for k in corpus.keys() | queries.keys()), 'IDs must be nonempty strings')
    need(all(isinstance(r.get('text'), str) and r['text'].strip() for r in list(corpus.values()) + list(queries.values())), 'empty text')
    qrels = data['qrels']
    need(set(qrels) == {q[0] for q in queries}, 'qrels query IDs differ', 'missing')
    need(sum(len(j) for j in qrels.values()) == scope.judgments, 'qrels count differs', 'missing')
    doc_ids = {d[0] for d in corpus}
    for q, j in qrels.items():
        need(isinstance(j, dict) and set(j) <= doc_ids, f'{q}: unknown qrel document', 'missing')
        need(all(type(v) is int and 0 <= v <= 4 for v in j.values()), f'{q}: grade outside integer0..4')
        need(len(j) >= scope.candidates, f'{q}: cannot build complete candidate pool', 'missing')
    observed_range = (min(map(len, qrels.values())), max(map(len, qrels.values())))
    need(observed_range == scope.judged_range, 'judged range differs')
    need(sum(any(v == 4 for v in j.values()) for j in qrels.values()) == scope.five_star_queries, 'five-star evaluable count differs')
    return doc_ids, {q[0] for q in queries}, qrels


def source_origins(root, manifest):
    """Authenticate unchanged source rows when several bounded runs are merged.

    This verifies file provenance, not GPU execution; execution audits stay separate.
    Each original run_id remains on results and its matching timing/request traces.
    """
    sources = manifest.get('source_runs')
    if sources is None:
        return None
    need(isinstance(sources, dict) and bool(sources), 'aggregate source_runs is empty', 'missing')
    root = root.resolve()
    origins = {}
    required = ('query-results.jsonl', 'timing-results.jsonl', 'request-trace.jsonl',
                'retrieval-attempts.jsonl', 'full-retrieval-rankings.jsonl')
    # Operational code and evaluation inputs must match across source runs.
    compatible = ('frozen-data/acord.json', 'models-manifest.json', 'src/scoring.py',
                  'src/runtime.py', 'src/owned_guard.py', 'src/runner.py')
    target_pins = manifest['frozen_files_sha256']
    def pinned(path, digest):
        f = (root / path).resolve()
        need(f.is_relative_to(root), 'source artifact path escapes aggregate')
        need(f.is_file(), 'source artifact missing', 'missing')
        need(file_hash(f) == digest, 'source artifact hash mismatch', 'hash_mismatch')
        return f
    for source_id, spec in sources.items():
        need(isinstance(source_id, str) and bool(source_id), 'invalid source run_id')
        src = read(pinned(spec['manifest_path'], spec['manifest_sha256']))
        need(src.get('run_id') == source_id and src.get('protocol_id') == PROTOCOL, 'source run/protocol mismatch')
        for name in compatible:
            need(name in target_pins and src.get('frozen_files_sha256', {}).get(name) == target_pins[name],
                 f'source frozen condition mismatch: {name}', 'hash_mismatch')
        artifacts = spec.get('artifacts', {})
        need(set(required) <= set(artifacts), 'source execution artifacts missing', 'missing')
        for name in required:
            artifact = artifacts[name]
            hashes = set()
            for row in lines(pinned(artifact['path'], artifact['sha256'])):
                need(row.get('run_id') == source_id, 'source artifact contains foreign run_id')
                h = canonical_hash(row)
                need(h not in hashes, 'duplicate source artifact record', 'duplicate')
                hashes.add(h)
            origins[(source_id, name)] = hashes
    return origins


def validate(root, scope=Scope()):
    """Raises Invalid at the first defect; no partial output is called complete."""
    root = Path(root)
    data = read(root / 'frozen-data/acord.json')
    doc_ids, query_ids, qrels = verify_data(data, scope)
    manifest = read(root / 'run-manifest.json')
    run_id = manifest.get('run_id')
    need(isinstance(run_id, str) and bool(run_id), 'missing run_id', 'missing')
    need(manifest.get('protocol_id') == PROTOCOL, 'manifest protocol mismatch')
    frozen = manifest.get('frozen_files_sha256', {})
    need(bool(frozen), 'manifest lacks frozen file hashes', 'missing')
    need('frozen-data/acord.json' in frozen, 'dataset not pinned in run manifest', 'missing')
    for name, digest in frozen.items():
        path = (root / name).resolve()
        need(path.is_relative_to(root.resolve()), 'frozen path escapes package')
        need(path.is_file(), f'frozen file missing: {name}', 'missing')
        need(file_hash(path) == digest, f'frozen hash mismatch: {name}', 'hash_mismatch')
    need('models-manifest.json' in frozen, 'model manifest not pinned', 'missing')
    origins = source_origins(root, manifest)
    allowed_run_ids = set(manifest['source_runs']) if origins is not None else {run_id}
    def origin(row, filename):
        need(row.get('run_id') in allowed_run_ids, f'{filename}: unknown source run_id')
        if origins is not None:
            need(canonical_hash(row) in origins[(row['run_id'], filename)],
                 f'{filename}: row differs from original source artifact', 'hash_mismatch')
    models = read(root / 'models-manifest.json')['models']
    need(set(models) == set(scope.registry_embedders or scope.embedders) | (set(scope.rerankers) - {'standalone'}), 'model registry coverage differs', 'missing')
    for name, model in models.items():
        need(isinstance(model.get('sha256'), str) and len(model['sha256']) == 64 and
             all(c in '0123456789abcdef' for c in model['sha256']), f'{name}: invalid model SHA', 'hash_mismatch')
    traces = index(lines(root / 'request-trace.jsonl'), ('id',), 'request trace')
    used_traces = set()
    queries_by_id = {q['id']: q for q in data['queries']}
    corpus_by_id = {d['id']: d for d in data['corpus']}
    candidates = index(lines(root / 'candidates.jsonl'), ('embedder', 'query_id'), 'candidate')
    expected_pairs = {(e, q) for e in scope.embedders for q in query_ids}
    need(set(candidates) == expected_pairs, 'candidate coverage differs', 'missing')
    rank_path = root / 'full-retrieval-rankings.jsonl'
    if not rank_path.exists():
        rank_path = root / 'full-retrieval-rankings.jsonl.gz'
    if not rank_path.exists():
        rank_path = root / 'retrieval-rankings.jsonl'
    ranks = {}
    primary_rank_hashes = {}
    for row in lines(rank_path):
        key = (row['embedder'], row['query_id'])
        need(key in expected_pairs, 'unexpected full-ranking key')
        need(key not in ranks, 'duplicate full ranking', 'duplicate')
        origin(row, 'full-retrieval-rankings.jsonl')
        rank = row['ranking']
        ids = [x['doc_id'] for x in rank]
        need(len(ids) == scope.corpus and set(ids) == doc_ids, 'full ranking doc coverage/duplicate', 'missing')
        need(len(set(ids)) == len(ids), 'duplicate full ranking doc', 'duplicate')
        need([x['rank'] for x in rank] == list(range(1, scope.corpus + 1)), 'rank positions wrong')
        need(all(finite(x['similarity']) for x in rank), 'nonfinite similarity', 'nonfinite')
        need(rank == sorted(rank, key=lambda x: (-x['similarity'], x['doc_id'])), 'similarity/doc_id ordering wrong')
        need(row.get('ranking_sha256') == canonical_hash(rank), 'full ranking hash mismatch', 'hash_mismatch')
        judgments = qrels[key[1]]
        need(all(type(x.get('judged')) is bool and x['judged'] == (x['doc_id'] in judgments) for x in rank), 'judged flags wrong')
        judged = [x for x in rank if x['doc_id'] in judgments]
        expected_ids = [x['doc_id'] for x in judged[:scope.candidates]]
        c = candidates[key]
        need(c.get('source_ranking_sha256') == row['ranking_sha256'], 'candidate source ranking hash differs', 'hash_mismatch')
        need(c.get('similarity_sha256') == canonical_hash([x['similarity'] for x in judged[:scope.candidates]]), 'candidate similarity hash differs', 'hash_mismatch')
        need(c.get('candidate_ids') == expected_ids, 'candidate must filter unknown BEFORE top50')
        need(c.get('original_ranks') == [x['rank'] for x in judged[:scope.candidates]], 'candidate original ranks wrong')
        need(c.get('ordered_candidate_sha256') == canonical_hash(expected_ids), 'candidate hash mismatch', 'hash_mismatch')
        need(c.get('filter_protocol') == 'judged-qrels-membership-v1', 'filter protocol wrong')
        need(not any(k in c for k in ('grade', 'grades', 'labels', 'reference_answer')), 'candidate payload includes labels')
        ranks[key] = [x['doc_id'] for x in judged]
        primary_rank_hashes[key] = row['ranking_sha256']
    need(set(ranks) == expected_pairs, 'full ranking coverage differs', 'missing')

    expected_configs = {(e, r) for e in scope.embedders for r in scope.rerankers}
    expected_rows = {(f'{e}__{r}', q) for e, r in expected_configs for q in query_ids}
    scores = collections.defaultdict(dict)
    score_count = 0
    for row in lines(root / 'reranker-scores.jsonl'):
        e, r, q = row['embedder'], row['reranker'], row['query_id']
        key = (row['config_id'], q)
        need((e, r) in expected_configs and r != 'standalone' and q in query_ids, 'unknown score key')
        need(row['config_id'] == f'{e}__{r}', 'score config mismatch')
        c = candidates[e, q]
        i = row['candidate_index']
        need(type(i) is int and 0 <= i < scope.candidates, 'candidate_index must be zero-based')
        need(row['doc_id'] == c['candidate_ids'][i], 'score index/document mismatch')
        need(row['doc_id'] not in scores[key], 'duplicate pair score', 'duplicate')
        need(finite(row['score']), 'nonfinite rerank score', 'nonfinite')
        need(row.get('finite') is True, 'finite flag false')
        need(row.get('ordered_candidate_sha256') == c['ordered_candidate_sha256'], 'score pool hash mismatch', 'hash_mismatch')
        need(row.get('model_sha256') == models[r]['sha256'], 'score model hash differs from pin', 'hash_mismatch')
        scores[key][row['doc_id']] = row['score']
        score_count += 1
    expected_score_count = len(expected_pairs) * (len(scope.rerankers) - 1) * scope.candidates
    need(score_count == expected_score_count, 'pair score count differs', 'missing')
    timing = index(lines(root / 'timing-results.jsonl'), ('config_id', 'query_id'), 'timing')
    results = index(lines(root / 'query-results.jsonl'), ('config_id', 'query_id'), 'result')
    retrievals = index(lines(root / 'retrieval-attempts.jsonl'), ('config_id', 'query_id'), 'fresh retrieval')
    need(set(results) == expected_rows and set(timing) == expected_rows, 'formal query/timing coverage differs', 'missing')
    need(set(retrievals) == expected_rows, 'fresh retrieval coverage differs', 'missing')
    corpus_pins = manifest.get('corpus_cache_sha256', {})
    need(set(corpus_pins) == set(scope.embedders), 'corpus cache hashes incomplete', 'missing')
    independently_computed = collections.defaultdict(list)
    timings = collections.defaultdict(list)
    for key, row in results.items():
        e, r, q = row['embedder'], row['reranker'], row['query_id']
        need((e, r) in expected_configs and row['config_id'] == f'{e}__{r}', 'result config mismatch')
        origin(row, 'query-results.jsonl')
        row_run_id = row['run_id']
        need(row.get('protocol_id') == PROTOCOL, 'result protocol mismatch')
        need(row.get('status') == 'ok', 'non-ok formal result')
        need(row.get('truncated', False) is False, 'truncated formal input', 'truncation')
        c = candidates[e, q]
        need(row.get('candidate_sha256') == c['ordered_candidate_sha256'], 'result candidate mismatch', 'hash_mismatch')
        order = row['final_doc_ids']
        need(len(order) == len(set(order)), 'duplicate final doc', 'duplicate')
        if r == 'standalone':
            expected_order = ranks[e, q]
        else:
            s = scores[key]
            need(set(s) == set(c['candidate_ids']), 'reranker did not score every candidate', 'missing')
            expected_order = sorted(s, key=lambda d: (-s[d], d))
        need(order == expected_order, 'final rank differs from full judged/score order')
        computed = recompute(order, qrels[q], c['candidate_ids'])
        need(set(computed) <= row['metrics'].keys(), 'missing per-query metrics', 'missing')
        for metric, value in computed.items():
            close(row['metrics'][metric], value, f'{key}/{metric}')
        independently_computed[row['config_id']].append(computed)
        t = timing[key]
        need(t.get('warmup') is False and t.get('repeat_id') == 0 and t.get('source') == 'fresh_inference', 'formal timing is not new measured query')
        if 'run_id' in t or origins is not None:
            origin(t, 'timing-results.jsonl')
            need(t['run_id'] == row_run_id, 'timing run_id mismatch')
        values = row['times_ms']
        need(all(s in values and finite(values[s]) and values[s] >= 0 for s in STAGES), 'invalid timing duration', 'nonfinite')
        need(values['query_embedding'] > 0 and values['retrieval'] > 0 and values['evaluation_filter'] > 0, 'query timing stage absent')
        need(values['rerank'] == 0 if r == 'standalone' else values['rerank'] > 0, 'rerank timing inconsistent')
        close(values['total'], sum(values[s] for s in STAGES[:4]), 'stage total', 1e-8)
        need(values['wall_total'] + 1e-5 >= values['total'], 'wall total shorter than measured stage sum')
        start_ns, end_ns = t.get('monotonic_start_ns'), t.get('monotonic_end_ns')
        need(type(start_ns) is int and type(end_ns) is int and end_ns > start_ns >= 0, 'invalid monotonic request interval')
        close(values['wall_total'], (end_ns - start_ns) / 1e6, 'wall/monotonic duration', 1e-6)
        need('times_ms' in t, 'timing row lacks durations', 'missing')
        for stage in STAGES:
            close(t['times_ms'].get(stage), values[stage], f'timing/result {stage}')
        p = row.get('provenance', {})
        need(p.get('query_embedding') == 'fresh_inference', 'query embedding provenance not fresh')
        need(p.get('rerank') == ('not_applicable' if r == 'standalone' else 'fresh_inference'), 'rerank provenance not fresh')
        retrieval = retrievals[key]
        origin(retrieval, 'retrieval-attempts.jsonl')
        need(retrieval.get('run_id') == row_run_id and retrieval.get('embedder') == e, 'fresh retrieval run/model mismatch')
        need(retrieval.get('embedding_request_id') == p.get('embedding_request_id'), 'retrieval not linked to fresh query request')
        need(retrieval.get('corpus_documents') == scope.corpus, 'retrieval did not search whole corpus')
        need(retrieval.get('corpus_cache_sha256') == corpus_pins[e], 'retrieval corpus hash mismatch', 'hash_mismatch')
        need(retrieval.get('ordered_candidate_sha256') == c['ordered_candidate_sha256'], 'fresh retrieval candidate hash differs', 'hash_mismatch')
        if retrieval.get('full_ranking_sha256') != primary_rank_hashes[e, q]:
            fresh_rank = retrieval.get('ranking')
            need(isinstance(fresh_rank, list), 'changed fresh full ranking lacks primitive rank evidence', 'missing')
            need(len(fresh_rank) == scope.corpus and {x['doc_id'] for x in fresh_rank} == doc_ids,
                 'fresh retrieval doc coverage differs', 'missing')
            need(all(finite(x['similarity']) for x in fresh_rank), 'fresh nonfinite similarity', 'nonfinite')
            need(fresh_rank == sorted(fresh_rank, key=lambda x: (-x['similarity'], x['doc_id'])), 'fresh score/tie order wrong')
            need([x['rank'] for x in fresh_rank] == list(range(1, scope.corpus + 1)), 'fresh rank indices wrong')
            need(all(type(x.get('judged')) is bool and x['judged'] == (x['doc_id'] in qrels[q]) for x in fresh_rank), 'fresh judged flags wrong')
            need(canonical_hash(fresh_rank) == retrieval['full_ranking_sha256'], 'fresh rank hash wrong', 'hash_mismatch')
            fresh_judged = [x['doc_id'] for x in fresh_rank if x['doc_id'] in qrels[q]]
            need(fresh_judged[:scope.candidates] == c['candidate_ids'], 'fresh search candidate changed')
            if r == 'standalone':
                need(order == fresh_judged, 'standalone result differs from its fresh search')
        reg = models[e].get('registry', {})
        prefix = reg.get('query_prefix') or reg.get('prompt', '')
        embed_body = {'input': [prefix + queries_by_id[q]['text']], 'encoding_format': 'float'}
        requests = [('query_embedding', p.get('embedding_request_id'), e, embed_body, canonical_hash([q]))]
        if r != 'standalone':
            rerank_body = {'query': queries_by_id[q]['text'],
                           'documents': [corpus_by_id[d]['text'] for d in c['candidate_ids']], 'top_n': scope.candidates}
            requests.append(('rerank', p.get('rerank_request_id'), r, rerank_body, c['ordered_candidate_sha256']))
        else:
            need(p.get('rerank_request_id') is None, 'standalone claims rerank request')
        previous_finish = start_ns
        for kind, request_id, model, body, ids_hash in requests:
            need(isinstance(request_id, str) and (request_id,) in traces, 'missing fresh request trace', 'missing')
            need(request_id not in used_traces, 'inference trace reused across formal queries/configs', 'duplicate')
            used_traces.add(request_id)
            trace = traces[request_id,]
            origin(trace, 'request-trace.jsonl')
            need(trace.get('run_id') == row_run_id and trace.get('config_id') == key[0] and trace.get('query_id') == q,
                 'request trace belongs to another query/config/run')
            need(trace.get('kind') == kind and trace.get('model_id') == model, 'request kind/model mismatch')
            need(trace.get('model_sha256') == models[model]['sha256'], 'request model SHA mismatch', 'hash_mismatch')
            need(trace.get('input_sha256') == canonical_hash(body), 'request body is not frozen unlabelled text/prefix', 'hash_mismatch')
            need(trace.get('input_ids_sha256') == ids_hash, 'request input order hash differs', 'hash_mismatch')
            if kind == 'query_embedding':
                vh = retrieval.get('query_vector_sha256')
                need(isinstance(vh, str) and len(vh) == 64 and all(x in '0123456789abcdef' for x in vh), 'fresh query vector hash invalid', 'hash_mismatch')
                need(trace.get('output_vector_sha256') == vh, 'search vector not linked to embedding output', 'hash_mismatch')
            need(set(trace.get('payload_field_names', [])) == set(body) and trace.get('grade_fields_absent') is True,
                 'request payload fields not approved')
            need(trace.get('status') == 'ok' and trace.get('http_status') == 200, 'failed request counted as formal')
            a, b = trace.get('started_ns'), trace.get('finished_ns')
            need(type(a) is int and type(b) is int and previous_finish <= a < b <= end_ns,
                 'request trace outside wall interval or inference stages overlap')
            need((b - a) / 1e6 <= values[kind] + 1e-5, 'HTTP request takes longer than reported stage')
            previous_finish = b
            need(isinstance(trace.get('attempt_id'), str) and bool(trace['attempt_id']), 'request attempt missing', 'missing')
            if p.get('attempt_id') is not None:
                need(trace['attempt_id'] == p['attempt_id'], 'request/result attempt mismatch')
        timings[row['config_id']].append(values)
    summaries = index(read(root / 'summary.json'), ('config_id',), 'summary')
    need(set(summaries) == {(c,) for c, _q in expected_rows}, 'summary config coverage differs', 'missing')
    for (config,), row in summaries.items():
        need(row['n'] == scope.queries and row['failed'] == 0, 'summary sample/error count wrong')
        cr = independently_computed[config]
        for metric in cr[0]:
            vals = [v[metric] for v in cr if v[metric] is not None]
            saved = row['metrics'][metric]
            need(saved['valid_n'] == len(vals), f'{config}/{metric} valid_n wrong')
            close(saved['mean'], statistics.mean(vals) if vals else None, f'{config}/{metric} mean')
        for stage in STAGES:
            vals = [v[stage] for v in timings[config]]
            saved = row['times_ms'][stage]
            need(saved['n'] == len(vals), f'{stage} timing n wrong')
            for statistic, expected in (('mean', statistics.mean(vals)), ('p50', quantile(vals, .5)), ('p95', quantile(vals, .95))):
                close(saved[statistic], expected, f'{config}/{stage}/{statistic}')
    return {'status': 'passed', 'protocol_id': PROTOCOL, 'run_id': run_id,
            'source_run_ids': sorted(allowed_run_ids),
            'counts': {'configurations': len(summaries), 'quality_rows': len(results),
                'standalone_rows': len(expected_pairs), 'reranker_rows': len(results) - len(expected_pairs),
                'candidate_lists': len(candidates), 'pair_scores': score_count, 'full_rankings': len(ranks),
                'verified_fresh_inference_requests': len(used_traces),
                'verified_fresh_retrievals': len(retrievals),
                'missing': 0, 'duplicate': 0, 'error': 0, 'truncation': 0, 'nonfinite': 0, 'hash_mismatch': 0},
            'independent_metrics': True, 'quantile_algorithm': 'Hyndman-Fan type 7 / linear',
            'execution_attestation': 'Required separately: frozen model/code/config hashes, source/cache regression, smoke/token/GPU/guard evidence, accepted commit pointers and inference request traces.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root', type=Path)
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    try:
        report = validate(args.root)
        code = 0
    except (Invalid, KeyError, TypeError, ValueError, OSError) as exc:
        category = getattr(exc, 'code', 'error')
        report = {'status': 'incomplete', 'first_failure': str(exc), 'failure_category': category,
                  'counts': {k: (1 if k == category else None) for k in
                    ('missing', 'duplicate', 'error', 'truncation', 'nonfinite', 'hash_mismatch')},
                  'note': 'Stopped at first defect; null counts have not been fully checked.'}
        code = 1
    payload = json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + '\n'
    if args.report:
        args.report.write_text(payload, encoding='utf-8')
    print(payload)
    return code


if __name__ == '__main__':
    raise SystemExit(main())
