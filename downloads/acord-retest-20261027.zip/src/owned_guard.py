"""Fail-closed external traffic guard for this retest's exact owned server set.

Unlike the historical single-server guard, this implementation excludes only
the explicit child PIDs owned by this run. Any other llama-server process stays
visible to the external metrics/router snapshot, even if it shares our parent.
"""
from __future__ import annotations

import concurrent.futures
import json
import os
import re
import shlex
import subprocess
import threading
import time
import urllib.request
from pathlib import Path
from typing import Any, Callable


class Interference(RuntimeError):
    pass


class DeadlineExceeded(TimeoutError):
    pass


def parse_metrics(text: str) -> dict[str, float]:
    values: dict[str, float] = {}
    for line in text.splitlines():
        if not line.startswith("llamacpp:") or "{" in line:
            continue
        fields = line.split()
        if len(fields) < 2:
            continue
        try:
            value = float(fields[1])
        except ValueError as exc:
            raise ValueError(f"invalid llama metric {fields[0]}") from exc
        if not (value >= 0.0 and value < float("inf")):
            raise ValueError(f"non-finite or negative llama metric {fields[0]}")
        values[fields[0].split(":", 1)[1]] = value
    required = {
        "requests_processing", "requests_deferred", "n_decode_total",
        "prompt_tokens_total", "tokens_predicted_total",
    }
    if not required <= values.keys():
        raise ValueError(f"required llama metrics missing: {sorted(required - values.keys())}")
    return values


def fetch(url: str, *, json_body: bool = True, timeout: float = 1.5) -> Any:
    with urllib.request.urlopen(url, timeout=timeout) as response:
        body = response.read().decode("utf-8")
    return json.loads(body) if json_body else body


def discover(owned_pids: set[int]) -> tuple[dict[int, int], dict[int, int]]:
    """Find all other local llama-server processes; exclude only exact owned PIDs."""
    output = subprocess.run(
        ["/bin/ps", "-axo", "pid=,ppid=,command="], check=True,
        capture_output=True, text=True, timeout=3,
    ).stdout
    workers: dict[int, int] = {}
    routers: dict[int, int] = {}
    for line in output.splitlines():
        fields = line.strip().split(None, 2)
        if len(fields) != 3:
            continue
        try:
            pid = int(fields[0])
            args = shlex.split(fields[2])
        except (ValueError, shlex.Error):
            continue
        if pid in owned_pids or not args:
            continue
        if Path(args[0]).name != "llama-server":
            continue
        port = int(args[args.index("--port") + 1]) if "--port" in args else 8080
        (routers if "--models-preset" in args or "--models-dir" in args else workers)[pid] = port
    return workers, routers


class OwnedTrafficGuard:
    """Monitor every non-owned server once per second and stop every owned server on interference."""

    def __init__(self, event_path: Path, deadline_epoch: float, idle_seconds: int = 30,
                 period_seconds: float = 1.0, clock: Callable[[], float] = time.monotonic):
        self.event_path = Path(event_path)
        self.deadline_epoch = float(deadline_epoch)
        self.idle_seconds = int(idle_seconds)
        self.period_seconds = float(period_seconds)
        self.clock = clock
        self._lock = threading.RLock()
        self._poll_lock = threading.Lock()
        self._owned: dict[str, Any] = {}
        self._previous: dict[str, Any] | None = None
        self._stop = threading.Event()
        self._reaper_stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._reaper_thread: threading.Thread | None = None
        self._pool = concurrent.futures.ThreadPoolExecutor(max_workers=12)
        self._last_poll = 0.0
        self._last_activity = self.clock()
        self._reason: str | None = "monitor not initialized"
        self._epoch = 0
        self._unit_epoch: int | None = None
        self._unit_id: str | None = None
        self._terminating: dict[int, tuple[Any, float]] = {}
        self._event_lock = threading.Lock()
        self._terminating_lock = threading.Lock()
        self._heartbeat_lock = threading.Lock()
        self._heartbeat = self.clock()
        self._fatal_reason: str | None = None
        self._deadman_thread: threading.Thread | None = None
        self.event_path.parent.mkdir(parents=True, exist_ok=True)

    @property
    def epoch(self) -> int:
        with self._lock:
            return self._epoch

    @property
    def reason(self) -> str | None:
        with self._lock:
            return self._reason

    @property
    def fatal_reason(self) -> str | None:
        with self._lock:
            return self._fatal_reason

    @property
    def owned_pids(self) -> dict[str, int]:
        with self._lock:
            return {
                name: int(server.process.pid)
                for name, server in self._owned.items()
                if (getattr(server, "process", None) is not None and
                    server.process.poll() is None)
            }

    def _write(self, event: str, **fields: Any) -> None:
        row = {"time_epoch": time.time(), "monotonic": self.clock(), "event": event, **fields}
        with self._event_lock:
            with self.event_path.open("a", encoding="utf-8") as stream:
                stream.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n")

    def register(self, name: str, server: Any) -> None:
        """Register before start so its PID is owned before the first metrics poll."""
        with self._lock:
            if name in self._owned and self._owned[name] is not server:
                raise RuntimeError(f"owned server name reused before unbind: {name}")
            self._owned[name] = server
        self._write("owned_server_registered", name=name)

    def unregister(self, name: str, server: Any) -> None:
        with self._lock:
            if self._owned.get(name) is server:
                self._owned.pop(name, None)
        self._write("owned_server_unregistered", name=name,
                    pid=getattr(getattr(server, "process", None), "pid", None))

    def _metrics_snapshot(self, item: tuple[int, int]) -> tuple[int, dict[str, Any]]:
        pid, port = item
        metrics = parse_metrics(fetch(f"http://127.0.0.1:{port}/metrics", json_body=False))
        counters = {key: metrics[key] for key in sorted(metrics) if key.endswith("_total")}
        return pid, {
            "port": port,
            "counters": counters,
            "busy": metrics["requests_processing"] > 0 or metrics["requests_deferred"] > 0,
        }

    def snapshot(self) -> dict[str, Any]:
        pids = set(self.owned_pids.values())
        workers, routers = discover(pids)
        worker_states = dict(self._pool.map(self._metrics_snapshot, workers.items()))
        router_states = {}
        for pid, port in routers.items():
            payload = fetch(f"http://127.0.0.1:{port}/models")
            states = {
                row["id"]: row.get("status", {}).get("value", "unknown")
                for row in payload["data"]
            }
            if any(value not in ("loaded", "unloaded", "sleeping") for value in states.values()):
                raise RuntimeError(f"router model transition or unknown state pid={pid}")
            router_states[pid] = states
        return {"workers": worker_states, "routers": router_states}

    def _terminate_owned(self, reason: str, *, write_events: bool = True) -> None:
        now = self.clock()
        with self._lock:
            servers = list(self._owned.items())
        to_log = []
        for name, server in servers:
            process = getattr(server, "process", None)
            if process is None or process.poll() is not None:
                continue
            pid = int(process.pid)
            with self._terminating_lock:
                if pid in self._terminating:
                    continue
                try:
                    process.terminate()
                    self._terminating[pid] = (process, now)
                except ProcessLookupError:
                    continue
            to_log.append((name, pid))
        # TERM every process before attempting event-log I/O. An independent reaper
        # handles KILL if the log blocks this thread.
        for name, pid in (to_log if write_events else ()):
            try:
                self._write("owned_server_terminated", name=name, pid=pid, reason=reason)
            except Exception:
                pass

    def _escalate_terminated(self, now: float) -> None:
        with self._terminating_lock:
            items = list(self._terminating.items())
        to_log = []
        for pid, (process, started) in items:
            if process.poll() is not None:
                with self._terminating_lock:
                    self._terminating.pop(pid, None)
            elif now - started >= 2.0:
                try:
                    process.kill()
                except ProcessLookupError:
                    pass
                with self._terminating_lock:
                    self._terminating.pop(pid, None)
                to_log.append(pid)
        # KILL all expired TERM requests before any log operation can block.
        for pid in to_log:
            try:
                self._write("owned_server_killed_after_grace", pid=pid)
            except Exception:
                pass

    def _reaper_loop(self) -> None:
        """Independent TERM-to-KILL escalation; it does not use monitor health."""
        while True:
            self._escalate_terminated(self.clock())
            with self._terminating_lock:
                pending = bool(self._terminating)
            with self._lock:
                active = any(getattr(server, "process", None) is not None and
                             server.process.poll() is None for server in self._owned.values())
            if self._reaper_stop.is_set() and not pending and not active:
                return
            time.sleep(0.1)

    def _mark_fatal(self, reason: str) -> None:
        with self._lock:
            self._fatal_reason = self._fatal_reason or reason
            self._reason = self._fatal_reason
            self._epoch += 1
            self._last_activity = self.clock()
        self._terminate_owned(self._fatal_reason)
        try:
            self._write("guard_fatal", reason=self._fatal_reason)
        except Exception:
            pass

    def poll(self) -> None:
        with self._poll_lock:
            now = self.clock()
            with self._heartbeat_lock:
                self._heartbeat = now
            if time.time() >= self.deadline_epoch:
                with self._lock:
                    self._reason = "original wall-clock deadline reached"
                    self._last_poll = now
                self._terminate_owned("deadline")
                self._write("deadline_reached", deadline_epoch=self.deadline_epoch)
                self._escalate_terminated(now)
                return
            failure = None
            snapshot = None
            try:
                snapshot = self.snapshot()
                if any(item["busy"] for item in snapshot["workers"].values()):
                    failure = "external llama-server request processing/deferred"
                elif self._previous is not None and snapshot != self._previous:
                    failure = "external llama-server counters/topology or router state changed"
            except Exception as exc:
                failure = f"monitoring unavailable: {type(exc).__name__}: {exc}"
            with self._lock:
                self._last_poll = now
                if failure:
                    self._last_activity = now
                    self._epoch += 1
                    self._reason = failure
                else:
                    self._reason = None
                self._previous = snapshot
                epoch = self._epoch
            try:
                self._write("snapshot", epoch=epoch, reason=failure, snapshot=snapshot)
            except Exception as exc:
                self._mark_fatal(f"traffic event log unavailable: {type(exc).__name__}: {exc}")
                return
            self._escalate_terminated(now)
            if failure:
                try:
                    self._write("external_activity", epoch=epoch, reason=failure)
                except Exception as exc:
                    self._mark_fatal(f"traffic event log unavailable: {type(exc).__name__}: {exc}")
                    return
                self._terminate_owned(failure)
            with self._heartbeat_lock:
                self._heartbeat = self.clock()

    def _loop(self) -> None:
        while not self._stop.is_set():
            try:
                self.poll()
            except BaseException as exc:
                self._mark_fatal(f"traffic monitor crashed: {type(exc).__name__}: {exc}")
                return
            self._stop.wait(self.period_seconds)

    def _deadman_loop(self) -> None:
        while not self._stop.wait(min(0.25, self.period_seconds)):
            if not self._deadman_check():
                return

    def _deadman_check(self) -> bool:
        with self._heartbeat_lock:
            heartbeat = self._heartbeat
        if self._thread is None or not self._thread.is_alive():
            self._mark_fatal("traffic monitor thread stopped unexpectedly")
            return False
        if self.clock() - heartbeat > max(3.0, self.period_seconds * 3.0):
            self._mark_fatal("traffic monitor heartbeat stale; owned servers stopped")
            return False
        return True

    def start(self) -> None:
        if self._thread is not None:
            raise RuntimeError("guard started more than once")
        self._write("guard_started", idle_seconds=self.idle_seconds, period_seconds=self.period_seconds,
                    deadline_epoch=self.deadline_epoch)
        self._thread = threading.Thread(target=self._loop, name="acord-owned-traffic-guard", daemon=True)
        self._thread.start()
        self._deadman_thread = threading.Thread(
            target=self._deadman_loop, name="acord-owned-traffic-deadman", daemon=True)
        self._deadman_thread.start()
        self._reaper_thread = threading.Thread(
            target=self._reaper_loop, name="acord-owned-process-reaper", daemon=True)
        self._reaper_thread.start()

    def close(self) -> None:
        # A preflight can fail between an HTTP call and its per-model cleanup.
        # Terminate only PIDs explicitly registered by this guard and leave the
        # independent reaper alive until every owned process has exited.
        self._terminate_owned("guard_close", write_events=False)
        stop_deadline = time.monotonic() + 12.0
        while True:
            self._escalate_terminated(self.clock())
            with self._lock:
                active = any(getattr(server, "process", None) is not None and
                             server.process.poll() is None for server in self._owned.values())
            with self._terminating_lock:
                pending = bool(self._terminating)
            if not active and not pending:
                break
            if time.monotonic() >= stop_deadline:
                self._mark_fatal("owned server did not exit during guard close")
                raise RuntimeError("owned server did not exit during guard close")
            time.sleep(0.1)

        with self._lock:
            closed_pids = sorted({int(server.process.pid) for server in self._owned.values()
                                  if getattr(server, "process", None) is not None})
        self._write("guard_owned_servers_stopped", pids=closed_pids)

        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=10)
            if self._thread.is_alive():
                self._mark_fatal("traffic monitor did not stop during close")
                raise RuntimeError("guard monitor thread did not stop")
        if self._deadman_thread is not None:
            self._deadman_thread.join(timeout=10)
            if self._deadman_thread.is_alive():
                self._mark_fatal("guard deadman thread did not stop during close")
                raise RuntimeError("guard deadman thread did not stop")
        self._pool.shutdown(wait=True)
        self._write("guard_closed")
        self._reaper_stop.set()
        if self._reaper_thread is not None:
            self._reaper_thread.join(timeout=10)
            if self._reaper_thread.is_alive():
                raise RuntimeError("owned process reaper did not stop")

    def ready(self) -> bool:
        with self._lock:
            return (self._last_poll > 0 and self._reason is None and
                    self._fatal_reason is None and
                    self.clock() - self._last_poll < 5 and
                    self.clock() - self._last_activity >= self.idle_seconds)

    def wait_idle(self, check_deadline: Callable[[], None], *, status_callback: Callable[..., None] | None = None) -> None:
        announced = False
        while not self.ready():
            check_deadline()
            with self._lock:
                fatal = self._fatal_reason
            if fatal is not None:
                self._terminate_owned(fatal)
                raise Interference(fatal)
            if not announced and status_callback:
                status_callback("waiting_for_traffic_quiet", reason=self.reason,
                                idle_elapsed_s=max(0.0, self.clock() - self._last_activity))
                announced = True
            time.sleep(min(self.period_seconds, 1.0))
        check_deadline()

    def check_deadline(self) -> None:
        """Check only the immutable wall deadline/fatal monitor state.

        Quiet-window waiting must not call check_environment(), because a recent
        nonfatal external event is exactly what wait_idle needs to wait out.
        """
        if time.time() >= self.deadline_epoch:
            self._terminate_owned("deadline")
            raise DeadlineExceeded("original wall-clock deadline reached; it cannot be extended")
        with self._lock:
            fatal = self._fatal_reason
        if fatal is not None:
            self._terminate_owned(fatal)
            raise Interference(fatal)

    def abort_unit(self, unit_id: str, reason: str) -> None:
        """Clear an invalid unit after fail-closed termination to allow quiet wait/retry."""
        with self._lock:
            current = self._unit_id
            if current == unit_id:
                self._unit_id = None
                self._unit_epoch = None
        try:
            self._write("guard_unit_aborted", unit_id=unit_id, reason=reason,
                        traffic_epoch=self.epoch)
        except Exception:
            # The independent deadman/reaper owns stop escalation even if logging fails.
            self._mark_fatal("traffic event log unavailable while recording aborted unit")

    def begin_unit(self, unit_id: str) -> dict[str, Any]:
        self.poll()
        if not self.ready():
            raise Interference("30-second rolling quiet window is not ready")
        snapshot = self._previous
        with self._lock:
            self._unit_epoch = self._epoch
            self._unit_id = unit_id
            epoch = self._epoch
        self._write("guard_unit_started", unit_id=unit_id, traffic_epoch=epoch,
                    quiet_seconds=self.idle_seconds, poll_period_seconds=self.period_seconds,
                    owned_pids=self.owned_pids, snapshot=snapshot)
        return snapshot or {}

    def check(self) -> None:
        if time.time() >= self.deadline_epoch:
            self._terminate_owned("deadline")
            raise DeadlineExceeded("original wall-clock deadline reached; it cannot be extended")
        with self._lock:
            in_unit = self._unit_epoch is not None
            invalid = (self._unit_epoch != self._epoch or self._reason is not None or
                       self._fatal_reason is not None or self.clock() - self._last_poll > 5) if in_unit else False
            failure = self._fatal_reason or self._reason or "external activity occurred during guarded unit"
        if not in_unit:
            self.check_environment()
        elif invalid:
            self._terminate_owned(failure)
            raise Interference(failure)

    def check_environment(self) -> None:
        """Check monitor/deadline outside a measured query unit (preflight/warmup)."""
        if time.time() >= self.deadline_epoch:
            self._terminate_owned("deadline")
            raise DeadlineExceeded("original wall-clock deadline reached; it cannot be extended")
        with self._lock:
            stale = self._last_poll <= 0 or self.clock() - self._last_poll > 5
            reason = self._fatal_reason or self._reason
        if stale or reason is not None:
            failure = reason or "external traffic monitor is stale"
            self._terminate_owned(failure)
            raise Interference(failure)

    def finish_unit(self, unit_id: str) -> dict[str, Any]:
        self.poll()
        self.check()
        with self._lock:
            if self._unit_id != unit_id:
                raise Interference("guarded unit identity changed")
            epoch = self._epoch
            snapshot = self._previous
            self._unit_epoch = None
            self._unit_id = None
        self._write("guard_unit_finished", unit_id=unit_id, traffic_epoch=epoch,
                    owned_pids=self.owned_pids, snapshot=snapshot)
        return snapshot or {}
