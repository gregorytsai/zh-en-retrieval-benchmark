"""Offline cache/source regression for ACORD judged-top50-v1.

This reads previously accepted embedding vectors and public correction evidence. It
does not load a model or produce fresh timing. The retest runner will not treat any
values here as new query/retrieval/reranker timing.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import math
import zipfile
from pathlib import Path
from typing import Any

import numpy as np

from scoring import evaluate_ranking, filter_judged_top50, ranked_entry_hash, stable_full_ranking

EMBEDDERS = (
    "qwen-4b", "qwen-8b", "embeddinggemma-2", "qwen-0.6b",
    "bge-m3", "f2llm-v2-0.6b", "granite-97m-r2",
)
CACHE_RELATIVE = {
    "qwen-4b": "run-full-matrix/B01/official/cache/qwen-4b/acord-eng-eng",
    "qwen-8b": "run-full-matrix-continuation-v3/B02-B/segment-01/official/cache/qwen-8b/acord-eng-eng",
    "embeddinggemma-2": "run-full-matrix-continuation-v4/B03/segment-01/official/cache/embeddinggemma-2/acord-eng-eng",
    "qwen-0.6b": "run-full-matrix-continuation-v4/B04/segment-01/official/cache/qwen-0.6b/acord-eng-eng",
    "bge-m3": "run-full-matrix-continuation-v4/B05/segment-01/official/cache/bge-m3/acord-eng-eng",
    "f2llm-v2-0.6b": "run-full-matrix-continuation-v4/B06/segment-01/official/cache/f2llm-v2-0.6b/acord-eng-eng",
    "granite-97m-r2": "run-full-matrix-continuation-v4/B07/segment-01/official/cache/granite-97m-r2/acord-eng-eng",
}
OFFICIAL_RELATIVE = {
    "qwen-4b": "run-full-matrix/B01/official",
    "qwen-8b": "run-full-matrix-continuation-v3/B02-B/segment-01/official",
    "embeddinggemma-2": "run-full-matrix-continuation-v4/B03/segment-01/official",
    "qwen-0.6b": "run-full-matrix-continuation-v4/B04/segment-01/official",
    "bge-m3": "run-full-matrix-continuation-v4/B05/segment-01/official",
    "f2llm-v2-0.6b": "run-full-matrix-continuation-v4/B06/segment-01/official",
    "granite-97m-r2": "run-full-matrix-continuation-v4/B07/segment-01/official",
}


class RegressionError(ValueError):
    pass


def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def _canonical_sha(value: Any) -> str:
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
    return _sha256_bytes(payload)


def _mean(values: list[float | None]) -> float | None:
    vals = [float(x) for x in values if x is not None]
    return sum(vals) / len(vals) if vals else None


def _close(a: float | None, b: float | None, tol: float = 1e-10) -> bool:
    return a is None and b is None or a is not None and b is not None and abs(a - b) <= tol


def _read_jsonl(path: Path) -> list[dict[str, Any]]:
    return [json.loads(line) for line in path.read_text("utf-8").splitlines() if line.strip()]


def validate_frozen_source(source_root: Path, frozen: dict[str, Any]) -> dict[str, Any]:
    """Compare frozen order/text/qrels against the pinned upstream archive and phase2 mapping."""
    source = json.loads((source_root / "datasets.json").read_text("utf-8"))["datasets"]["acord-eng-eng"]
    with zipfile.ZipFile(source_root / "sources/acord/original.zip") as zf:
        raw_queries = [json.loads(x) for x in zf.read("ACORD Dataset & ReadMe (external)/queries.jsonl").decode("utf-8").splitlines() if x.strip()]
        raw_corpus = [json.loads(x) for x in zf.read("ACORD Dataset & ReadMe (external)/corpus.jsonl").decode("utf-8").splitlines() if x.strip()]
        qrel_tsv = zf.read("ACORD Dataset & ReadMe (external)/qrels/test.tsv").decode("utf-8")
    raw_q = {str(x["_id"]): x for x in raw_queries}
    raw_d = {str(x["_id"]): x for x in raw_corpus}
    if [(x["id"], x["text"]) for x in frozen["corpus"]] != [(x["id"], x["text"]) for x in source["corpus"]]:
        raise RegressionError("frozen corpus order/text differs from phase2 source dataset")
    if [(x["id"], x["text"]) for x in frozen["queries"]] != [(x["id"], x["text"]) for x in source["queries"]]:
        raise RegressionError("frozen query order/text differs from phase2 source dataset")
    if frozen["qrels"] != source["qrels"]:
        raise RegressionError("frozen qrels differ from phase2 source mapping")
    if len(raw_corpus) != 3931 or len(raw_queries) != 114:
        raise RegressionError("upstream ACORD raw corpus/query count mismatch")
    if not all(str(d["id"]) in raw_d and d["text"] == raw_d[str(d["id"])]["text"] for d in frozen["corpus"]):
        raise RegressionError("frozen corpus text differs from upstream corpus.jsonl")
    for q in frozen["queries"]:
        raw = raw_q.get(str(q["id"]))
        if raw is None or q["text"] != raw["text"] or q["metadata"] != raw["metadata"]:
            raise RegressionError(f"frozen query/source metadata mismatch: {q['id']}")
    rows = list(csv.reader(io.StringIO(qrel_tsv), delimiter="\t"))
    header = rows.pop(0)
    if header != ["query-id", "corpus-id", "score"]:
        raise RegressionError("upstream test qrels TSV schema changed")
    raw_qrels: dict[str, dict[str, int]] = {}
    for qid, did, grade in rows:
        raw_qrels.setdefault(qid, {})[did] = int(grade)
    if raw_qrels != frozen["qrels"]:
        raise RegressionError("frozen qrels differ from original upstream test.tsv")
    return {
        "phase2_dataset_canonical_sha256": _canonical_sha(source),
        "phase2_corpus_order_text_equal": True,
        "phase2_query_order_text_equal": True,
        "upstream_corpus_text_equal": True,
        "upstream_query_text_metadata_equal": True,
        "upstream_test_qrels_equal": True,
        "upstream_queries_total": len(raw_queries),
        "upstream_test_queries_selected": len(frozen["queries"]),
        "parent_query_id_nonempty": sum(bool(q["metadata"].get("parent_query_id")) for q in frozen["queries"]),
    }


def validate_accepted_standalone(workspace: Path, embedder: str, query_ids: list[str], computed_top50: dict[str, list[str]]) -> dict[str, Any]:
    official = workspace / OFFICIAL_RELATIVE[embedder]
    commit_path = official / "committed.json"
    main_path = official / "query-results.jsonl"
    if not commit_path.is_file() or not main_path.is_file():
        raise RegressionError(f"{embedder}: accepted official pointers missing")
    commit = json.loads(commit_path.read_text("utf-8"))
    key = f"acord-eng-eng--{embedder}--standalone"
    pointer = commit.get(key)
    if not isinstance(pointer, dict) or pointer.get("queries") != 57:
        raise RegressionError(f"{embedder}: committed standalone pointer missing/invalid")
    attempt_rel = Path(pointer["attempt"])
    attempt = (official / attempt_rel).resolve()
    if not attempt.is_relative_to(official.resolve()) or not attempt.is_dir():
        raise RegressionError(f"{embedder}: committed attempt escapes or is missing")
    validity = json.loads((attempt / "validity.json").read_text("utf-8"))
    if validity.get("status") != "accepted":
        raise RegressionError(f"{embedder}: standalone attempt was not accepted")
    attempt_rows = _read_jsonl(attempt / "query-results.jsonl")
    main_rows = [r for r in _read_jsonl(main_path) if r.get("dataset") == "acord-eng-eng" and r.get("embedding") == embedder and r.get("reranker") == "standalone"]
    for rows, source_label in ((attempt_rows, "attempt"), (main_rows, "official main")):
        by_qid = {str(r["query_id"]): r for r in rows if r.get("dataset") == "acord-eng-eng" and r.get("embedding") == embedder and r.get("reranker") == "standalone"}
        if len(by_qid) != 57 or set(by_qid) != set(query_ids):
            raise RegressionError(f"{embedder}: accepted {source_label} rows do not cover exact 57 query IDs")
        if any(r.get("status") != "ok" or len(r.get("final_ids", [])) != 50 for r in by_qid.values()):
            raise RegressionError(f"{embedder}: accepted {source_label} result status/top50 width mismatch")
        if any(r["final_ids"] != computed_top50[str(r["query_id"])] for r in by_qid.values()):
            raise RegressionError(f"{embedder}: accepted {source_label} Top50 differs from recomputed cache ranking")
    main_by_qid = {str(r["query_id"]): r for r in main_rows}
    attempt_by_qid = {str(r["query_id"]): r for r in attempt_rows if r.get("dataset") == "acord-eng-eng" and r.get("embedding") == embedder and r.get("reranker") == "standalone"}
    if any(main_by_qid[q]["final_ids"] != attempt_by_qid[q]["final_ids"] for q in query_ids):
        raise RegressionError(f"{embedder}: committed result differs from accepted attempt")
    audit_path = official / "batch-completion-audit.json"
    audit = None
    if audit_path.is_file():
        audit = json.loads(audit_path.read_text("utf-8"))
        if audit.get("status") != "passed" or audit.get("errors") != 0:
            raise RegressionError(f"{embedder}: official batch audit not passed")
    elif embedder == "qwen-8b":
        combined_audit = workspace / "run-full-matrix-continuation-v4/B02/combined/batch-completion-audit.json"
        if not combined_audit.is_file():
            raise RegressionError("qwen-8b: split batch combined audit missing")
        audit = json.loads(combined_audit.read_text("utf-8"))
        if audit.get("status") != "passed" or audit.get("errors") != 0:
            raise RegressionError("qwen-8b: split batch combined audit not passed")
    return {
        "official_relative_path": OFFICIAL_RELATIVE[embedder],
        "committed_key": key,
        "attempt_relative_path": str(attempt.relative_to(official.resolve())),
        "attempt_validity": validity,
        "attempt_query_results_sha256": _sha256_file(attempt / "query-results.jsonl"),
        "official_query_results_sha256": _sha256_file(main_path),
        "committed_sha256": _sha256_file(commit_path),
        "batch_audit_status": audit.get("status") if audit else "not-present-for-split-segment",
        "accepted_query_count": 57,
        "official_main_top50_match_count": 57,
        "accepted_attempt_top50_match_count": 57,
    }


def validate_cache_manifest(cache: Path, manifest: dict[str, Any], dataset_sha: str,
                            embedder: str, query_ids: list[str], expected_model_sha: str,
                            expected_settings: dict[str, Any]) -> dict[str, Any]:
    if manifest.get("dataset") != "acord-eng-eng" or manifest.get("embedding") != embedder:
        raise RegressionError(f"{embedder}: dataset/embedder pin mismatch")
    if manifest.get("dataset_sha256") != dataset_sha:
        raise RegressionError(f"{embedder}: dataset canonical hash mismatch")
    if manifest.get("model_sha256") != expected_model_sha:
        raise RegressionError(f"{embedder}: model SHA mismatch")
    if manifest.get("query_ids") != query_ids or len(query_ids) != 57:
        raise RegressionError(f"{embedder}: query ID order mismatch")
    if manifest.get("corpus_documents") != 3931 or manifest.get("candidate_k") != 50:
        raise RegressionError(f"{embedder}: corpus/candidate count mismatch")
    for key, value in expected_settings.items():
        if manifest.get(key) != value:
            raise RegressionError(f"{embedder}: model setting mismatch for {key}")
    files = manifest.get("files_sha256")
    if not isinstance(files, dict) or set(files) != {"corpus.npy", "queries.npy", "candidates.json"}:
        raise RegressionError(f"{embedder}: cache file hash manifest incomplete")
    actual_files = {}
    for name, expected_hash in files.items():
        observed = _sha256_bytes((cache / name).read_bytes())
        actual_files[name] = observed
        if observed != expected_hash:
            raise RegressionError(f"{embedder}: cache file SHA mismatch {name}")
    unsigned = {k: v for k, v in manifest.items() if k not in ("cache_key_sha256", "files_sha256")}
    if manifest.get("cache_key_sha256") != _canonical_sha(unsigned):
        raise RegressionError(f"{embedder}: cache_key_sha256 does not match manifest")
    corpus = np.load(cache / "corpus.npy", allow_pickle=False)
    queries = np.load(cache / "queries.npy", allow_pickle=False)
    dim = manifest.get("dimension")
    if corpus.shape != (3931, dim) or queries.shape != (57, dim):
        raise RegressionError(f"{embedder}: cache vector shape mismatch")
    if not np.isfinite(corpus).all() or not np.isfinite(queries).all():
        raise RegressionError(f"{embedder}: non-finite vectors")
    if np.max(np.abs(np.linalg.norm(corpus, axis=1) - 1.0)) >= 1e-5:
        raise RegressionError(f"{embedder}: corpus vectors not normalized")
    if np.max(np.abs(np.linalg.norm(queries, axis=1) - 1.0)) >= 1e-5:
        raise RegressionError(f"{embedder}: query vectors not normalized")
    return {
        "manifest_sha256": _sha256_bytes((cache / "cache-manifest.json").read_bytes()),
        "manifest_cache_key_sha256": manifest["cache_key_sha256"],
        "files_sha256": actual_files,
        "vector_shapes": {"corpus": list(corpus.shape), "queries": list(queries.shape)},
        "vectors_finite": True,
        "corpus_normalized_max_abs_error": float(np.max(np.abs(np.linalg.norm(corpus, axis=1) - 1.0))),
        "queries_normalized_max_abs_error": float(np.max(np.abs(np.linalg.norm(queries, axis=1) - 1.0))),
        "corpus": corpus,
        "queries": queries,
    }


def run_regression(workspace: Path, package_root: Path, source_root: Path, frozen_data: Path,
                   model_pins: dict[str, str], settings: dict[str, dict[str, Any]]) -> dict[str, Any]:
    source_data = json.loads((source_root / "datasets.json").read_text("utf-8"))["datasets"]["acord-eng-eng"]
    dataset_sha = _canonical_sha(source_data)
    frozen = json.loads(frozen_data.read_text("utf-8"))
    query_ids = [str(q["id"]) for q in frozen["queries"]]
    doc_ids = [str(d["id"]) for d in frozen["corpus"]]
    if len(query_ids) != 57 or len(set(query_ids)) != 57 or len(doc_ids) != 3931 or len(set(doc_ids)) != 3931:
        raise RegressionError("frozen ACORD input identity/count mismatch")
    qrels = frozen["qrels"]
    if len(qrels) != 57 or sum(len(j) for j in qrels.values()) != 61988:
        raise RegressionError("frozen qrels count mismatch")
    source_checks = validate_frozen_source(source_root, frozen)

    correction_root = package_root / "source-reference"
    corrected = json.loads((correction_root / "data/matrix/acord-corrected.json").read_text("utf-8"))
    if (corrected.get("version") != "2026-10-27-correction" or
            corrected.get("verification", {}).get("original_top50_rankings_matched") != 399 or
            corrected.get("verification", {}).get("new_inference") is not False):
        raise RegressionError("pinned public correction summary does not declare expected historical scope")
    with zipfile.ZipFile(correction_root / "acord-corrected-rankings.zip") as zf:
        public_rows = [json.loads(line) for line in zf.read("judged-rankings.jsonl").decode("utf-8").splitlines()]
    if len(public_rows) != 399 or len({(r["embedding"], r["query_id"]) for r in public_rows}) != 399:
        raise RegressionError("public corrected ranking archive must contain 399 unique model/query rows")
    public_map = {(r["embedding"], str(r["query_id"])): r for r in public_rows}
    corrected_map = {r["embedding"]: r for r in corrected["rows"]}
    if set(corrected_map) != set(EMBEDDERS):
        raise RegressionError("public standalone corrected summaries do not cover seven embedders")

    result: dict[str, Any] = {
        "status": "running",
        "protocol_id": "judged-top50-v1",
        "dataset_sha256": dataset_sha,
        "queries": len(query_ids),
        "corpus_docs": len(doc_ids),
        "qrels": sum(len(j) for j in qrels.values()),
        "source_zip_sha256": _sha256_bytes((source_root / "sources/acord/original.zip").read_bytes()),
        "frozen_source_checks": source_checks,
        "public_rankings_zip_sha256": _sha256_bytes((correction_root / "acord-corrected-rankings.zip").read_bytes()),
        "model_regressions": [],
        "accepted_official_standalone": [],
        "original_top50_rankings_matched": 0,
        "public_judged_rankings_exact": 0,
        "public_judged_rankings_order_drift": 0,
        "public_judged_rankings_non_tie_mismatches": 0,
        "public_judged_top50_candidate_lists_matched": 0,
        "public_judged_top50_positions_mismatched": 0,
        "judged_rankings_matched": 0,
        "source_numpy_lexsort_matches_local_scorer": 0,
        "public_tail_drift_diagnostics": {
            "max_absolute_judged_rank_delta": 0,
            "max_mismatched_slot_score_gap": 0.0,
            "max_mismatched_slot_score_gap_example": None,
        },
        "new_inference": False,
        "new_timing": False,
        "limitations": [
            "Uses previously saved query/corpus vectors only for offline historical regression.",
            "Does not substitute for fresh query embedding, full retrieval, filtering, reranker inference, or timing in the authorized retest.",
            "Parent query IDs in the selected ACORD test split are empty; no independent parent-group bootstrap will be claimed."
        ],
    }

    for embedder in EMBEDDERS:
        cache = workspace / CACHE_RELATIVE[embedder]
        manifest = json.loads((cache / "cache-manifest.json").read_text("utf-8"))
        spec = settings[embedder]
        pinned = validate_cache_manifest(cache, manifest, dataset_sha, embedder, query_ids,
                                         model_pins[embedder], spec)
        public_provenance = corrected["provenance"].get(embedder)
        if not isinstance(public_provenance, dict):
            raise RegressionError(f"{embedder}: public cache provenance missing")
        if (public_provenance.get("cache_manifest_sha256") != pinned["manifest_sha256"] or
                public_provenance.get("files_sha256") != pinned["files_sha256"] or
                public_provenance.get("dataset_sha256") != dataset_sha or
                public_provenance.get("model_sha256") != model_pins[embedder] or
                public_provenance.get("dimension") != spec["dimension"] or
                public_provenance.get("query_ids") != query_ids or
                public_provenance.get("original_top50_rankings_matched") != 57):
            raise RegressionError(f"{embedder}: public correction provenance does not match accepted cache")
        corpus = pinned.pop("corpus")
        queries = pinned.pop("queries")
        saved_candidates = json.loads((cache / "candidates.json").read_text("utf-8"))
        saved_by_qid = {str(row["query_id"]): row for row in saved_candidates}
        if list(saved_by_qid) != query_ids or len(saved_candidates) != 57:
            raise RegressionError(f"{embedder}: stored candidate query order mismatch")
        scored_rows: list[dict[str, float | int | None]] = []
        computed_top50_by_qid: dict[str, list[str]] = {}
        per_model = {"embedder": embedder, **pinned, "original_top50_match_count": 0, "judged_ranking_match_count": 0}
        for i, query_id in enumerate(query_ids):
            scores = np.asarray(corpus @ queries[i], dtype=np.float32)
            full = stable_full_ranking(doc_ids, scores)
            # Re-run the exact public reference operation from the pinned script
            # (corpus @ query, np.lexsort((docs, -scores))) in this installed NumPy
            # runtime. This establishes local scorer/source parity without asserting
            # that the public archive was generated in this same BLAS environment.
            reference_order = np.lexsort((np.asarray(doc_ids, dtype=str), -scores))
            if [doc_ids[int(j)] for j in reference_order] != [row["doc_id"] for row in full]:
                raise RegressionError(f"{embedder}/{query_id}: pinned NumPy lexsort differs from scorer ordering")
            result["source_numpy_lexsort_matches_local_scorer"] += 1
            for row in full:
                row["judged"] = row["doc_id"] in qrels[query_id]
            old_top50 = saved_by_qid[query_id]["ids"]
            computed_old_top50 = [row["doc_id"] for row in full[:50]]
            if computed_old_top50 != old_top50:
                raise RegressionError(f"{embedder}/{query_id}: full-corpus historical Top50 mismatch")
            per_model["original_top50_match_count"] += 1
            result["original_top50_rankings_matched"] += 1
            computed_top50_by_qid[query_id] = computed_old_top50

            filtered = [row for row in full if row["judged"]]
            judged_ids = [row["doc_id"] for row in filtered]
            public_row = public_map.get((embedder, query_id))
            if public_row is None or set(judged_ids) != set(public_row["judged_ids"]):
                raise RegressionError(f"{embedder}/{query_id}: corrected judged ranking set mismatch")
            if judged_ids == public_row["judged_ids"]:
                per_model["judged_ranking_exact_count"] = per_model.get("judged_ranking_exact_count", 0) + 1
                result["public_judged_rankings_exact"] += 1
            else:
                # The published ZIP contains IDs but not the original per-document scores.
                # Locate ordering drift; never excuse a changed Top50 candidate or metric.
                old_ids = public_row["judged_ids"]
                score_by_doc = {row["doc_id"]: row["similarity"] for row in full}
                changed_positions = [i for i, (new_id, old_id) in enumerate(zip(judged_ids, old_ids)) if new_id != old_id]
                old_rank_by_doc = {doc_id: rank for rank, doc_id in enumerate(old_ids, 1)}
                new_rank_by_doc = {doc_id: rank for rank, doc_id in enumerate(judged_ids, 1)}
                max_rank_delta = max(abs(new_rank_by_doc[doc_id] - old_rank_by_doc[doc_id]) for doc_id in judged_ids)
                result["public_tail_drift_diagnostics"]["max_absolute_judged_rank_delta"] = max(
                    result["public_tail_drift_diagnostics"]["max_absolute_judged_rank_delta"], max_rank_delta)
                close_score_positions = [i for i in changed_positions if
                    abs(float(score_by_doc[judged_ids[i]]) - float(score_by_doc[old_ids[i]])) <=
                    max(abs(float(score_by_doc[judged_ids[i]])), abs(float(score_by_doc[old_ids[i]])), 1.0) * 2**-23]
                changed_pairs = []
                for pos in changed_positions:
                    new_id, old_id = judged_ids[pos], old_ids[pos]
                    gap = abs(float(score_by_doc[new_id]) - float(score_by_doc[old_id]))
                    eps = max(abs(float(score_by_doc[new_id])), abs(float(score_by_doc[old_id])), 1.0) * 2**-23
                    pair = {
                        "position_1_based": pos + 1,
                        "local_doc_id": new_id,
                        "public_reference_doc_id": old_id,
                        "local_score_local_doc": float(score_by_doc[new_id]),
                        "local_score_public_doc": float(score_by_doc[old_id]),
                        "local_score_gap_at_slot": gap,
                        "one_float32_epsilon_bound": eps,
                        "within_one_float32_epsilon_by_diagnostic": gap <= eps,
                        "local_judged_rank_delta_for_local_doc": new_rank_by_doc[new_id] - old_rank_by_doc[new_id],
                        "local_judged_rank_delta_for_public_doc": new_rank_by_doc[old_id] - old_rank_by_doc[old_id],
                    }
                    changed_pairs.append(pair)
                    if gap > result["public_tail_drift_diagnostics"]["max_mismatched_slot_score_gap"]:
                        result["public_tail_drift_diagnostics"]["max_mismatched_slot_score_gap"] = gap
                        result["public_tail_drift_diagnostics"]["max_mismatched_slot_score_gap_example"] = {
                            "embedder": embedder, "query_id": query_id, **pair}
                if any(pos < 50 for pos in changed_positions):
                    raise RegressionError(f"{embedder}/{query_id}: public judged Top50 candidate order changed")
                # Candidate parity and old metric parity below are mandatory, regardless
                # of whether the full-tail difference is exact or near-equal-score drift.
                drift = {
                    "embedder": embedder,
                    "query_id": query_id,
                    "changed_positions": len(changed_positions),
                    "all_changed_positions_within_one_float32_epsilon": len(close_score_positions) == len(changed_positions),
                    "first_positions_1_based": [i + 1 for i in changed_positions[:12]],
                    "max_absolute_judged_rank_delta": max_rank_delta,
                    "changed_slot_pairs": changed_pairs,
                }
                result.setdefault("public_rank_order_drift", []).append(drift)
                per_model["judged_ranking_order_drift_count"] = per_model.get("judged_ranking_order_drift_count", 0) + 1
                result["public_judged_rankings_order_drift"] += 1
                if len(close_score_positions) != len(changed_positions):
                    result["public_judged_rankings_non_tie_mismatches"] += 1
            per_model["judged_ranking_match_count"] = per_model.get("judged_ranking_match_count", 0) + 1
            result["judged_rankings_matched"] += 1
            candidate_ids, candidate_ranks = filter_judged_top50(full, qrels[query_id])
            if candidate_ids != public_row["judged_ids"][:50]:
                raise RegressionError(f"{embedder}/{query_id}: judged-top50 candidate list differs from public reference")
            result["public_judged_top50_candidate_lists_matched"] += 1
            metrics = evaluate_ranking(judged_ids, candidate_ids, qrels[query_id])
            if not _close(metrics["ndcg@10"], public_row["ndcg10"]):
                raise RegressionError(f"{embedder}/{query_id}: corrected nDCG@10 mismatch")
            for metric, refkey in (("top1", "top1"), ("mrr@10", "mrr10")):
                if not _close(metrics[metric], public_row[refkey]):
                    raise RegressionError(f"{embedder}/{query_id}: corrected {metric} mismatch")
            recall50 = sum(doc in {d for d, g in qrels[query_id].items() if g >= 2} for doc in judged_ids[:50]) / sum(g >= 2 for g in qrels[query_id].values())
            if not _close(recall50, public_row["recall50"]):
                raise RegressionError(f"{embedder}/{query_id}: corrected recall@50 mismatch")
            for threshold in (2, 3, 4):
                if not _close(metrics[f"normalized_p5_grade_ge_{threshold}"], public_row[f"p5_stars{threshold+1}"]):
                    raise RegressionError(f"{embedder}/{query_id}: corrected normalized P@5 mismatch")
            scored_rows.append(metrics)

        metric_refs = {
            "ndcg@10": "ndcg10", "top1": "top1", "mrr@10": "mrr10",
            "recall@50": "recall50", "normalized_p5_grade_ge_2": "p5_stars3",
            "normalized_p5_grade_ge_3": "p5_stars4", "normalized_p5_grade_ge_4": "p5_stars5",
        }
        summary = corrected_map[embedder]
        for key, ref in metric_refs.items():
            observed = _mean([row[key] if key in row else None for row in scored_rows]) if key != "recall@50" else None
            # Public source uses recall@50; verify directly from the public per-query rows below.
            if key == "recall@50":
                observed = _mean([r["recall50"] for r in public_rows if r["embedding"] == embedder])
            if not _close(observed, summary[ref]):
                raise RegressionError(f"{embedder}: corrected summary mean mismatch for {ref}")
        if summary.get("p5_stars5_evaluable_queries") != 29:
            raise RegressionError(f"{embedder}: expected 29 evaluable five-star normalized P@5 queries")
        result["model_regressions"].append({
            **{k:v for k,v in per_model.items() if k != "files_sha256"},
            "public_summary_match": True,
            "corrected_ndcg10": summary["ndcg10"],
            "corrected_top1": summary["top1"],
            "corrected_p5_stars5": summary["p5_stars5"],
            "normalized_p5_ge4_valid_n": summary["p5_stars5_evaluable_queries"],
        })
        result["accepted_official_standalone"].append(
            validate_accepted_standalone(workspace, embedder, query_ids, computed_top50_by_qid)
        )

    result["status"] = ("passed_with_public_order_drift" if result["public_judged_rankings_order_drift"] else "passed")
    if result["original_top50_rankings_matched"] != 399 or result["judged_rankings_matched"] != 399:
        raise RegressionError("expected exactly 399 historical/full judged ranking matches")
    return result


def cli() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--workspace", type=Path, required=True, help="phase2 workspace")
    parser.add_argument("--package-root", type=Path, required=True, help="isolated ACORD retest package root")
    parser.add_argument("--output", type=Path, required=True, help="write regression JSON outside frozen run outputs")
    parser.add_argument("--model-pins", type=Path, required=True)
    parser.add_argument("--settings", type=Path, required=True)
    args = parser.parse_args()
    model_pins = json.loads(args.model_pins.read_text("utf-8"))
    settings = json.loads(args.settings.read_text("utf-8"))
    result = run_regression(args.workspace, args.package_root, args.workspace,
                            args.package_root/"frozen-data/acord.json", model_pins, settings)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    print(json.dumps({k: result[k] for k in ("status","original_top50_rankings_matched","judged_rankings_matched","new_inference","new_timing")}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(cli())

