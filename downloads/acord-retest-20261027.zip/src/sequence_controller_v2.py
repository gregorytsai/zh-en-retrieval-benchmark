#!/usr/bin/env python3
"""Sequential ACORD A01–A07 controller; never runs batches concurrently."""
from __future__ import annotations

import argparse
import fcntl
import hashlib
import json
import os
import signal
import subprocess
import sys
import time
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

from . import audit_execution, runner

PACKAGE_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_BATCH_WALL_HOURS = 12.0
SEQUENCE_VERSION = "acord-a01-a07-sequential-v2-validation-report-pin"


class SequenceError(RuntimeError):
    pass


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_json_atomic(path: Path, value: Any) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + f".{uuid.uuid4().hex}.tmp")
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n",
                    encoding="utf-8")
    os.replace(temp, path)


def read_json(path: Path) -> Any:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def taipei_now() -> str:
    return datetime.now(ZoneInfo("Asia/Taipei")).isoformat()


def execution_pins(package_root: Path) -> dict[str, str]:
    return {
        "controller_sha256": sha256_file(Path(__file__)),
        "runner_sha256": sha256_file(package_root / "src/runner.py"),
        "independent_audit_sha256": sha256_file(package_root / "src/audit_execution.py"),
        "models_manifest_sha256": sha256_file(package_root / "models-manifest.json"),
    }


def official_command(python: str, package_root: Path, workspace: Path, phase2_root: Path,
                     output_root: Path, preflight_root: Path, batch: str,
                     wall_hours: float, *, resume: bool = False) -> list[str]:
    if batch not in dict(runner.BATCHES):
        raise SequenceError(f"unknown batch: {batch}")
    if not (0 < float(wall_hours) <= runner.MAX_WALL_HOURS):
        raise SequenceError(f"batch wall budget must be in (0,{runner.MAX_WALL_HOURS}] hours")
    command = [
        python, "-m", "src.runner",
        "--workspace", str(workspace.resolve()),
        "--phase2-root", str(phase2_root.resolve()),
        "--output-root", str(output_root.resolve()),
        "--batch", batch, "--segment", "segment-01",
        "--wall-hours", str(float(wall_hours)),
        "--preflight-evidence", str(preflight_root.resolve()),
        "--execute",
    ]
    if resume:
        command.append("--resume")
    return command


def _run_manifest(run_dir: Path) -> dict[str, Any] | None:
    path = run_dir / "run-manifest.json"
    return read_json(path) if path.is_file() else None


def _audit_completed(run_dir: Path) -> dict[str, Any]:
    manifest = _run_manifest(run_dir)
    if not manifest or manifest.get("status") != "complete":
        raise SequenceError(f"official run is not complete: {run_dir}")
    completion = read_json(run_dir / "batch-completion-audit.json")
    validation_path = run_dir / "validation-report.json"
    if completion.get("status") != "passed":
        raise SequenceError(f"batch completion audit did not pass: {run_dir}")
    expected_validation_hash = completion.get("validation_report_sha256")
    if not expected_validation_hash or not validation_path.is_file():
        raise SequenceError(f"batch completion audit does not pin a validation report: {run_dir}")
    if sha256_file(validation_path) != expected_validation_hash:
        raise SequenceError(f"batch validation-report bytes differ from completion pin: {run_dir}")
    validation = read_json(validation_path)
    if validation.get("status") != "passed" or validation.get("run_id") != manifest.get("run_id"):
        raise SequenceError(f"independent batch validation report did not pass or has wrong run_id: {run_dir}")
    independent = audit_execution.audit(run_dir)
    if independent.get("status") != "passed":
        raise SequenceError(f"independent execution audit did not pass: {independent}")
    return independent


def resume_start_index(batch_order: list[str], completed_batches: list[str]) -> int:
    """Advance after the verified contiguous completed prefix; never relaunch it."""
    expected_prefix = batch_order[:len(completed_batches)]
    if completed_batches != expected_prefix:
        raise SequenceError(
            f"completed batches are not a contiguous prefix: {completed_batches}; expected {expected_prefix}"
        )
    return len(completed_batches)


def _runner_is_alive(pid: int, package_root: Path) -> bool:
    if pid <= 0:
        return False
    try:
        result = subprocess.run(["/bin/ps", "-p", str(pid), "-o", "command="],
                                text=True, capture_output=True, timeout=5, check=False)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise SequenceError(f"cannot safely check prior runner PID {pid}: {exc}") from exc
    command = result.stdout.strip()
    return result.returncode == 0 and "src.runner" in command and str(package_root.resolve()) in command


class SequenceLock:
    def __init__(self, path: Path):
        self.path = path
        self.handle = None

    def __enter__(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.handle = self.path.open("a+", encoding="utf-8")
        try:
            fcntl.flock(self.handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            self.handle.close()
            self.handle = None
            raise SequenceError("another ACORD sequence controller holds the sequence lock") from exc
        self.handle.seek(0)
        self.handle.truncate()
        self.handle.write(json.dumps({"pid": os.getpid(), "started_at": taipei_now()}) + "\n")
        self.handle.flush()
        return self

    def __exit__(self, _exc_type, _exc, _tb):
        if self.handle is not None:
            self.handle.seek(0)
            self.handle.truncate()
            self.handle.write(json.dumps({"released_at": taipei_now()}) + "\n")
            self.handle.flush()
            fcntl.flock(self.handle.fileno(), fcntl.LOCK_UN)
            self.handle.close()
            self.handle = None


def validate_preflight(package_root: Path, workspace: Path, preflight_root: Path) -> dict[str, Any]:
    models = read_json(package_root / "models-manifest.json")
    audit = runner.verify_live_audits(workspace, package_root, models)
    compatible = runner.check_preflight_compatibility(preflight_root, package_root, models, audit)
    independent = audit_execution.audit(preflight_root)
    if independent.get("status") != "passed" or independent.get("preflight") is not True:
        raise SequenceError(f"independent preflight execution audit failed: {independent}")
    return {**compatible, "independent_audit": independent}


def _update_status(path: Path, status: dict[str, Any], **updates: Any) -> None:
    status.update(updates)
    status["updated_at"] = taipei_now()
    write_json_atomic(path, status)


def update_plan_batch_status(package_root: Path, batch: str, embedder: str, text: str) -> None:
    """Update exactly one batch row after launch/completion; leave all plan scope fixed."""
    path = package_root / "PLAN_ZH_TW.md"
    lines = path.read_text(encoding="utf-8").splitlines()
    prefix = f"| {batch} | {embedder} |"
    matches = [i for i, line in enumerate(lines) if line.startswith(prefix)]
    if len(matches) != 1:
        raise SequenceError(f"plan batch row is missing or ambiguous: {batch}")
    lines[matches[0]] = f"| {batch} | {embedder} | {text} |"
    temp = path.with_name(path.name + f".{uuid.uuid4().hex}.tmp")
    temp.write_text("\n".join(lines) + "\n", encoding="utf-8")
    os.replace(temp, path)


def run_sequence(*, package_root: Path, workspace: Path, phase2_root: Path,
                 output_root: Path, preflight_root: Path, wall_hours: float,
                 resume: bool, python: str) -> dict[str, Any]:
    package_root = package_root.resolve()
    workspace = workspace.resolve()
    phase2_root = phase2_root.resolve()
    output_root = output_root.resolve()
    preflight_root = preflight_root.resolve()
    controller_root = output_root / "sequence-controller"
    manifest_path = controller_root / "sequence-manifest.json"
    status_path = controller_root / "sequence-status.json"
    log_root = controller_root / "logs"
    lock_path = controller_root / "sequence.lock"
    pins = execution_pins(package_root)

    if not resume:
        if status_path.exists() or manifest_path.exists():
            raise SequenceError("sequence state already exists; use --resume-sequence or a new output root")
        preflight = validate_preflight(package_root, workspace, preflight_root)
        created = taipei_now()
        sequence_id = f"acord-sequence-{datetime.now(ZoneInfo('Asia/Taipei')).strftime('%Y%m%d-%H%M%S')}-{uuid.uuid4().hex[:8]}"
        manifest = {
            "sequence_id": sequence_id, "version": SEQUENCE_VERSION,
            "created_at": created, "status": "prepared",
            "batch_order": [batch for batch, _embedder in runner.BATCHES],
            "embedder_order": [embedder for _batch, embedder in runner.BATCHES],
            "wall_hours_per_batch_max": float(wall_hours),
            "preflight": preflight,
            "preflight_root": str(preflight_root),
            "execution_pins": pins,
            "batch_runs": {},
            "launch_policy": "one child runner at a time; each batch receives its own fixed <=12h deadline; stop on any failed gate; no hidden retries beyond runner's whole-unit limit",
        }
        status = {"sequence_id": sequence_id, "status": "prepared", "current_batch": None,
                  "completed_batches": [], "batch_order": manifest["batch_order"],
                  "updated_at": created}
        controller_root.mkdir(parents=True, exist_ok=True)
        write_json_atomic(manifest_path, manifest)
        write_json_atomic(status_path, status)
    else:
        if not manifest_path.is_file() or not status_path.is_file():
            raise SequenceError("--resume-sequence requires existing sequence manifest and status")
        manifest, status = read_json(manifest_path), read_json(status_path)
        if manifest.get("version") != SEQUENCE_VERSION or manifest.get("execution_pins") != pins:
            raise SequenceError("controller/runner/audit/registry pins changed; this sequence cannot resume")
        if status.get("status") == "complete":
            return status

    with SequenceLock(lock_path):
        # A second lock acquisition can race with a preflight/launcher; re-read
        # state only after owning the sequence lock.
        manifest, status = read_json(manifest_path), read_json(status_path)
        if status.get("status") == "complete":
            return status
        if manifest.get("execution_pins") != execution_pins(package_root):
            raise SequenceError("frozen sequence source changed before launch")
        preflight_root = Path(manifest["preflight_root"])
        validate_preflight(package_root, workspace, preflight_root)
        completed = list(status.get("completed_batches", []))
        active_child: subprocess.Popen | None = None
        active_batch: str | None = None
        old_handlers = {}

        def forward_signal(signum, _frame):
            if active_child is not None and active_child.poll() is None:
                active_child.send_signal(signum)
                try:
                    active_child.wait(timeout=120)
                except subprocess.TimeoutExpired:
                    active_child.send_signal(signal.SIGTERM)
                    try:
                        active_child.wait(timeout=10)
                    except subprocess.TimeoutExpired:
                        active_child.kill()
                        active_child.wait()
            raise KeyboardInterrupt(f"sequence received signal {signum}")

        for sig in (signal.SIGINT, signal.SIGTERM):
            old_handlers[sig] = signal.signal(sig, forward_signal)

        try:
            manifest["status"] = "running"
            manifest["started_at"] = manifest.get("started_at") or taipei_now()
            status.update({"status": "running", "completed_batches": completed})
            _update_status(status_path, status)
            write_json_atomic(manifest_path, manifest)
            start_index = resume_start_index(manifest["batch_order"], completed)

            for batch in manifest["batch_order"][start_index:]:
                if batch in completed:
                    continue
                active_batch = batch
                run_dir = output_root / batch / "segment-01"
                prior = _run_manifest(run_dir)
                resume_child = False
                if prior:
                    if prior.get("status") == "complete":
                        audit = _audit_completed(run_dir)
                        entry = manifest.setdefault("batch_runs", {}).setdefault(batch, {})
                        entry.update({"status": "complete", "run_id": prior.get("run_id"),
                                      "run_dir": str(run_dir), "deadline_epoch": prior.get("deadline_epoch"),
                                      "audit": audit, "recovered_completed_run": True})
                        completed.append(batch)
                        status.update({"current_batch": batch, "completed_batches": completed,
                                       "last_batch_audit": audit})
                        write_json_atomic(manifest_path, manifest)
                        _update_status(status_path, status)
                        continue
                    child_pid = int(prior.get("execution", {}).get("runner_pid") or 0)
                    if _runner_is_alive(child_pid, package_root):
                        raise SequenceError(f"batch {batch} already has live runner PID {child_pid}; refusing duplicate")
                    if time.time() >= float(prior.get("deadline_epoch", 0)):
                        raise SequenceError(f"batch {batch} fixed deadline expired; this controller will not extend it")
                    if prior.get("package_source_sha256") != runner._package_source_hashes(package_root):
                        raise SequenceError(f"batch {batch} frozen runner source differs; cannot resume")
                    if prior.get("status") not in ("interrupted_by_operator", "running", "lock_acquired"):
                        raise SequenceError(f"batch {batch} status {prior.get('status')} is not safely resumable")
                    resume_child = True
                command = official_command(python, package_root, workspace, phase2_root,
                                           output_root, preflight_root, batch, wall_hours,
                                           resume=resume_child)
                log_path = log_root / f"{batch}.log"
                log_path.parent.mkdir(parents=True, exist_ok=True)
                batch_entry = manifest.setdefault("batch_runs", {}).setdefault(batch, {})
                batch_entry.update({"status": "launching", "run_dir": str(run_dir),
                                    "launch_argv": command, "resume": resume_child,
                                    "launched_at": taipei_now(), "log_path": str(log_path)})
                status.update({"status": "running", "current_batch": batch,
                               "completed_batches": completed, "child_pid": None,
                               "launch_argv": command, "run_dir": str(run_dir)})
                write_json_atomic(manifest_path, manifest)
                _update_status(status_path, status)
                update_plan_batch_status(package_root, batch, dict(runner.BATCHES)[batch],
                                         "正式 runner 啟動中；每批 12 小時固定期限")
                with log_path.open("a", encoding="utf-8") as log:
                    active_child = subprocess.Popen(command, cwd=package_root,
                                                    stdout=log, stderr=subprocess.STDOUT,
                                                    text=True)
                    batch_entry["runner_pid"] = active_child.pid
                    batch_entry["status"] = "running"
                    batch_entry["runner_started_at"] = taipei_now()
                    status["child_pid"] = active_child.pid
                    status["runner_started_at"] = batch_entry["runner_started_at"]
                    write_json_atomic(manifest_path, manifest)
                    _update_status(status_path, status)
                    while True:
                        try:
                            return_code = active_child.wait(timeout=30)
                            break
                        except subprocess.TimeoutExpired:
                            child_manifest = _run_manifest(run_dir)
                            if child_manifest:
                                batch_entry.update({"run_id": child_manifest.get("run_id"),
                                                    "deadline_epoch": child_manifest.get("deadline_epoch"),
                                                    "runner_status": child_manifest.get("status"),
                                                    "accepted_rows": child_manifest.get("execution", {}).get("formal_accepted_rows", 0)})
                                p = run_dir / "progress.json"
                                if p.is_file():
                                    batch_entry["progress"] = read_json(p)
                            status["child_status"] = batch_entry.get("runner_status", "starting")
                            status["accepted_rows"] = batch_entry.get("accepted_rows", 0)
                            _update_status(status_path, status)
                            write_json_atomic(manifest_path, manifest)
                active_child = None
                child_manifest = _run_manifest(run_dir)
                batch_entry["runner_exit_code"] = return_code
                if child_manifest:
                    batch_entry["run_id"] = child_manifest.get("run_id")
                    batch_entry["deadline_epoch"] = child_manifest.get("deadline_epoch")
                    batch_entry["runner_status"] = child_manifest.get("status")
                if return_code != 0 or not child_manifest or child_manifest.get("status") != "complete":
                    batch_entry["status"] = "needs_attention"
                    batch_entry["finished_at"] = taipei_now()
                    manifest["status"] = "blocked_on_batch"
                    manifest["blocked_batch"] = batch
                    manifest["blocked_reason"] = "child runner did not complete successfully; fixed deadline and accepted evidence preserved"
                    status.update({"status": "blocked_on_batch", "current_batch": batch,
                                   "child_pid": None, "child_exit_code": return_code,
                                   "runner_status": child_manifest.get("status") if child_manifest else "manifest_missing"})
                    write_json_atomic(manifest_path, manifest)
                    _update_status(status_path, status)
                    update_plan_batch_status(package_root, batch, dict(runner.BATCHES)[batch],
                                             f"未完成，保留 accepted/attempt 證據；狀態 {batch_entry.get('runner_status', 'manifest_missing')}")
                    return status
                independent = _audit_completed(run_dir)
                batch_entry.update({"status": "complete", "finished_at": taipei_now(),
                                    "audit": independent})
                completed.append(batch)
                update_plan_batch_status(package_root, batch, dict(runner.BATCHES)[batch],
                                         f"完成 228 rows；batch audit 與 execution audit passed（{child_manifest.get('run_id')}）")
                status.update({"status": "running", "current_batch": batch,
                               "completed_batches": completed, "child_pid": None,
                               "last_batch_audit": independent,
                               "accepted_rows": 228})
                write_json_atomic(manifest_path, manifest)
                _update_status(status_path, status)

            manifest["status"] = "complete"
            manifest["completed_at"] = taipei_now()
            status.update({"status": "complete", "current_batch": None,
                           "completed_batches": completed, "child_pid": None})
            write_json_atomic(manifest_path, manifest)
            _update_status(status_path, status)
            return status
        except KeyboardInterrupt:
            manifest["status"] = "interrupted"
            manifest["interrupted_at"] = taipei_now()
            if active_batch:
                manifest.setdefault("batch_runs", {}).setdefault(active_batch, {})["status"] = "interrupted"
            status.update({"status": "interrupted", "current_batch": active_batch,
                           "completed_batches": completed, "child_pid": None})
            write_json_atomic(manifest_path, manifest)
            _update_status(status_path, status)
            raise
        finally:
            for sig, handler in old_handlers.items():
                signal.signal(sig, handler)


def parser() -> argparse.ArgumentParser:
    value = argparse.ArgumentParser(description=__doc__)
    value.add_argument("--workspace", type=Path, required=True)
    value.add_argument("--phase2-root", type=Path, required=True)
    value.add_argument("--output-root", type=Path, default=PACKAGE_ROOT / "runs")
    value.add_argument("--preflight-evidence", type=Path,
                       default=PACKAGE_ROOT / "runs/preflight/segment-02")
    value.add_argument("--wall-hours", type=float, default=DEFAULT_BATCH_WALL_HOURS)
    value.add_argument("--resume-sequence", action="store_true")
    value.add_argument("--execute", action="store_true")
    return value


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    try:
        if not args.execute:
            plan = {"status": "offline_plan_only", "sequence_version": SEQUENCE_VERSION,
                    "batch_order": [batch for batch, _ in runner.BATCHES],
                    "embedders": [embedder for _, embedder in runner.BATCHES],
                    "per_batch_wall_hours_max": runner.MAX_WALL_HOURS,
                    "preflight_required": str(args.preflight_evidence),
                    "execute_required": True, "inference_started": False}
            print(json.dumps(plan, ensure_ascii=False, indent=2))
            return 0
        status = run_sequence(package_root=PACKAGE_ROOT, workspace=args.workspace,
                              phase2_root=args.phase2_root, output_root=args.output_root,
                              preflight_root=args.preflight_evidence,
                              wall_hours=args.wall_hours, resume=args.resume_sequence,
                              python=sys.executable)
        print(json.dumps(status, ensure_ascii=False, indent=2))
        return 0 if status.get("status") == "complete" else 2
    except (SequenceError, runner.RunnerError, OSError, ValueError, KeyError) as exc:
        print(json.dumps({"status": "blocked", "error": f"{type(exc).__name__}: {exc}"},
                         ensure_ascii=False, indent=2), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
