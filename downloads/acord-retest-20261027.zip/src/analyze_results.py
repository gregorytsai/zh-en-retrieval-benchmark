#!/usr/bin/env python3
"""Rebuild descriptive ACORD analysis from validated primitive evidence.

No bootstrap is performed: official parent/cluster coverage must first support it.
No query text examples are inserted in either report. This script never publishes.
"""
from __future__ import annotations

import argparse
import collections
import json
import math
import statistics
from pathlib import Path

try:
    from . import independent_validate as v
except ImportError:
    import independent_validate as v

PAIR_LEFT = 'qwen-4b__qwen-reranker-0.6b'
PAIR_RIGHT = 'bge-m3__qwen-reranker-0.6b'
TIE_TOLERANCE = 1e-12


def aggregate(values):
    valid = [x for x in values if x is not None]
    return {'mean': statistics.mean(valid) if valid else None, 'valid_n': len(valid)}


def paired(left, right, query_ids, metrics):
    out = {}
    for metric in metrics:
        rows = []
        excluded = []
        for q in sorted(query_ids):
            a, b = left[q]['metrics'][metric], right[q]['metrics'][metric]
            if a is None or b is None:
                excluded.append(q)
                continue
            delta = a - b
            outcome = 'tie' if abs(delta) <= TIE_TOLERANCE else ('win' if delta > 0 else 'loss')
            rows.append({'query_id': q, 'left': a, 'right': b, 'delta': delta, 'outcome': outcome})
        counts = collections.Counter(r['outcome'] for r in rows)
        out[metric] = {'mean_difference': aggregate([r['delta'] for r in rows])['mean'],
                       'valid_n': len(rows), 'excluded_query_ids': excluded,
                       'wins': counts['win'], 'losses': counts['loss'], 'ties': counts['tie'],
                       'per_query': rows}
    return out


def dependency_metadata(queries):
    """Only official metadata counts; never promote study-derived clusters."""
    fields = {}
    for name in ('parent_query_id', 'cluster_id'):
        present = {q['id']: q.get('metadata', {}).get(name) for q in queries}
        present = {q: val for q, val in present.items() if val not in (None, '')}
        fields[name] = {'nonempty_queries': len(present),
                        'unique_values': len(set(str(val) for val in present.values()))}
    return {'official_fields': fields, 'study_metadata_used_for_grouping': False,
            'bootstrap_performed': False,
            'reason': 'No confidence intervals are computed; reliable source-question dependence groups have not been established.'}


def build_analysis(data, results, candidates, models, summaries):
    groups = collections.defaultdict(dict)
    for r in results:
        v.need(r['query_id'] not in groups[r['config_id']], 'duplicate analysis result', 'duplicate')
        groups[r['config_id']][r['query_id']] = r
    pools = {(r['embedder'], r['query_id']): r['candidate_ids'] for r in candidates}
    qids = {q['id'] for q in data['queries']}
    metrics = list(next(iter(results))['metrics'])
    for config, rows in groups.items():
        v.need(set(rows) == qids, f'incomplete analysis group {config}', 'missing')
    changes, capacity = [], []
    for embedder in v.EMBEDDERS:
        base = groups[f'{embedder}__standalone']
        for reranker in v.RERANKERS[1:]:
            config = f'{embedder}__{reranker}'
            diff = paired(groups[config], base, qids, metrics)
            changes.append({'config_id': config, 'baseline': f'{embedder}__standalone', 'metrics': diff})
        per_query = []
        for q in sorted(qids):
            judgments = data['qrels'][q]
            pool = pools[(embedder, q)]
            ideal_in_pool = sorted(pool, key=lambda d: (-judgments[d], d))
            oracle = v.recompute(ideal_in_pool, judgments, pool)
            row = {'query_id': q, 'candidate_recall@50': oracle['candidate_recall@50'],
                   'oracle_candidate_ndcg@10': oracle['ndcg@10'],
                   'candidate_limit_gap_ndcg@10': 1.0 - oracle['ndcg@10'],
                   'within_candidate_ordering_gap_ndcg@10': {}}
            for reranker in v.RERANKERS[1:]:
                observed = groups[f'{embedder}__{reranker}'][q]['metrics']['ndcg@10']
                gap = oracle['ndcg@10'] - observed
                v.need(gap >= -TIE_TOLERANCE, 'reranker exceeds candidate oracle')
                row['within_candidate_ordering_gap_ndcg@10'][reranker] = gap
            per_query.append(row)
        capacity.append({'embedder': embedder, 'queries': len(per_query),
            'candidate_recall@50': aggregate([r['candidate_recall@50'] for r in per_query]),
            'oracle_candidate_ndcg@10': aggregate([r['oracle_candidate_ndcg@10'] for r in per_query]),
            'candidate_limit_gap_ndcg@10': aggregate([r['candidate_limit_gap_ndcg@10'] for r in per_query]),
            'within_candidate_ordering_gap_ndcg@10': {rr: aggregate([
                r['within_candidate_ordering_gap_ndcg@10'][rr] for r in per_query]) for rr in v.RERANKERS[1:]},
            'per_query': per_query})
    comparison = {'left': PAIR_LEFT, 'right': PAIR_RIGHT,
                  'direction': 'left_minus_right', 'tie_absolute_tolerance': TIE_TOLERANCE,
                  'metrics': paired(groups[PAIR_LEFT], groups[PAIR_RIGHT], qids, metrics)}
    strata = []
    for field in ('category', 'type'):
        mapping = collections.defaultdict(list)
        for q in data['queries']:
            label = q.get('metadata', {}).get(field)
            if isinstance(label, str) and label.strip():
                mapping[label].append(q['id'])
        for label, ids in sorted(mapping.items()):
            eligible = len(ids) >= 5
            strata.append({'field': field, 'value': label, 'query_count': len(ids),
                           'descriptive_comparison_included': eligible,
                           'metrics': paired(groups[PAIR_LEFT], groups[PAIR_RIGHT], ids, metrics) if eligible else None})
    weight_rows = []
    for s in summaries:
        embed, rr = s['embedder'], s['reranker']
        eb = models[embed]['bytes']
        rb = 0 if rr == 'standalone' else models[rr]['bytes']
        weight_rows.append({'config_id': s['config_id'], 'embedder_bytes': eb, 'reranker_bytes': rb,
                            'combined_weight_gib': (eb + rb) / 2 ** 30, 'measured_peak_ram_gib': None})
    return {'protocol_id': v.PROTOCOL, 'method': 'descriptive_query_paired_analysis',
            'query_unit_n': len(qids), 'independent_sample_count_not_claimed': True,
            'candidate_oracle_uses_labels_for_analysis_only': True,
            'candidate_oracle_used_for_model_inputs_or_pool_selection': False,
            'reranker_changes_from_standalone': changes, 'candidate_capacity': capacity,
            'specified_pair': comparison, 'official_metadata_strata': strata,
            'stratum_minimum_n': 5, 'strata_are_exploratory_not_stable_advantage_claims': True,
            'dependency_structure': dependency_metadata(data['queries']), 'weight_capacity': weight_rows,
            'multiple_comparison_adjustment': 'none; no inferential significance claims or confidence intervals'}


def fmt(value, percent=False):
    if value is None:
        return '—'
    return f'{value * 100:.2f}%' if percent else f'{value:.3f}'


def render_report(analysis, summaries, run_id, zh):
    title = '# ACORD 法律條款檢索修正重測' if zh else '# ACORD corrected legal-clause retrieval retest'
    lines = [title, '', f'Run: `{run_id}` · Protocol: `{v.PROTOCOL}`', '',
        ('本報告由完整逐題檔案重算並經獨立數值驗證。最終 complete 狀態仍須查 validation-report.json 的完整執行證據與交付稽核。'
         if zh else 'This report is rebuilt from complete per-query files after independent numerical validation. Final complete status additionally requires the execution-evidence and delivery audit in validation-report.json.'), '',
        ('57 題、3,931 篇條款、61,988 個明確 qrels；28 組、1,596 筆正式品質結果。每組 57 題等權。'
         if zh else '57 queries, 3,931 clauses, 61,988 explicit qrels; 28 configurations and 1,596 formal quality rows. Each configuration gives equal weight to its 57 queries.'), '',
        ('## 28 組結果' if zh else '## All 28 configurations'), '',
        '| Configuration | nDCG@5 | nDCG@10 | Top-1 | 4★ normalized P@5 | 5★ normalized P@5 (n) | Candidate Recall@50 | Total mean / p50 / p95 ms | Weights GiB |',
        '|---|---:|---:|---:|---:|---:|---:|---:|---:|']
    weights = {r['config_id']: r for r in analysis['weight_capacity']}
    ordered = sorted(summaries, key=lambda s: (-s['metrics']['ndcg@10']['mean'], s['config_id']))
    for s in ordered:
        m = s['metrics']; t = s['times_ms']['total']; five = m['normalized_p5_grade_ge_4']
        cells = [s['config_id'], fmt(m['ndcg@5']['mean']), fmt(m['ndcg@10']['mean']),
            fmt(m['top1']['mean'], True), fmt(m['normalized_p5_grade_ge_3']['mean'], True),
            f"{fmt(five['mean'], True)} ({five['valid_n']})", fmt(m['candidate_recall@50']['mean'], True),
            f"{t['mean']:.2f} / {t['p50']:.2f} / {t['p95']:.2f}",
            f"{weights[s['config_id']]['combined_weight_gib']:.3f}"]
        lines.append('| ' + ' | '.join(cells) + ' |')
    best = ordered[0]
    lines += ['', ('主要觀察：' if zh else 'Main observations: ')
        + (f"本輪最高 nDCG@10 為 {best['config_id']}（{fmt(best['metrics']['ndcg@10']['mean'])}）。相鄰組合差異很小，不能據此宣稱穩定勝出。重排未必改善結果，應比較下表每個 Embedder 的配對差異；高星等指標僅有29題可評估，不能解讀成法律答案正確率。"
           if zh else f"The highest observed nDCG@10 is {best['config_id']} ({fmt(best['metrics']['ndcg@10']['mean'])}). Small differences between nearby configurations do not establish a stable winner. Reranking does not always help: inspect the paired changes below. Five-star metrics have only 29 evaluable queries and do not measure legal-answer accuracy.")]
    lines += ['', ('權重容量是檔案大小相加，不是實測 RAM。未提供可靠 peak-memory 值，故保持 null。完整精度、其他指標、時間各階段與有效題數請見 summary.json／query-results.jsonl。'
        if zh else 'Weight capacity sums model file sizes; it is not measured RAM. Reliable peak memory is unavailable and remains null. See summary.json and query-results.jsonl for full precision, other metrics, stage timings and valid counts.'), '',
        ('## 加入重排器的逐題配對差異' if zh else '## Paired changes after reranking'), '',
        '| Configuration | Δ nDCG@10 | Wins / losses / ties | Δ 4★ normalized P@5 | Δ 5★ normalized P@5 |',
        '|---|---:|---:|---:|---:|']
    for r in analysis['reranker_changes_from_standalone']:
        m = r['metrics']; n = m['ndcg@10']
        lines.append(f"| {r['config_id']} | {fmt(n['mean_difference'])} | {n['wins']} / {n['losses']} / {n['ties']} | {fmt(m['normalized_p5_grade_ge_3']['mean_difference'], True)} | {fmt(m['normalized_p5_grade_ge_4']['mean_difference'], True)} |")
    lines += ['', ('百分比差異表示百分點；比較對象是相同 Embedder 的 standalone。'
                  if zh else 'Percentage differences represent percentage points; the baseline is the same embedder used standalone.'), '',
        ('## 候選限制與候選內排序' if zh else '## Candidate limits and ordering within candidates'), '',
        '| Embedder | Candidate Recall@50 | Candidate oracle nDCG@10 | 1 − oracle | Oracle − BGE | Oracle − Qwen 0.6B | Oracle − Qwen 4B |',
        '|---|---:|---:|---:|---:|---:|---:|']
    for r in analysis['candidate_capacity']:
        vals = [r['embedder'], fmt(r['candidate_recall@50']['mean'], True), fmt(r['oracle_candidate_ndcg@10']['mean']),
                fmt(r['candidate_limit_gap_ndcg@10']['mean'])]
        vals += [fmt(r['within_candidate_ordering_gap_ndcg@10'][rr]['mean']) for rr in v.RERANKERS[1:]]
        lines.append('| ' + ' | '.join(vals) + ' |')
    lines += ['', ('Oracle 只用於事後診斷：在已固定候選內按真實 grade 理想排序，IDCG 仍取完整 qrels。1−oracle 是候選造成的品質上限損失；oracle−實測是候選內排序仍可改善的空間。標籤未提供給模型，也未用來挑候選。'
        if zh else 'The oracle is a post-hoc diagnostic: it ideally orders the fixed candidate set by grade while IDCG still uses full qrels. 1−oracle measures the candidate-limited gap; oracle−observed measures the remaining ordering gap. Grades are never sent to models or used to select candidates.'), '',
        ('## 指定組合配對比較' if zh else '## Requested paired comparison'), '',
        f"Left: `{PAIR_LEFT}` · Right: `{PAIR_RIGHT}`", '',
        '| Metric | Mean left − right | Valid n | Wins / losses / ties |', '|---|---:|---:|---:|']
    for metric, r in analysis['specified_pair']['metrics'].items():
        lines.append(f"| {metric} | {fmt(r['mean_difference'])} | {r['valid_n']} | {r['wins']} / {r['losses']} / {r['ties']} |")
    lines += ['', ('兩組的候選池可能不同，因此差異不能全部歸因於同一重排器。完整逐題差異與勝負平手已存 analysis.json，不在文章新增真實題目案例。'
        if zh else 'These embedders may supply different candidates, so their difference cannot be attributed solely to the shared reranker. Complete per-query deltas and outcomes are in analysis.json; this article adds no real query examples.'), '',
        ('### 官方 category／type 分項（僅描述性）' if zh else '### Official category/type strata (descriptive only)'), '',
        '| Field | Label | n | Δ nDCG@10 | Wins / losses / ties |', '|---|---|---:|---:|---:|']
    for r in analysis['official_metadata_strata']:
        label = r['value'].replace('|', '\\|').replace('\n', ' ')
        if r['metrics']:
            m = r['metrics']['ndcg@10']; delta = fmt(m['mean_difference']); outcome = f"{m['wins']} / {m['losses']} / {m['ties']}"
        else:
            delta = 'n < 5'; outcome = '—'
        lines.append(f"| {r['field']} | {label} | {r['query_count']} | {delta} | {outcome} |")
    lines += ['', ('小於5題的分項只列題數；達門檻仍只是探索性描述，不能視為穩定優勢。僅使用官方標籤，未自行編造法律領域、難度或多跳分類。'
        if zh else 'Strata with fewer than five queries show counts only. Larger strata remain exploratory descriptions, not stable advantage claims. Only official labels are used; no legal-domain, difficulty or multi-hop labels are invented.'), '',
        ('## 協定與限制' if zh else '## Protocol and limitations'), '',
        ('- 已標註配對篩選使用了 qrels 的「是否受標註」資訊；未知配對移除，grade=0 保留。這不是一般 RAG 可取得的資訊。主協定 judged coverage 必然100%，不表示模型改善。\n- nDCG 使用線性 grade 和完整 qrels IDCG；二元相關門檻 grade>=2。normalized P@5 分母為 min(5,完整 qrels 達門檻數)，並非一般固定分母 Precision@5。5星有效題數29；零分母存null並排除平均。\n- 時間每組涵蓋57題，正式查詢實際執行 query embedding、完整搜尋、評估篩選與指定重排。total 為四階段加總，wall_total 另以單調時鐘量測。loopback HTTP 傳輸包含於對應推論階段；模型載入、語料準備與暖機另記。HTTP 傳輸及服務端排隊未能可靠拆分，仍包含於推論階段；獨立排隊時間保存 null。分位數採線性插值 type7。\n- 完整語料與 query 向量快取僅可供經回歸驗證的品質準備；正式時間不可由快取讀取替代推論。詳見來源與 run manifest。\n- 這57題可能有來源相依性，不將28×57視為1,596個獨立樣本。未確認可靠來源群聚，因此未做bootstrap或信賴區間；未做多重比較校正，不宣稱統計顯著。\n- 本輪使用凍結 test 子集、Q8_0 GGUF、7個指定 Embedder、3個指定 Reranker 與 judged Top50。論文模型、切分與流程不同（原文兩階段範例為BM25 Top100）；不宣稱完整複製官方leaderboard。\n- ACORD維持獨立法律專項，不納入首頁五分項或六分項平均。未發布網站。\n- launcher與十模型原始SHA符合歷史pins；本輪另凍結動態函式庫hash。歷史manifest未提供所有動態函式庫hash，不能聲稱逐一歷史位元組身份已核實。'
        if zh else '- Candidate filtering uses knowledge of which pairs have judgments; unknown pairs are removed and explicit grade=0 pairs remain. This is unavailable in ordinary RAG. Judged coverage is necessarily 100% under this protocol, not evidence of improvement.\n- nDCG uses linear grade and full-qrels IDCG; binary relevance means grade>=2. Normalized P@5 divides by min(5, full-qrels qualifying count), not a fixed five. Five-star results have 29 evaluable queries; zero denominators remain null and are excluded from means.\n- Each configuration times all 57 queries with actual query embedding, full retrieval, evaluation filtering and the selected reranker. Total sums four stages; wall_total separately uses a monotonic clock. Loopback HTTP transport is included in inference stages. Model loading, corpus preparation and warmup are recorded separately. HTTP transport and server queue time cannot be reliably separated and remain included in inference stages; standalone queue timing is null. Quantiles use type7 linear interpolation.\n- Verified corpus/query caches may support regression-checked quality preparation; cache reads cannot replace fresh inference timing. Consult source and run manifests.\n- These 57 queries may share source dependencies; 28×57 is not 1,596 independent samples. Reliable grouping has not been established, so no bootstrap or confidence intervals are reported. There is no multiple-comparison correction and no significance claim.\n- This experiment uses the frozen test subset, Q8_0 GGUF models, seven specified embedders, three specified rerankers and judged Top50. Paper models, splits and pipelines differ (its two-stage example uses BM25 Top100); this is not a replication of the official leaderboard.\n- ACORD remains a separate legal task, outside homepage five- or six-task averages. No website publication is performed.\n- The launcher and ten models match historical SHA pins; current dynamic-library hashes are additionally frozen. Historical manifests lack all library hashes, so historical byte identity of every library is not claimed.'), '',
        ('資料：ACORD，CC BY 4.0。revision `7ba1c6f2e0baaa32e78c78c2b02e9c57b102af4e`。本輪衍生變更為候選與評分協定，保留來源文字與標籤。'
         if zh else 'Data: ACORD, CC BY 4.0, revision `7ba1c6f2e0baaa32e78c78c2b02e9c57b102af4e`. Derived changes concern candidate selection and evaluation; source texts and labels are preserved.'), '',
        '[ACORD paper, C.5 and F.1](https://aclanthology.org/2025.acl-long.1206.pdf) · [Dataset](https://huggingface.co/datasets/theatticusproject/acord)', '']
    return '\n'.join(lines)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('root', type=Path)
    args = p.parse_args()
    root = args.root
    # Re-run validation rather than trusting a possibly stale report or summaries.
    validation = v.validate(root)
    summaries = v.read(root / 'summary.json')
    result = build_analysis(v.read(root / 'frozen-data/acord.json'), list(v.lines(root / 'query-results.jsonl')),
        list(v.lines(root / 'candidates.jsonl')), v.read(root / 'models-manifest.json')['models'], summaries)
    result['run_id'] = validation['run_id']
    result['input_sha256'] = {str(f): v.file_hash(root / f) for f in (
        'query-results.jsonl', 'candidates.jsonl', 'summary.json', 'frozen-data/acord.json', 'models-manifest.json')}
    (root / 'analysis.json').write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    for zh, name in ((True, 'REPORT_ZH_TW.md'), (False, 'REPORT_EN.md')):
        (root / name).write_text(render_report(result, summaries, validation['run_id'], zh), encoding='utf-8')
    print(json.dumps({'status': 'analysis_generated_after_numerical_validation', 'configurations': 28,
                      'delivery_acceptance': 'requires separate execution and publication-package audits'}))


if __name__ == '__main__':
    main()
