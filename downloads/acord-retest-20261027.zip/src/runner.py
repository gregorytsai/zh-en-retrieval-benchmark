#!/usr/bin/env python3
"""Guarded, resumable ACORD judged-top50-v1 rerun.

No inference is started unless --execute is present. A run is one embedder batch
with a fixed, non-extendable wall deadline and an explicit batch-local commit map.
"""
from __future__ import annotations

import argparse
import fcntl
import hashlib
import json
import math
import os
import shutil
import signal
import statistics
import sys
import time
import uuid
import zipfile
import platform
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable
from zoneinfo import ZoneInfo

import numpy as np

from . import owned_guard, runtime, scoring

PACKAGE_ROOT = Path(__file__).resolve().parents[1]
SPEC_FILE = PACKAGE_ROOT / "src" / "legacycore" / "matrix_spec.py"
EMBEDDERS = (
    "qwen-4b", "qwen-8b", "embeddinggemma-2", "qwen-0.6b",
    "bge-m3", "f2llm-v2-0.6b", "granite-97m-r2",
)
RERANKERS = ("standalone", "bge-reranker", "qwen-reranker-0.6b", "qwen-reranker-4b")
BATCHES = tuple((f"A{i:02d}", embedder) for i, embedder in enumerate(EMBEDDERS, 1))
MAX_WALL_HOURS = 12.0
MAX_UNIT_ATTEMPTS = 3
FILE_SCOPE = (
    "frozen-data/acord.json", "frozen-data/query-source-metadata.jsonl",
    "frozen-data/scoring-protocol.json", "models-manifest.json",
    "LIVE_HASH_AUDIT.json", "LIVE_RUNTIME_DEPENDENCY_AUDIT.json",
    "LIVE_HARDWARE_AUDIT.json", "INDEPENDENT_REFERENCE_VALIDATION.json",
    "runs/cache-regression-report.json", "source-reference/acord-corrected-rankings.zip",
    "source-reference/data/matrix/acord-corrected.json", "source-reference/LICENSE",
    "source-reference/cache-model-pins.json", "source-reference/cache-embedding-settings.json",
    "source-reference/FULL_MATRIX_ENVIRONMENT.json", "source-reference/core_v4.py",
    "source-reference/traffic_guard_v4.py", "source-reference/guarded_engine_v4.py",
    "source-reference/matrix_spec_v4.py", "source-reference/server_helper_v4.py",
    "src/scoring.py", "src/runtime.py", "src/owned_guard.py", "src/runner.py",
    "src/cache_regression.py", "src/independent_validate.py", "src/audit_publish_package.py",
    "src/analyze_results.py", "src/output-schema.json",
    "src/legacycore/__init__.py", "src/legacycore/core.py",
    "src/legacycore/matrix_spec.py", "src/legacycore/server_helper.py",
    "RUN_STATUS.json",
    "PLAN_ZH_TW.md", "PROTOCOL.md", "README_重現說明.md", "USER_REQUIREMENTS_ZH_TW.md",
)
EXECUTION_SOURCE_SCOPE = (
    "frozen-data/acord.json", "frozen-data/query-source-metadata.jsonl",
    "frozen-data/scoring-protocol.json", "models-manifest.json",
    "src/scoring.py", "src/runtime.py", "src/owned_guard.py", "src/runner.py",
    "src/cache_regression.py", "src/independent_validate.py", "src/output-schema.json",
    "src/legacycore/__init__.py", "src/legacycore/core.py",
    "src/legacycore/matrix_spec.py", "src/legacycore/server_helper.py",
    "source-reference/acord-corrected-rankings.zip",
    "source-reference/data/matrix/acord-corrected.json",
    "source-reference/cache-model-pins.json", "source-reference/cache-embedding-settings.json",
    "LIVE_HASH_AUDIT.json", "LIVE_RUNTIME_DEPENDENCY_AUDIT.json", "LIVE_HARDWARE_AUDIT.json",
    "PROTOCOL.md",
)


class RunnerError(RuntimeError):
    pass


class CandidateDrift(RunnerError):
    def __init__(self, message: str, evidence: dict[str, Any]):
        self.evidence = evidence
        super().__init__(message)


class DeadlineReached(RunnerError):
    pass


def canonical_sha(value: Any) -> str:
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True,
                         separators=(",", ":"), allow_nan=False).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def file_sha(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_json(path: Path) -> Any:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_json_atomic(path: Path, payload: Any) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + f".{uuid.uuid4()}.tmp")
    temp.write_text(json.dumps(payload, ensure_ascii=False, indent=2,
                                allow_nan=False) + "\n", encoding="utf-8")
    os.replace(temp, path)


def append_jsonl(path: Path, payload: Any) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(payload, ensure_ascii=False, allow_nan=False,
                                 separators=(",", ":")) + "\n")


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    path = Path(path)
    if not path.is_file():
        return []
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()
            if line.strip()]


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def stat_snapshot(path: Path) -> dict[str, int]:
    row = Path(path).stat()
    return {"device": int(row.st_dev), "inode": int(row.st_ino),
            "size": int(row.st_size), "mtime_ns": int(row.st_mtime_ns)}


def _elapsed_ms(start_ns: int, end_ns: int) -> float:
    """Convert an enclosing monotonic interval to milliseconds."""
    if type(start_ns) is not int or type(end_ns) is not int:
        raise RunnerError("monotonic interval endpoints must be integer nanoseconds")
    if start_ns < 0 or end_ns < start_ns:
        raise RunnerError("monotonic interval must be nonnegative and ordered")
    return (end_ns - start_ns) / 1_000_000.0


def _safe_workspace_file(workspace: Path, relative: str) -> Path:
    path = (workspace / relative).resolve()
    if not path.is_relative_to(workspace.resolve()):
        raise RunnerError(f"workspace path escapes selected root: {relative}")
    return path


def verify_live_audits(workspace: Path, package_root: Path, models_manifest: dict[str, Any]) -> dict[str, Any]:
    """Use completed full-byte audits, then verify current inode/size/mtime snapshots."""
    hash_path = package_root / "LIVE_HASH_AUDIT.json"
    dependency_path = package_root / "LIVE_RUNTIME_DEPENDENCY_AUDIT.json"
    hardware_path = package_root / "LIVE_HARDWARE_AUDIT.json"
    for path in (hash_path, dependency_path, hardware_path):
        if not path.is_file():
            raise RunnerError(f"required live prelaunch audit is missing: {path.name}")
    hash_audit = read_json(hash_path)
    dependency_audit = read_json(dependency_path)
    hardware = read_json(hardware_path)
    if hash_audit.get("status") != "passed":
        raise RunnerError("live model/binary SHA audit did not pass")
    if dependency_audit.get("status") != "passed_current_runtime_inventory":
        raise RunnerError("live runtime dependency inventory did not pass")
    if dependency_audit.get("git_status") != "":
        raise RunnerError("llama.cpp source tree is not clean according to runtime audit")
    if hardware.get("status") not in ("passed", "passed_live_hardware"):
        raise RunnerError("live hardware audit did not pass")
    audited_models = {row["model_id"]: row for row in hash_audit.get("models", [])}
    manifest_models = models_manifest.get("models", {})
    if set(audited_models) != set(manifest_models):
        raise RunnerError("live model audit coverage differs from frozen registry")
    checked_models = {}
    for model_id, pin in manifest_models.items():
        row = audited_models[model_id]
        rel = pin["path_relative_to_gguf"]
        if row.get("workspace_relative_path") != rel or row.get("actual_sha256") != pin["sha256"]:
            raise RunnerError(f"live SHA audit differs from registry for {model_id}")
        if not row.get("passed") or not row.get("stat_stable_during_hash"):
            raise RunnerError(f"live hash/stat audit did not pass for {model_id}")
        expected_stat = row.get("stat_snapshot") or row.get("stat")
        if not isinstance(expected_stat, dict):
            raise RunnerError(f"model stat snapshot missing from live audit: {model_id}")
        path = _safe_workspace_file(workspace, rel)
        if stat_snapshot(path) != expected_stat:
            raise RunnerError(f"model file stat changed since SHA audit: {model_id}")
        if path.stat().st_size != pin["bytes"]:
            raise RunnerError(f"model size differs from frozen registry: {model_id}")
        checked_models[model_id] = {"sha256": pin["sha256"], "stat": expected_stat}

    binary_pin = models_manifest["server"]
    binary_audit = hash_audit.get("binary", {})
    if (binary_audit.get("workspace_relative_path") != binary_pin["binary_path_relative_to_gguf"] or
            binary_audit.get("sha256") != binary_pin["binary_sha256"] or
            binary_audit.get("bytes") != binary_pin["binary_bytes"] or
            not binary_audit.get("stat_stable")):
        raise RunnerError("binary SHA audit differs from frozen runtime pin")
    binary_stat = binary_audit.get("stat_snapshot") or binary_audit.get("stat")
    if not isinstance(binary_stat, dict):
        raise RunnerError("live binary stat snapshot is missing")
    binary_path = _safe_workspace_file(workspace, binary_pin["binary_path_relative_to_gguf"])
    if stat_snapshot(binary_path) != binary_stat:
        raise RunnerError("llama-server binary stat changed since SHA audit")

    dependency_rows = dependency_audit.get("files", [])
    if not dependency_rows:
        raise RunnerError("runtime audit has no dependency inventory")
    checked_dependencies = []
    for dep in dependency_rows:
        path_value = dep.get("path")
        expected_stat = dep.get("stat_snapshot")
        if not isinstance(path_value, str) or not isinstance(expected_stat, dict):
            raise RunnerError("runtime dependency stat snapshot is missing")
        path = Path(path_value)
        if not path.is_absolute():
            path = _safe_workspace_file(workspace, path_value)
        if stat_snapshot(path) != expected_stat:
            raise RunnerError(f"runtime dependency stat changed: {Path(path_value).name}")
        if path.stat().st_size != dep.get("bytes"):
            raise RunnerError(f"runtime dependency size changed: {Path(path_value).name}")
        checked_dependencies.append({"path_label": path.name, "bytes": dep["bytes"],
                                     "sha256": dep["sha256"], "stat": expected_stat})
    return {
        "hash_audit_sha256": file_sha(hash_path),
        "runtime_dependency_audit_sha256": file_sha(dependency_path),
        "hardware_audit_sha256": file_sha(hardware_path),
        "models": checked_models,
        "binary_sha256": binary_pin["binary_sha256"],
        "binary_stat": binary_stat,
        "runtime_dependencies": checked_dependencies,
        "hardware_summary": {key: hardware.get(key) for key in ("status", "platform", "cpu", "physical_memory_bytes")},
    }


def validate_frozen_data(data: dict[str, Any], protocol: dict[str, Any] | None = None) -> None:
    # Protocol is pinned in scoring-protocol.json/config, not injected into the
    # upstream ACORD dataset JSON.
    if data.get("dataset_id") != "acord-eng-eng":
        raise RunnerError("frozen dataset id mismatch")
    if protocol is not None and (protocol.get("protocol_id") != "judged-top50-v1" or
                                 protocol.get("dataset_id") != data.get("dataset_id")):
        raise RunnerError("scoring-protocol dataset/protocol id mismatch")
    corpus = data.get("corpus")
    queries = data.get("queries")
    qrels = data.get("qrels")
    if not isinstance(corpus, list) or len(corpus) != 3931:
        raise RunnerError("ACORD corpus must contain exactly 3,931 clauses")
    if not isinstance(queries, list) or len(queries) != 57:
        raise RunnerError("ACORD test set must contain exactly 57 queries")
    if not isinstance(qrels, dict) or len(qrels) != 57 or sum(len(x) for x in qrels.values()) != 61988:
        raise RunnerError("ACORD qrels must contain the complete 61,988 judgments")
    doc_ids = [str(row.get("id")) for row in corpus]
    query_ids = [str(row.get("id")) for row in queries]
    if len(set(doc_ids)) != 3931 or len(set(query_ids)) != 57:
        raise RunnerError("ACORD document/query IDs must be unique")
    if set(qrels) != set(query_ids):
        raise RunnerError("ACORD qrels query coverage differs from frozen queries")
    doc_set = set(doc_ids)
    for row in corpus + queries:
        if not isinstance(row.get("text"), str) or not row["text"].strip():
            raise RunnerError("every frozen ACORD query/document needs nonempty raw text")
    for query_id, judgments in qrels.items():
        if not isinstance(judgments, dict) or len(judgments) < 50:
            raise RunnerError(f"{query_id}: complete qrels do not provide 50 judged candidates")
        if any(doc_id not in doc_set or type(grade) is not int or not 0 <= grade <= 4
               for doc_id, grade in judgments.items()):
            raise RunnerError(f"{query_id}: invalid ACORD qrel")
    if sum(any(grade == 4 for grade in judgments.values()) for judgments in qrels.values()) != 29:
        raise RunnerError("ACORD five-star evaluable query count differs from frozen protocol")


def read_public_candidate_lists(package_root: Path, data: dict[str, Any]) -> tuple[dict[str, dict[str, list[str]]], dict[str, Any]]:
    archive = package_root / "source-reference" / "acord-corrected-rankings.zip"
    report_path = package_root / "runs" / "cache-regression-report.json"
    status_path = package_root / "RUN_STATUS.json"
    if not archive.is_file() or not report_path.is_file() or not status_path.is_file():
        raise RunnerError("pinned correction/cache regression evidence is incomplete")
    report = read_json(report_path)
    status = read_json(status_path)
    pin = status.get("offline_evidence", {}).get("cache_regression_report_sha256")
    if not pin or file_sha(report_path) != pin:
        raise RunnerError("offline cache-regression report hash differs from RUN_STATUS pin")
    if report.get("status") != "passed_with_public_order_drift" or report.get("new_inference") or report.get("new_timing"):
        raise RunnerError("historical cache regression is not a valid no-inference reference")
    correction = read_json(package_root / "source-reference" / "data/matrix/acord-corrected.json")
    if correction.get("verification", {}).get("original_top50_rankings_matched") != 399:
        raise RunnerError("pinned correction reference does not cover 399 rows")
    query_ids = [str(row["id"]) for row in data["queries"]]
    qrels = data["qrels"]
    result = {embedder: {} for embedder in EMBEDDERS}
    with zipfile.ZipFile(archive) as zf:
        rows = [json.loads(line) for line in zf.read("judged-rankings.jsonl").decode("utf-8").splitlines() if line.strip()]
    if len(rows) != 399 or len({(row.get("embedding"), str(row.get("query_id"))) for row in rows}) != 399:
        raise RunnerError("pinned public judged ranking archive must contain 399 unique rows")
    for row in rows:
        embedder, query_id = row.get("embedding"), str(row.get("query_id"))
        if embedder not in result or query_id not in qrels:
            raise RunnerError("public corrected ranking has an unknown embedder/query")
        ids = row.get("judged_ids")
        if not isinstance(ids, list) or len(ids) < 50:
            raise RunnerError(f"{embedder}/{query_id}: reference judged ranking is shorter than 50")
        candidates = [str(value) for value in ids[:50]]
        if len(set(candidates)) != 50 or any(doc_id not in qrels[query_id] for doc_id in candidates):
            raise RunnerError(f"{embedder}/{query_id}: reference Top50 has duplicate/unknown/unjudged IDs")
        result[embedder][query_id] = candidates
    expected_queries = set(query_ids)
    if any(set(result[name]) != expected_queries for name in EMBEDDERS):
        raise RunnerError("public corrected candidate archive lacks a complete 7x57 matrix")
    evidence = {"archive_sha256": file_sha(archive), "report_sha256": file_sha(report_path),
                "dataset_sha256": report["dataset_sha256"],
                "candidate_sets": {name: canonical_sha(result[name]) for name in EMBEDDERS},
                "ordered_candidate_hashes": {name: {qid: scoring.ordered_candidate_hash(ids)
                    for qid, ids in result[name].items()} for name in EMBEDDERS}}
    return result, evidence


def load_verified_corpus_cache(workspace: Path, package_root: Path, embedder: str,
                               data: dict[str, Any], run_dir: Path | None = None,
                               phase2_root: Path | None = None) -> tuple[np.ndarray, str, dict[str, Any]]:
    """Verify a previously accepted standalone corpus-vector cache for search only."""
    src_path = str((package_root / "src").resolve())
    if src_path not in sys.path:
        sys.path.insert(0, src_path)
    from .cache_regression import CACHE_RELATIVE, validate_cache_manifest
    phase2_root = (Path(phase2_root) if phase2_root else
                   Path(workspace) / "embedding-study-phase2-20261023")
    manifest_all = read_json(package_root / "models-manifest.json")
    model = manifest_all["models"][embedder]
    settings = read_json(package_root / "source-reference/cache-embedding-settings.json")[embedder]
    model_pins = read_json(package_root / "source-reference/cache-model-pins.json")
    report = read_json(package_root / "runs/cache-regression-report.json")
    cache = phase2_root / CACHE_RELATIVE[embedder]
    manifest = read_json(cache / "cache-manifest.json")
    query_ids = [str(row["id"]) for row in data["queries"]]
    verified = validate_cache_manifest(cache, manifest, report["dataset_sha256"], embedder,
                                       query_ids, model_pins[embedder], settings)
    correction = read_json(package_root / "source-reference/data/matrix/acord-corrected.json")
    provenance = correction.get("provenance", {}).get(embedder)
    if (not isinstance(provenance, dict) or
            provenance.get("cache_manifest_sha256") != verified["manifest_sha256"] or
            provenance.get("files_sha256") != verified["files_sha256"] or
            provenance.get("dataset_sha256") != report["dataset_sha256"] or
            provenance.get("model_sha256") != model["sha256"] or
            provenance.get("dimension") != settings["dimension"] or
            provenance.get("query_ids") != query_ids or
            provenance.get("original_top50_rankings_matched") != 57):
        raise RunnerError(f"{embedder}: accepted cache provenance is not compatible with public correction")
    accepted = next((row for row in report["accepted_official_standalone"]
                     if row.get("committed_key") == f"acord-eng-eng--{embedder}--standalone"), None)
    if not accepted or accepted.get("batch_audit_status") not in ("passed", "not-present-for-split-segment"):
        raise RunnerError(f"{embedder}: accepted standalone commit/audit reference missing")
    if accepted.get("accepted_query_count") != 57 or accepted.get("official_main_top50_match_count") != 57 or accepted.get("accepted_attempt_top50_match_count") != 57:
        raise RunnerError(f"{embedder}: accepted standalone source did not cover all queries")
    official = phase2_root / accepted["official_relative_path"]
    committed = official / "committed.json"
    if file_sha(committed) != accepted["committed_sha256"]:
        raise RunnerError(f"{embedder}: official committed pointer changed after regression audit")
    commit = read_json(committed)
    pointer = commit.get(accepted["committed_key"])
    if not isinstance(pointer, dict) or pointer.get("queries") != 57:
        raise RunnerError(f"{embedder}: current accepted commit pointer is invalid")
    attempt = (official / pointer["attempt"]).resolve()
    if not attempt.is_relative_to(official.resolve()):
        raise RunnerError(f"{embedder}: accepted attempt path escapes official run")
    validity = read_json(attempt / "validity.json")
    if validity.get("status") != "accepted":
        raise RunnerError(f"{embedder}: committed standalone attempt is not accepted")
    if file_sha(attempt / "query-results.jsonl") != accepted["attempt_query_results_sha256"]:
        raise RunnerError(f"{embedder}: accepted attempt rows changed after regression audit")
    if file_sha(official / "query-results.jsonl") != accepted["official_query_results_sha256"]:
        raise RunnerError(f"{embedder}: official main rows changed after regression audit")

    corpus = verified["corpus"]
    if run_dir is not None:
        destination = run_dir / "corpus-cache" / "corpus.npy"
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(cache / "corpus.npy", destination)
        if file_sha(destination) != verified["files_sha256"]["corpus.npy"]:
            raise RunnerError("copied accepted corpus vectors failed hash check")
        corpus = np.load(destination, allow_pickle=False)
        corpus_hash = file_sha(destination)
    else:
        corpus_hash = verified["files_sha256"]["corpus.npy"]
    if (corpus.shape != (3931, int(settings["dimension"])) or corpus.dtype != np.float32 or
            not np.isfinite(corpus).all() or np.max(np.abs(np.linalg.norm(corpus, axis=1) - 1.0)) >= 1e-5):
        raise RunnerError(f"{embedder}: accepted corpus vectors fail shape/numeric/normalization gate")
    return np.asarray(corpus, dtype=np.float32), corpus_hash, {
        "cache_manifest_sha256": verified["manifest_sha256"],
        "corpus_file_sha256": corpus_hash,
        "source_official": accepted["official_relative_path"],
        "committed_sha256": accepted["committed_sha256"],
        "attempt_query_results_sha256": accepted["attempt_query_results_sha256"],
        "official_query_results_sha256": accepted["official_query_results_sha256"],
        "cache_files_sha256": verified["files_sha256"],
    }


def validate_source_data(package_root: Path, phase2_root: Path,
                         data: dict[str, Any], protocol: dict[str, Any]) -> dict[str, Any]:
    """Cross-check frozen ACORD order, text, metadata, qrels and upstream ZIP."""
    validate_frozen_data(data, protocol)
    src_path = str((package_root / "src").resolve())
    if src_path not in sys.path:
        sys.path.insert(0, src_path)
    from .cache_regression import validate_frozen_source
    with (phase2_root / "datasets.json").open("r", encoding="utf-8") as handle:
        datasets = json.load(handle)["datasets"]
    source_dir = package_root / "runs" / "source-validation"
    source_dir.mkdir(parents=True, exist_ok=True)
    source_payload = {"datasets": {"acord-eng-eng": datasets["acord-eng-eng"]}}
    write_json_atomic(source_dir / "datasets.json", source_payload)
    original_zip = package_root / "source-reference" / "acord-original.zip"
    source_zip = source_dir / "sources" / "acord" / "original.zip"
    source_zip.parent.mkdir(parents=True, exist_ok=True)
    if not source_zip.exists() or file_sha(source_zip) != file_sha(original_zip):
        shutil.copy2(original_zip, source_zip)
    result = validate_frozen_source(source_dir, data)
    if result["phase2_dataset_canonical_sha256"] != read_json(package_root / "runs" / "cache-regression-report.json")["dataset_sha256"]:
        raise RunnerError("phase-2 ACORD canonical data hash differs from cache-regression evidence")
    return {**result,
            "phase2_dataset_file_sha256": file_sha(phase2_root / "datasets.json"),
            "upstream_zip_sha256": file_sha(original_zip),
            "frozen_dataset_sha256": file_sha(package_root / "frozen-data" / "acord.json")}


def _model_subset(full_manifest: dict[str, Any], model_ids: list[str]) -> dict[str, Any]:
    expected = set(model_ids)
    if not expected <= set(full_manifest.get("models", {})):
        raise RunnerError("requested run models are not present in the pinned registry")
    return {**full_manifest,
            "scope": "official batch subset of full frozen ten-model registry",
            "models": {model_id: full_manifest["models"][model_id] for model_id in model_ids}}


def _copy_package_inputs(package_root: Path, run_dir: Path, *, model_ids: list[str],
                         include_protocol: bool = True) -> dict[str, str]:
    """Copy exact source evidence into a new run root and hash every copied input."""
    full_manifest = read_json(package_root / "models-manifest.json")
    hashes: dict[str, str] = {}
    for relative in FILE_SCOPE:
        source = package_root / relative
        if not source.is_file():
            if relative in ("PROTOCOL.md", "README_重現說明.md"):
                continue
            raise RunnerError(f"frozen input is missing: {relative}")
        destination = run_dir / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        hashes[relative] = file_sha(destination)
    # A compact source view supports independent revalidation without copying the
    # other five studies from the 8.8 MB combined datasets file.
    source_data = json.loads((package_root / "runs/source-validation/datasets.json").read_text("utf-8"))
    source_json_rel = "source-reference/phase2-acord-source/datasets.json"
    source_json = run_dir / source_json_rel
    source_json.parent.mkdir(parents=True, exist_ok=True)
    write_json_atomic(source_json, source_data)
    hashes[source_json_rel] = file_sha(source_json)
    original_zip = package_root / "source-reference/acord-original.zip"
    dest_zip = run_dir / "source-reference/phase2-acord-source/sources/acord/original.zip"
    dest_zip.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(original_zip, dest_zip)
    hashes[str(dest_zip.relative_to(run_dir))] = file_sha(dest_zip)
    # Preserve the complete ten-model registry separately; independent scoring
    # reads the scoped models-manifest.json below.
    all_models_rel = "source-reference/models-manifest-all.json"
    all_models_path = run_dir / all_models_rel
    write_json_atomic(all_models_path, full_manifest)
    hashes[all_models_rel] = file_sha(all_models_path)
    if include_protocol and "frozen-data/scoring-protocol.json" not in hashes:
        raise RunnerError("scoring protocol did not enter frozen run files")
    # Every segment freezes the same complete ten-model registry. The independent
    # validator scopes measured rows separately, while source_runs aggregation can
    # compare one immutable manifest hash across all seven batches.
    if read_json(run_dir / "models-manifest.json") != full_manifest:
        raise RunnerError("copied full models-manifest changed during run preparation")
    return hashes


def _atomic_committed(path: Path, commits: dict[str, Any]) -> None:
    write_json_atomic(path, {"schema_version": 1, "commits": commits})


def load_commits(run_dir: Path) -> dict[str, dict[str, Any]]:
    payload = read_json(run_dir / "committed.json") if (run_dir / "committed.json").is_file() else {"commits": {}}
    commits = payload.get("commits", {})
    if not isinstance(commits, dict):
        raise RunnerError("committed.json is malformed")
    accepted = {}
    for key, pointer in commits.items():
        if not isinstance(pointer, dict) or not isinstance(pointer.get("attempt"), str):
            raise RunnerError(f"invalid committed pointer for {key}")
        attempt = (run_dir / pointer["attempt"]).resolve()
        if not attempt.is_relative_to(run_dir.resolve()):
            raise RunnerError(f"committed attempt escapes run directory: {key}")
        validity_path = attempt / "validity.json"
        if not validity_path.is_file():
            raise RunnerError(f"committed attempt validity is missing: {key}")
        validity = read_json(validity_path)
        if validity.get("status") != "accepted" or file_sha(validity_path) != pointer.get("validity_sha256"):
            raise RunnerError(f"committed attempt is not accepted or validity hash differs: {key}")
        accepted[key] = pointer
    return accepted


def _attempt_key(config_id: str, query_id: str) -> str:
    return f"{config_id}|{query_id}"


def _attempt_path(run_dir: Path, config_id: str, query_id: str, attempt_id: str) -> Path:
    return run_dir / "attempts" / config_id / query_id / attempt_id


def _attempt_bundle(attempt: Path) -> dict[str, Any]:
    return {
        "result": read_json(attempt / "query-result.json"),
        "timing": read_json(attempt / "timing-result.json"),
        "retrieval": read_json(attempt / "retrieval-attempt.json"),
        "traces": read_json(attempt / "request-traces.json"),
        "scores": read_json(attempt / "reranker-scores.json"),
        "candidate": read_json(attempt / "candidate-list.json") if (attempt / "candidate-list.json").is_file() else None,
        "full_ranking": read_json(attempt / "full-ranking.json") if (attempt / "full-ranking.json").is_file() else None,
    }


def _append_bundle(run_dir: Path, bundle: dict[str, Any]) -> None:
    append_jsonl(run_dir / "query-results.jsonl", bundle["result"])
    append_jsonl(run_dir / "timing-results.jsonl", bundle["timing"])
    append_jsonl(run_dir / "retrieval-attempts.jsonl", bundle["retrieval"])
    for trace in bundle["traces"]:
        append_jsonl(run_dir / "request-trace.jsonl", trace)
    for score in bundle["scores"]:
        append_jsonl(run_dir / "reranker-scores.jsonl", score)
    if bundle["candidate"] is not None:
        append_jsonl(run_dir / "candidates.jsonl", bundle["candidate"])
    if bundle["full_ranking"] is not None:
        append_jsonl(run_dir / "full-retrieval-rankings.jsonl", bundle["full_ranking"])


def rebuild_aggregates(run_dir: Path, commits: dict[str, dict[str, Any]]) -> None:
    """Regenerate main JSONL tables from accepted commit pointers only."""
    names = ("query-results.jsonl", "timing-results.jsonl", "retrieval-attempts.jsonl",
             "request-trace.jsonl", "reranker-scores.jsonl", "candidates.jsonl",
             "full-retrieval-rankings.jsonl")
    for name in names:
        target = run_dir / name
        if target.exists():
            target.unlink()
    reranker_order = {name: i for i, name in enumerate(RERANKERS)}
    def sort_key(item):
        _key, pointer = item
        row = read_json((run_dir / pointer["attempt"]) / "query-result.json")
        return (reranker_order.get(row["reranker"], 999), str(row["query_id"]))
    for _key, pointer in sorted(commits.items(), key=sort_key):
        attempt = run_dir / pointer["attempt"]
        validity = read_json(attempt / "validity.json")
        if validity.get("status") != "accepted":
            raise RunnerError("aggregate rebuild saw a non-accepted committed attempt")
        _append_bundle(run_dir, _attempt_bundle(attempt))
    rows = read_jsonl(run_dir / "query-results.jsonl")
    keys = [(row["config_id"], row["query_id"]) for row in rows]
    if len(set(keys)) != len(keys):
        raise RunnerError("accepted commit pointers produce duplicate main query rows")
    write_json_atomic(run_dir / "summary.json", build_summary(read_json(run_dir / "run-manifest.json")["run_id"], rows))


def write_progress(run_dir: Path, manifest: dict[str, Any], commits: dict[str, dict[str, Any]],
                   status: str, current: dict[str, Any] | None = None,
                   errors: int | None = None) -> None:
    by_config = {f"{manifest.get('embedder')}__{reranker}": 0 for reranker in RERANKERS}
    for pointer in commits.values():
        row = read_json((run_dir / pointer["attempt"]) / "query-result.json")
        by_config[row["config_id"]] = by_config.get(row["config_id"], 0) + 1
    payload = {"run_id": manifest["run_id"], "mode": manifest["mode"],
               "batch": manifest.get("batch"), "embedder": manifest.get("embedder"),
               "status": status, "accepted_rows": sum(by_config.values()),
               "accepted_summaries": sum(count == 57 for count in by_config.values()),
               "expected_rows": 228, "accepted_by_config": by_config,
               "current_unit": current, "error_count": errors if errors is not None else 0,
               "deadline_epoch": manifest["deadline_epoch"], "updated_at": utc_now()}
    write_json_atomic(run_dir / "progress.json", payload)


def plan_for_batch(batch: str) -> dict[str, Any]:
    mapping = dict(BATCHES)
    if batch not in mapping:
        raise RunnerError(f"unknown batch: {batch}")
    embedder = mapping[batch]
    return {"status": "offline_plan_only", "batch": batch, "embedder": embedder,
            "configs": [{"config_id": f"{embedder}__{reranker}", "embedder": embedder,
                         "reranker": reranker, "queries": 57} for reranker in RERANKERS],
            "expected": {"formal_rows": 228, "standalone_rows": 57,
                         "reranker_rows": 171, "candidate_lists": 57,
                         "pair_scores": 8550, "fresh_retrievals": 228},
            "wall_hours_max": MAX_WALL_HOURS, "execute_requires_explicit_flag": "--execute",
            "guard": {"poll_seconds": 1, "quiet_seconds": 30, "max_unit_attempts": MAX_UNIT_ATTEMPTS,
                      "owned_servers": [embedder, *[r for r in RERANKERS if r != "standalone"]],
                      "sequential_inference": True}}


def rank_query(corpus_matrix: np.ndarray, vector: np.ndarray, corpus: list[dict[str, Any]],
               qrels: dict[str, int]) -> tuple[list[dict[str, Any]], list[str], list[int]]:
    """Fresh full-corpus float32 cosine ranking, then qrels-membership Top50."""
    if corpus_matrix.shape[0] != len(corpus) or corpus_matrix.ndim != 2:
        raise RunnerError("corpus-vector matrix and frozen corpus dimensions disagree")
    if vector.ndim != 1 or vector.shape[0] != corpus_matrix.shape[1] or not np.isfinite(vector).all():
        raise RunnerError("fresh query vector has invalid shape or values")
    if not np.isfinite(corpus_matrix).all():
        raise RunnerError("verified corpus cache contains a nonfinite vector")
    similarities = np.asarray(corpus_matrix @ vector, dtype=np.float32)
    if not np.isfinite(similarities).all():
        raise RunnerError("fresh cosine result contains nonfinite values")
    doc_ids = [str(item["id"]) for item in corpus]
    ranking = scoring.stable_full_ranking(doc_ids, similarities.tolist())
    judged_ids = {str(doc_id) for doc_id in qrels}
    for entry in ranking:
        entry["judged"] = entry["doc_id"] in judged_ids
    candidates, original_ranks = scoring.filter_judged_top50(ranking, qrels)
    return ranking, candidates, original_ranks


def rank_full(corpus_matrix: np.ndarray, vector: np.ndarray,
              corpus: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Cosine and deterministic full sort only; qrels access is separate."""
    if corpus_matrix.shape[0] != len(corpus) or corpus_matrix.ndim != 2:
        raise RunnerError("corpus-vector matrix and frozen corpus dimensions disagree")
    if vector.ndim != 1 or vector.shape[0] != corpus_matrix.shape[1] or not np.isfinite(vector).all():
        raise RunnerError("fresh query vector has invalid shape or values")
    similarities = np.asarray(corpus_matrix @ vector, dtype=np.float32)
    if not np.isfinite(similarities).all():
        raise RunnerError("fresh cosine result contains nonfinite values")
    return scoring.stable_full_ranking([str(row["id"]) for row in corpus], similarities.tolist())


def filter_full_ranking(ranking: list[dict[str, Any]], qrels: dict[str, int]) -> tuple[list[str], list[int]]:
    for row in ranking:
        row["judged"] = row["doc_id"] in qrels
    return scoring.filter_judged_top50(ranking, qrels)


def candidate_row(run_id: str, embedder: str, query_id: str,
                  ranking: list[dict[str, Any]], candidate_ids: list[str],
                  original_ranks: list[int]) -> dict[str, Any]:
    top_entries = [entry for entry in ranking if entry["doc_id"] in set(candidate_ids)]
    # The filter preserves the complete-ranking order. This also checks that the
    # stored similarity hashes describe precisely the ordered judged Top50.
    if [entry["doc_id"] for entry in top_entries] != candidate_ids or len(top_entries) != 50:
        raise RunnerError("candidate similarity evidence is not aligned to Top50 IDs")
    return {
        "run_id": run_id, "protocol_id": "judged-top50-v1", "dataset_id": "acord-eng-eng",
        "embedder": embedder, "query_id": query_id,
        "filter_protocol": "judged-qrels-membership-v1", "candidate_ids": list(candidate_ids),
        "original_ranks": list(original_ranks),
        "ordered_candidate_sha256": scoring.ordered_candidate_hash(candidate_ids),
        "similarity_sha256": scoring.sha256_canonical([entry["similarity"] for entry in top_entries]),
        "source_ranking_sha256": scoring.ranked_entry_hash(ranking),
    }


def build_summary(run_id: str, rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Aggregate complete or partial config rows with type-7 timing quantiles."""
    groups: dict[str, list[dict[str, Any]]] = {f"{e}__{r}": [] for e in EMBEDDERS for r in RERANKERS}
    for row in rows:
        groups[row["config_id"]].append(row)
    summaries = []
    for config_id, group in groups.items():
        if not group:
            continue
        metrics = {}
        for name in group[0]["metrics"]:
            values = [row["metrics"][name] for row in group if row["metrics"][name] is not None]
            metrics[name] = {"mean": statistics.fmean(values) if values else None,
                             "valid_n": len(values)}
        times = {}
        for name in ("query_embedding", "retrieval", "evaluation_filter", "rerank", "total", "wall_total"):
            values = [float(row["times_ms"][name]) for row in group]
            times[name] = {"mean": statistics.fmean(values),
                           "p50": float(np.quantile(values, .5, method="linear")),
                           "p95": float(np.quantile(values, .95, method="linear")),
                           "n": len(values)}
        first = group[0]
        summaries.append({"run_id": run_id, "protocol_id": "judged-top50-v1",
                          "dataset_id": "acord-eng-eng", "config_id": config_id,
                          "embedder": first["embedder"], "reranker": first["reranker"],
                          "n": len(group), "failed": 0, "metrics": metrics, "times_ms": times,
                          "complete": len(group) == 57})
    return summaries


class GlobalBenchmarkLock:
    """Shared flock; deadline begins before any waiting and is never reset."""

    def __init__(self, path: Path, deadline_epoch: float, status: Callable[..., None]):
        self.path = Path(path)
        self.deadline_epoch = float(deadline_epoch)
        self.status = status
        self.handle = None

    def __enter__(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.handle = self.path.open("a+", encoding="utf-8")
        first = True
        while True:
            if time.time() >= self.deadline_epoch:
                raise DeadlineReached("original wall deadline reached while waiting for global benchmark lock")
            try:
                fcntl.flock(self.handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                self.handle.seek(0)
                self.handle.truncate()
                self.handle.write(json.dumps({"pid": os.getpid(), "acquired_epoch": time.time()}) + "\n")
                self.handle.flush()
                self.status("global_lock_acquired", lock_path=str(self.path))
                return self
            except BlockingIOError:
                if first:
                    self.status("waiting_for_global_lock", lock_path=str(self.path))
                    first = False
                time.sleep(1.0)

    def __exit__(self, exc_type, exc, tb):
        if self.handle is not None:
            try:
                self.handle.seek(0)
                self.handle.truncate()
                self.handle.write(json.dumps({"pid": os.getpid(), "released_epoch": time.time()}) + "\n")
                self.handle.flush()
            finally:
                fcntl.flock(self.handle.fileno(), fcntl.LOCK_UN)
                self.handle.close()
                self.handle = None


def _package_source_hashes(package_root: Path) -> dict[str, str]:
    result = {}
    for relative in EXECUTION_SOURCE_SCOPE:
        path = package_root / relative
        if path.is_file():
            result[relative] = file_sha(path)
        else:
            raise RunnerError(f"source input disappeared before freeze: {relative}")
    return result


def _build_environment(package_root: Path, audit: dict[str, Any]) -> dict[str, Any]:
    try:
        import numpy
        numpy_version = numpy.__version__
    except Exception:
        numpy_version = None
    return {
        "captured_at": datetime.now(ZoneInfo("Asia/Taipei")).isoformat(),
        "python": sys.version, "python_executable": sys.executable,
        "platform": platform.platform(), "machine": platform.machine(),
        "numpy": numpy_version,
        "live_hardware": audit.get("hardware_summary"),
        "llama_cpp_commit": read_json(package_root / "LIVE_RUNTIME_DEPENDENCY_AUDIT.json").get("git_commit"),
        "runtime_dependency_inventory_sha256": audit["runtime_dependency_audit_sha256"],
        "note": "Loopback HTTP transport is included in embedding/reranking stage times; transport/queue split is unavailable and recorded null.",
    }


def create_run_root(package_root: Path, workspace: Path, phase2_root: Path, output_root: Path,
                    batch: str, segment: str, mode: str, *, deadline_epoch: float,
                    full_manifest: dict[str, Any], audit: dict[str, Any], resume: bool = False,
                    preflight_evidence: Path | None = None) -> tuple[Path, dict[str, Any]]:
    batch_embedder = dict(BATCHES).get(batch)
    if mode == "preflight":
        model_ids = list(full_manifest["models"])
        run_leaf = output_root / "preflight" / segment
    else:
        if batch_embedder is None:
            raise RunnerError(f"unknown official batch {batch}")
        model_ids = [batch_embedder, "bge-reranker", "qwen-reranker-0.6b", "qwen-reranker-4b"]
        run_leaf = output_root / batch / segment
    if resume:
        run_dir = run_leaf
        if not run_dir.is_dir():
            raise RunnerError(f"--resume requires an existing run directory: {run_dir}")
        manifest = read_json(run_dir / "run-manifest.json")
        if manifest.get("mode") != mode or manifest.get("batch") != batch or manifest.get("segment") != segment:
            raise RunnerError("resume mode/batch/segment differs from the original run")
        original_deadline = float(manifest.get("deadline_epoch", 0))
        if abs(original_deadline - float(deadline_epoch)) > .001:
            deadline_epoch = original_deadline
        if time.time() >= deadline_epoch:
            raise DeadlineReached("original run deadline has expired; resume cannot extend it")
        source_hashes = manifest.get("package_source_sha256", {})
        current_source = _package_source_hashes(package_root)
        if current_source != source_hashes:
            raise RunnerError("frozen package source/code hashes changed; cannot resume this run")
        if manifest.get("audit_fingerprints") != {key: audit[key] for key in (
                "hash_audit_sha256", "runtime_dependency_audit_sha256", "hardware_audit_sha256")}:
            raise RunnerError("live model/runtime/hardware audit inputs changed since run start")
        if preflight_evidence is not None:
            check_preflight_compatibility(preflight_evidence, package_root, full_manifest, audit)
        return run_dir, manifest
    if run_leaf.exists():
        raise RunnerError(f"run output already exists; choose a new segment or use --resume: {run_leaf}")
    run_dir = run_leaf
    run_dir.mkdir(parents=True, exist_ok=False)
    data = read_json(package_root / "frozen-data/acord.json")
    protocol = read_json(package_root / "frozen-data/scoring-protocol.json")
    source_check = validate_source_data(package_root, phase2_root, data, protocol)
    copied_hashes = _copy_package_inputs(package_root, run_dir, model_ids=model_ids)
    env = _build_environment(package_root, audit)
    write_json_atomic(run_dir / "environment.json", env)
    copied_hashes["environment.json"] = file_sha(run_dir / "environment.json")
    config = {"mode": mode, "batch": batch, "embedder": batch_embedder,
              "protocol_id": "judged-top50-v1", "dataset_id": "acord-eng-eng",
              "rerankers": list(RERANKERS), "candidate_k": 50,
              "similarity": "normalized float32 cosine, descending; doc_id ascending tie-break",
              "candidate_filter": "qrels document membership before Top50; explicit grade 0 included",
              "query_ids": [str(row["id"]) for row in data["queries"]],
              "model_ids": model_ids, "runtime": full_manifest["server"]["runtime"],
              "timing": {"stages": ["query_embedding", "retrieval", "evaluation_filter", "rerank"],
                         "transport": "loopback HTTP included in embedding/rerank stage; separate transport/queue ms=null"}}
    write_json_atomic(run_dir / "config.json", config)
    copied_hashes["config.json"] = file_sha(run_dir / "config.json")
    run_id = f"acord-{mode}-{batch.lower()}-{datetime.now(ZoneInfo('Asia/Taipei')).strftime('%Y%m%d-%H%M%S')}-{uuid.uuid4().hex[:8]}"
    manifest = {
        "run_id": run_id, "protocol_id": "judged-top50-v1", "dataset_id": "acord-eng-eng",
        "batch": batch, "embedder": batch_embedder, "segment": segment, "mode": mode,
        "status": "prepared", "created_at": datetime.now(ZoneInfo("Asia/Taipei")).isoformat(),
        "deadline_epoch": float(deadline_epoch), "deadline_timezone": "epoch seconds; display Asia/Taipei",
        "deadline_source": "fixed before global-lock wait; --resume cannot change it",
        "package_source_sha256": _package_source_hashes(package_root),
        "frozen_files_sha256": copied_hashes,
        "audit_fingerprints": {key: audit[key] for key in (
            "hash_audit_sha256", "runtime_dependency_audit_sha256", "hardware_audit_sha256")},
        "source_validation": source_check,
        "preflight_evidence": None,
        "corpus_cache_sha256": {},
        "execution": {"inference_started": False, "global_lock": False,
                      "guard_started": False, "owned_server_pids": [],
                      "formal_accepted_rows": 0, "error_count": 0},
    }
    if mode == "official" and preflight_evidence:
        check_preflight_compatibility(preflight_evidence, package_root, full_manifest, audit)
        manifest["preflight_evidence"] = {
            "root": str(preflight_evidence.resolve()),
            "manifest_sha256": file_sha(preflight_evidence / "preflight-manifest.json"),
            "summary_sha256": file_sha(preflight_evidence / "preflight-complete.json"),
        }
    write_json_atomic(run_dir / "run-manifest.json", manifest)
    write_json_atomic(run_dir / "progress.json", {"run_id": run_id, "mode": mode, "status": "prepared",
                                                    "accepted_rows": 0, "updated_at": utc_now()})
    return run_dir, manifest


def _runtime_model(workspace: Path, row: dict[str, Any]) -> dict[str, Any]:
    result = dict(row)
    result["absolute_path"] = str(_safe_workspace_file(workspace, row["path_relative_to_gguf"]))
    return result


def _candidate_cache_evidence(package_root: Path,
                              reference: dict[str, dict[str, list[str]]]) -> dict[str, dict[str, Any]]:
    correction = read_json(package_root / "source-reference/data/matrix/acord-corrected.json")
    regressions = read_json(package_root / "runs/cache-regression-report.json").get("model_regressions", [])
    reg_by_model = {row["embedder"]: row for row in regressions}
    result = {}
    for embedder, by_query in reference.items():
        provenance = correction.get("provenance", {}).get(embedder)
        report = reg_by_model.get(embedder)
        if not isinstance(provenance, dict) or not isinstance(report, dict):
            raise RunnerError(f"historical accepted cache evidence missing for {embedder}")
        if report.get("original_top50_match_count") != 57 or report.get("judged_ranking_match_count") != 57:
            raise RunnerError(f"historical cache regression incomplete for {embedder}")
        result[embedder] = {
            "candidate_hashes": {qid: scoring.ordered_candidate_hash(ids) for qid, ids in by_query.items()},
            "cache_manifest_sha256": provenance.get("cache_manifest_sha256"),
            "model_sha256": provenance.get("model_sha256"),
            "regression_manifest_sha256": report.get("manifest_sha256"),
            "source_query_ids": 57,
        }
    return result


def check_preflight_compatibility(preflight_root: Path, package_root: Path,
                                  full_manifest: dict[str, Any], audit: dict[str, Any]) -> dict[str, Any]:
    preflight_root = Path(preflight_root).resolve()
    complete_path = preflight_root / "preflight-complete.json"
    manifest_path = preflight_root / "preflight-manifest.json"
    if not complete_path.is_file() or not manifest_path.is_file():
        raise RunnerError("official run requires a completed ten-model preflight run")
    complete = read_json(complete_path)
    manifest = read_json(manifest_path)
    if complete.get("status") != "passed" or len(complete.get("models", [])) != 10:
        raise RunnerError("preflight is incomplete or has a blocked model")
    if manifest.get("protocol_id") != "judged-top50-v1":
        raise RunnerError("preflight protocol differs from official protocol")
    current_source = _package_source_hashes(package_root)
    if manifest.get("package_source_sha256") != current_source:
        raise RunnerError("preflight package/source/code hash differs from current frozen runner")
    current_models = {k: v.get("sha256") for k, v in full_manifest.get("models", {}).items()}
    if manifest.get("model_sha256") != current_models:
        raise RunnerError("preflight model pins differ from current registry")
    expected_audit = {key: audit[key] for key in (
        "hash_audit_sha256", "runtime_dependency_audit_sha256", "hardware_audit_sha256")}
    if manifest.get("audit_fingerprints") != expected_audit:
        raise RunnerError("preflight live audit fingerprints differ from official run")
    if complete.get("protocol_id") != "judged-top50-v1" or complete.get("dataset_sha256") != file_sha(package_root / "frozen-data/acord.json"):
        raise RunnerError("preflight frozen dataset/protocol differs from current inputs")
    final_evidence = manifest.get("final_event_evidence")
    if not isinstance(final_evidence, dict) or final_evidence.get("guard_closed") is not True or complete.get("guard_closed") is not True:
        raise RunnerError("preflight lacks post-guard-close event-log evidence")
    traffic_path = preflight_root / "traffic-events.jsonl"
    server_rel = complete.get("server_events_file", "server-events.jsonl")
    server_path = preflight_root / server_rel
    request_path = preflight_root / "preflight-request-trace.jsonl"
    expected_hashes = {
        "traffic_events_sha256": file_sha(traffic_path),
        "server_events_sha256": file_sha(server_path),
        "request_trace_sha256": file_sha(request_path),
    }
    for key, digest in expected_hashes.items():
        if final_evidence.get(key) != digest:
            raise RunnerError(f"preflight manifest {key} does not match closed event evidence")
    complete_hashes = {
        "guard_events_sha256": expected_hashes["traffic_events_sha256"],
        "server_event_sha256": expected_hashes["server_events_sha256"],
        "request_trace_sha256": expected_hashes["request_trace_sha256"],
    }
    if any(complete.get(key) != digest for key, digest in complete_hashes.items()):
        raise RunnerError("preflight complete record event hashes do not match closed files")
    if complete.get("preflight_manifest_sha256") != file_sha(manifest_path):
        raise RunnerError("preflight completion does not pin its finalized manifest")
    return {"root": str(preflight_root), "manifest_sha256": file_sha(manifest_path),
            "complete_sha256": file_sha(complete_path), "model_count": 10,
            "status": "passed"}


def _save_server_event(path: Path, row: dict[str, Any]) -> None:
    append_jsonl(path, row)


def _ensure_server(core: Any, guard: owned_guard.OwnedTrafficGuard,
                   servers: dict[str, Any], *, workspace: Path, out: Path,
                   full_manifest: dict[str, Any], model_id: str, deadline: float,
                   server_event_path: Path) -> Any:
    existing = servers.get(model_id)
    if existing is not None and getattr(existing, "process", None) is not None and existing.process.poll() is None:
        return existing
    if existing is not None:
        try:
            runtime.stop_owned_server(guard, existing, model_id, server_event_path)
        finally:
            servers.pop(model_id, None)
    guard.check_environment()
    row = _runtime_model(workspace, full_manifest["models"][model_id])
    registry = row["registry"]
    mode = "embedding" if registry["kind"] == "embedding" else "rerank"
    server = runtime.start_owned_server(
        core, guard, out=out, model_id=model_id, model_path=Path(row["absolute_path"]),
        mode=mode, pooling=registry.get("pooling") or "last", deadline_epoch=deadline,
        event_path=server_event_path,
    )
    servers[model_id] = server
    return server


def warm_loaded_server(core: Any, guard: owned_guard.OwnedTrafficGuard, server: Any,
                       model_id: str, model: dict[str, Any], run_dir: Path) -> dict[str, Any] | None:
    """Issue an explicit nonformal fixture warmup once for each newly loaded server."""
    run_id = read_json(run_dir / "run-manifest.json")["run_id"]
    if getattr(server, "_acord_warmup_run_id", None) == run_id:
        return None
    query, positive, negative = runtime.fixed_fixtures()[0]
    unit_id = f"warmup/{model_id}/{uuid.uuid4()}"
    attempt = str(uuid.uuid4())
    evidence = {"run_id": run_id, "model_id": model_id,
                "model_sha256": model["sha256"], "unit_id": unit_id,
                "attempt_id": attempt, "warmup": True,
                "included_in_formal_timing": False}
    unit_started = False
    try:
        guard.wait_idle(guard.check_deadline)
        guard.begin_unit(unit_id)
        unit_started = True
        guard.check()
        started = time.monotonic_ns()
        if model["registry"]["kind"] == "embedding":
            prefix = model["registry"].get("query_prefix") or model["registry"].get("prompt", "")
            doc_prefix = model["registry"].get("document_prefix", "")
            vectors, _elapsed = core.embed(
                server, [prefix + query, doc_prefix + positive, doc_prefix + negative],
                int(model["registry"]["dimension"]))
            positive_score = float(vectors[0] @ vectors[1])
            negative_score = float(vectors[0] @ vectors[2])
            if not (np.isfinite(vectors).all() and positive_score > negative_score):
                raise RunnerError(f"embedding fixture warmup failed for {model_id}")
            evidence.update({"fixture_count": 1, "positive_score": positive_score,
                             "negative_score": negative_score, "positive_wins": True})
        else:
            distractors = [f"Fixed neutral distractor clause {i:02d}." for i in range(48)]
            order, _elapsed, scores = core.rerank(server, query, [positive, negative, *distractors])
            if len(order) != 50 or len(scores) != 50 or order[0] != 0 or scores[0] <= scores[1]:
                raise RunnerError(f"reranker fixture warmup failed for {model_id}")
            evidence.update({"fixture_count": 1, "positive_rank": order.index(0) + 1,
                             "positive_score": float(scores[0]),
                             "negative_score": float(scores[1]), "positive_wins": True})
        evidence["started_ns"] = started
        evidence["finished_ns"] = time.monotonic_ns()
        guard.finish_unit(unit_id)
        unit_started = False
        evidence["traffic_epoch"] = guard.epoch
        evidence["status"] = "passed"
        server._acord_warmup_run_id = run_id
        append_jsonl(run_dir / "warmup-events.jsonl", evidence)
        return evidence
    except BaseException as exc:
        guard_failure = _guard_interference_after_exception(guard, exc, unit_started=unit_started)
        try:
            guard.abort_unit(unit_id, f"{type(exc).__name__}: {exc}")
        except Exception:
            pass
        evidence.update({"status": "rejected", "failure": f"{type(exc).__name__}: {exc}",
                         "finished_ns": time.monotonic_ns()})
        if isinstance(guard_failure, owned_guard.Interference):
            evidence["guard_interference"] = str(guard_failure)
        elif isinstance(guard_failure, owned_guard.DeadlineExceeded):
            evidence["deadline_failure"] = str(guard_failure)
        try:
            append_jsonl(run_dir / "warmup-events.jsonl", evidence)
        except Exception:
            pass
        if guard_failure is not None and guard_failure is not exc:
            raise guard_failure from exc
        raise


def _guard_interference_after_exception(guard: Any, exc: BaseException, *,
                                        unit_started: bool) -> owned_guard.Interference | owned_guard.DeadlineExceeded | None:
    """Reclassify a failed HTTP operation only when the guard confirms unit invalidation.

    A loopback request can fail because fail-closed monitoring has already stopped
    its owned server. Preserve the transport exception as attempt evidence, but
    let the caller retry the whole unit when an independent guard check confirms
    that the unit's traffic epoch is invalid. Ordinary transport faults remain
    fatal and are never retried by this helper.
    """
    if isinstance(exc, owned_guard.Interference):
        return exc
    if not unit_started:
        return None
    try:
        guard.check()
    except owned_guard.Interference as guard_exc:
        return guard_exc
    except owned_guard.DeadlineExceeded as deadline_exc:
        return deadline_exc
    return None


def _stop_server(guard: owned_guard.OwnedTrafficGuard, servers: dict[str, Any], model_id: str,
                 event_path: Path) -> None:
    server = servers.get(model_id)
    if server is not None:
        runtime.stop_owned_server(guard, server, model_id, event_path)
        servers.pop(model_id, None)


def guarded_preflight_call(guard: owned_guard.OwnedTrafficGuard, unit_id: str,
                           operation: Callable[[], Any], *,
                           prepare: Callable[[], Any] | None = None,
                           event_path: Path | None = None) -> tuple[Any, int]:
    """Run a nonformal audit/smoke unit, retrying the entire unit on interference."""
    last_error = None
    for attempt in range(1, MAX_UNIT_ATTEMPTS + 1):
        guard.wait_idle(guard.check_deadline)
        attempt_id = f"{attempt}-{uuid.uuid4().hex[:8]}"
        current_id = f"{unit_id}/attempt-{attempt_id}"
        started = False
        try:
            if prepare is not None:
                prepare()
            guard.wait_idle(guard.check_deadline)
            guard.begin_unit(current_id)
            started = True
            result = operation()
            guard.finish_unit(current_id)
            return result, attempt
        except Exception as exc:
            interference = exc if isinstance(exc, owned_guard.Interference) else None
            if interference is None:
                # A request can fail because the guard killed its owned server
                # while the HTTP call was blocked. Reclassify only if the guard
                # independently confirms an invalidated unit; ordinary transport
                # faults remain ordinary failures.
                try:
                    guard.check()
                except owned_guard.Interference as guard_exc:
                    interference = guard_exc
                except owned_guard.DeadlineExceeded:
                    raise
            if interference is None:
                raise
            last_error = str(interference)
            if started:
                try:
                    guard.abort_unit(current_id, last_error)
                except Exception:
                    pass
            if event_path is not None:
                append_jsonl(event_path, {
                    "unit_id": unit_id, "attempt_id": attempt_id,
                    "status": "interference_retry" if attempt < MAX_UNIT_ATTEMPTS else "interference_exhausted",
                    "reason": last_error, "error_type": type(exc).__name__,
                    "request_trace": getattr(exc, "trace", None),
                    "time": utc_now(),
                })
            if attempt >= MAX_UNIT_ATTEMPTS:
                raise RunnerError(f"preflight unit retry limit reached: {unit_id}") from exc
    raise RunnerError(f"preflight unit failed without result: {unit_id}: {last_error}")


def run_preflight_models(package_root: Path, workspace: Path, run_dir: Path,
                         full_manifest: dict[str, Any], audit: dict[str, Any],
                         data: dict[str, Any], reference: dict[str, dict[str, list[str]]],
                         deadline: float, guard: owned_guard.OwnedTrafficGuard,
                         core: Any) -> dict[str, Any]:
    """Audit and smoke all ten pinned models before any official batch."""
    model_ids = list(full_manifest["models"])
    source_hashes = _package_source_hashes(package_root)
    preflight_manifest = {
        "run_id": read_json(run_dir / "run-manifest.json")["run_id"],
        "protocol_id": "judged-top50-v1", "dataset_id": "acord-eng-eng",
        "package_source_sha256": source_hashes,
        "model_sha256": {k: v["sha256"] for k, v in full_manifest["models"].items()},
        "audit_fingerprints": {key: audit[key] for key in (
            "hash_audit_sha256", "runtime_dependency_audit_sha256", "hardware_audit_sha256")},
        "dataset_sha256": file_sha(package_root / "frozen-data/acord.json"),
        "reference_archive_sha256": file_sha(package_root / "source-reference/acord-corrected-rankings.zip"),
        "deadline_epoch": deadline,
    }
    write_json_atomic(run_dir / "preflight-manifest.json", preflight_manifest)
    q0 = data["queries"][0]
    qid = str(q0["id"])
    doc_by_id = {str(row["id"]): row for row in data["corpus"]}
    cache_evidence = _candidate_cache_evidence(package_root, reference)
    results = []
    servers: dict[str, Any] = {}
    event_path = run_dir / "server-events.jsonl"
    smoke_req_path = run_dir / "preflight-request-trace.jsonl"
    preflight_attempt_path = run_dir / "preflight-attempts.jsonl"

    def check() -> None:
        guard.check_deadline()

    for model_id in model_ids:
        check()
        model_dir = run_dir / "model-preflight" / model_id
        record_path = model_dir / "preflight.json"
        if record_path.is_file():
            saved = read_json(record_path)
            if saved.get("status") == "passed" and saved.get("model_sha256") == full_manifest["models"][model_id]["sha256"]:
                results.append(saved)
                continue
        model_dir.mkdir(parents=True, exist_ok=True)
        model = _runtime_model(workspace, full_manifest["models"][model_id])
        model_state: dict[str, Any] = {"server": None, "loaded_ms": [], "warmups": []}

        def prepare_server() -> None:
            guard.wait_idle(guard.check_deadline)
            old = servers.get(model_id)
            active = _ensure_server(core, guard, servers, workspace=workspace, out=run_dir,
                                    full_manifest=full_manifest, model_id=model_id,
                                    deadline=deadline, server_event_path=event_path)
            if active is not old:
                model_state["loaded_ms"].append(float(active.load_ms))
            warmup = warm_loaded_server(core, guard, active, model_id, model, run_dir)
            if warmup is not None:
                model_state["warmups"].append(warmup)
            model_state["server"] = active

        token_audit_elapsed = []

        def do_token_audit():
            started = time.monotonic_ns()
            try:
                return runtime.detailed_token_audit(
                    core, model_state["server"], model_id=model_id, model=model, data=data, out=run_dir,
                    check=guard.check,
                    candidate_lists_by_embedder=reference if model["registry"]["kind"] == "reranker" else None,
                    corpus_cache=cache_evidence if model["registry"]["kind"] == "reranker" else None,
                )
            finally:
                token_audit_elapsed.append((time.monotonic_ns() - started) / 1e6)

        token_summary, token_attempts = guarded_preflight_call(
            guard, f"preflight/token-audit/{model_id}", do_token_audit,
            prepare=prepare_server, event_path=preflight_attempt_path)
        token_elapsed_ms = sum(token_audit_elapsed)
        if model["registry"]["kind"] == "embedding":
            def do_smoke():
                server = model_state["server"]
                fixture_row = runtime.embedding_smoke(core, server, model_id, model["registry"], guard.check)
                # This new query embedding/search/filter path uses an actual fixed ACORD ID.
                vector, trace_row, embed_ms = runtime.traced_embedding(
                    server, query=q0,
                    prefix=model["registry"].get("query_prefix") or model["registry"].get("prompt", ""),
                    dimension=int(model["registry"]["dimension"]), model_id=model_id,
                    model_sha=model["sha256"], run_id=preflight_manifest["run_id"],
                    config_id=f"{model_id}__preflight-smoke", attempt_id=f"preflight-{model_id}")
                matrix, corpus_hash, cache_provenance = load_verified_corpus_cache(
                    workspace, package_root, model_id, data, run_dir=None,
                    phase2_root=workspace / "embedding-study-phase2-20261023")
                qrels = data["qrels"][qid]
                rank, ids, _original_ranks = rank_query(matrix, vector, data["corpus"], qrels)
                if ids != reference[model_id][qid]:
                    raise CandidateDrift(
                        f"{model_id}/{qid}: preflight ACORD candidate drift versus public correction",
                        {"query_id": qid, "observed": ids, "expected": reference[model_id][qid],
                         "ranking_sha256": scoring.ranked_entry_hash(rank),
                         "corpus_cache_sha256": corpus_hash, "cache_provenance": cache_provenance})
                return fixture_row, {"status": "passed", "query_id": qid, "embedding_ms": embed_ms,
                                     "query_vector_sha256": trace_row["output_vector_sha256"],
                                     "candidate_hash": scoring.ordered_candidate_hash(ids),
                                     "candidate_matches_reference": True,
                                     "corpus_cache_sha256": corpus_hash,
                                     "ranking_sha256": scoring.ranked_entry_hash(rank),
                                     "timing_included_in_official": False}, trace_row

            (fixture, smoke, trace), smoke_attempts = guarded_preflight_call(
                guard, f"preflight/smoke/{model_id}", do_smoke,
                prepare=prepare_server, event_path=preflight_attempt_path)
            trace["preflight_only"] = True
            append_jsonl(smoke_req_path, trace)
        else:
            def do_smoke():
                server = model_state["server"]
                fixture_row = runtime.reranker_smoke(core, server, model_id, guard.check)
                candidate_ids = reference["qwen-4b"][qid]
                query_docs = [doc_by_id[doc_id] for doc_id in candidate_ids]
                _scores, trace_row, smoke_ms = runtime.traced_rerank(
                    server, query=q0, documents=query_docs, model_id=model_id,
                    model_sha=model["sha256"], run_id=preflight_manifest["run_id"],
                    config_id=f"preflight-{model_id}", attempt_id=f"preflight-{model_id}")
                return fixture_row, {"status": "passed", "query_id": qid,
                                     "embedder_candidate_source": "qwen-4b", "candidate_count": 50,
                                     "candidate_hash": scoring.ordered_candidate_hash(candidate_ids),
                                     "rerank_ms": smoke_ms, "timing_included_in_official": False}, trace_row

            (fixture, smoke, trace), smoke_attempts = guarded_preflight_call(
                guard, f"preflight/smoke/{model_id}", do_smoke,
                prepare=prepare_server, event_path=preflight_attempt_path)
            trace["preflight_only"] = True
            append_jsonl(smoke_req_path, trace)
        _stop_server(guard, servers, model_id, event_path)
        record = {
            "model_id": model_id, "model_sha256": model["sha256"],
            "status": "passed", "loaded_ms_excluded": sum(model_state["loaded_ms"]),
            "server_loads_excluded_ms": model_state["loaded_ms"],
            "warmups": model_state["warmups"],
            "token_audit": token_summary,
            "token_audit_elapsed_ms_excluded": token_elapsed_ms,
            "token_audit_guard_attempts": token_attempts,
            "smoke_guard_attempts": smoke_attempts,
            "fixture_smoke": fixture, "acord_smoke": smoke,
            "smoke_requests_file": str(smoke_req_path.relative_to(run_dir)),
            "status_at": utc_now(),
        }
        write_json_atomic(record_path, record)
        results.append(record)
        write_json_atomic(run_dir / "preflight-progress.json", {
            "status": "running", "passed_models": [row["model_id"] for row in results],
            "passed_count": len(results), "expected_count": 10,
            "updated_at": utc_now(), "deadline_epoch": deadline,
        })
        check()
    if len(results) != 10 or any(row.get("status") != "passed" for row in results):
        raise RunnerError("ten-model preflight did not pass all required models")
    # Final event-log hashes are written only after execute() stops every owned
    # server and closes/joins the guard. At this point these are pending evidence.
    pending = {"status": "validated_pending_guard_close", "protocol_id": "judged-top50-v1",
                "run_id": preflight_manifest["run_id"],
                "dataset_sha256": file_sha(package_root / "frozen-data/acord.json"),
                "models": [{"model_id": row["model_id"], "model_sha256": row["model_sha256"],
                            "token_status": row["token_audit"]["status"],
                            "fixture_status": row["fixture_smoke"]["status"],
                            "acord_smoke_status": row["acord_smoke"]["status"]} for row in results],
                "request_trace_sha256": file_sha(smoke_req_path),
                "server_events_file": str(event_path.relative_to(run_dir)),
                "traffic_events_file": "traffic-events.jsonl",
                "validated_at": datetime.now(ZoneInfo("Asia/Taipei")).isoformat()}
    write_json_atomic(run_dir / "preflight-validation-pending.json", pending)
    return pending


def _primary_ranking_hash(commits: dict[str, dict[str, Any]], run_dir: Path,
                          embedder: str, query_id: str) -> str | None:
    key = _attempt_key(f"{embedder}__standalone", query_id)
    pointer = commits.get(key)
    if not pointer:
        return None
    attempt = run_dir / pointer["attempt"]
    row = read_json(attempt / "full-ranking.json")
    return row["ranking_sha256"]


def _accepted_candidate(commits: dict[str, dict[str, Any]], run_dir: Path,
                        embedder: str, query_id: str) -> dict[str, Any] | None:
    pointer = commits.get(_attempt_key(f"{embedder}__standalone", query_id))
    if not pointer:
        return None
    return read_json((run_dir / pointer["attempt"]) / "candidate-list.json")


def _store_failed_attempt(run_dir: Path, attempt_dir: Path, attempt_id: str,
                          config_id: str, query_id: str, reason: str,
                          traces: list[dict[str, Any]], started_ns: int | None,
                          extra: dict[str, Any] | None = None) -> None:
    attempt_dir.mkdir(parents=True, exist_ok=True)
    write_json_atomic(attempt_dir / "request-traces.json", traces)
    validity = {"status": "rejected", "run_id": read_json(run_dir / "run-manifest.json")["run_id"],
                "attempt_id": attempt_id, "config_id": config_id, "query_id": query_id,
                "reason": reason, "started_ns": started_ns, "failed_at": utc_now(),
                **(extra or {})}
    write_json_atomic(attempt_dir / "validity.json", validity)
    append_jsonl(run_dir / "failed-attempts.jsonl", validity)


def measure_query(run_dir: Path, manifest: dict[str, Any], commits: dict[str, dict[str, Any]],
                  *, embedder: str, reranker: str, query: dict[str, Any],
                  corpus: list[dict[str, Any]], doc_by_id: dict[str, dict[str, Any]],
                  qrels: dict[str, int], corpus_matrix: np.ndarray, corpus_hash: str,
                  embed_server: Any, rerank_server: Any | None, embed_model: dict[str, Any],
                  rerank_model: dict[str, Any] | None, reference_candidates: list[str],
                  guard: owned_guard.OwnedTrafficGuard,
                  ensure_servers: Callable[[], tuple[Any, Any | None]]) -> dict[str, Any]:
    """Perform one fresh embedding→search→filter→optional-rerank guarded unit."""
    run_id = manifest["run_id"]
    query_id = str(query["id"])
    config_id = f"{embedder}__{reranker}"
    attempt_id = str(uuid.uuid4())
    attempt_dir = _attempt_path(run_dir, config_id, query_id, attempt_id)
    traces: list[dict[str, Any]] = []
    unit_started = False
    mono_start_ns = None
    try:
        guard.wait_idle(guard.check_deadline)
        embed_server, rerank_server = ensure_servers()
        guard.begin_unit(f"{config_id}/{query_id}/{attempt_id}")
        unit_started = True
        guard.check()
        attempt_dir.mkdir(parents=True, exist_ok=False)
        mono_start_ns = time.monotonic_ns()
        prefix = embed_model["registry"].get("query_prefix") or embed_model["registry"].get("prompt", "")
        stage_start = time.perf_counter_ns()
        vector, embed_trace, _http_ms = runtime.traced_embedding(
            embed_server, query=query, prefix=prefix,
            dimension=int(embed_model["registry"]["dimension"]),
            model_id=embedder, model_sha=embed_model["sha256"],
            run_id=run_id, config_id=config_id, attempt_id=attempt_id)
        traces.append(embed_trace)
        guard.check()
        query_embedding_ms = (time.perf_counter_ns() - stage_start) / 1e6

        stage_start = time.perf_counter_ns()
        ranking = rank_full(corpus_matrix, vector, corpus)
        retrieval_ms = (time.perf_counter_ns() - stage_start) / 1e6
        guard.check()

        stage_start = time.perf_counter_ns()
        candidate_ids, original_ranks = filter_full_ranking(ranking, qrels)
        if reranker == "standalone":
            final_doc_ids = [entry["doc_id"] for entry in ranking if entry["judged"]]
        evaluation_filter_ms = (time.perf_counter_ns() - stage_start) / 1e6
        guard.check()

        # Hashing/checkpoint comparison is audit work inside wall_total, not part
        # of the measured qrels filter stage.
        candidate_sha = scoring.ordered_candidate_hash(candidate_ids)
        ranking_sha = scoring.ranked_entry_hash(ranking)
        if candidate_ids != reference_candidates:
            drift = {"query_id": query_id, "expected_candidate_ids": reference_candidates,
                     "observed_candidate_ids": candidate_ids, "ordered_candidate_sha256": candidate_sha,
                     "ranking_sha256": ranking_sha, "ranking": ranking,
                     "note": "fresh full similarity ranking was not substituted or silently corrected"}
            write_json_atomic(attempt_dir / "candidate-drift-evidence.json", drift)
            raise CandidateDrift(f"{embedder}/{query_id}: fresh candidates drift from pinned correction", drift)
        primary_candidate = _accepted_candidate(commits, run_dir, embedder, query_id)
        if primary_candidate and candidate_sha != primary_candidate["ordered_candidate_sha256"]:
            raise CandidateDrift(f"{config_id}/{query_id}: candidate set differs from committed standalone", {
                "query_id": query_id, "candidate_ids": candidate_ids,
                "standalone_candidate_ids": primary_candidate["candidate_ids"],
                "ranking_sha256": ranking_sha, "ranking": ranking})
        guard.check()

        candidate = candidate_row(run_id, embedder, query_id, ranking, candidate_ids, original_ranks)
        score_rows: list[dict[str, Any]] = []
        rerank_request_id = None
        if reranker == "standalone":
            rerank_ms = 0.0
        else:
            if rerank_server is None or rerank_model is None:
                raise RunnerError("reranker config has no loaded owned reranker server")
            ordered_docs = [doc_by_id[doc_id] for doc_id in candidate_ids]
            stage_start = time.perf_counter_ns()
            guard.check()
            scores, rerank_trace, _http_ms = runtime.traced_rerank(
                rerank_server, query=query, documents=ordered_docs,
                model_id=reranker, model_sha=rerank_model["sha256"],
                run_id=run_id, config_id=config_id, attempt_id=attempt_id)
            traces.append(rerank_trace)
            rerank_request_id = rerank_trace["id"]
            guard.check()
            final_indices = sorted(range(50), key=lambda i: (-scores[i], candidate_ids[i]))
            final_doc_ids = [candidate_ids[i] for i in final_indices]
            for idx, (doc_id, score) in enumerate(zip(candidate_ids, scores)):
                score_rows.append({
                    "run_id": run_id, "protocol_id": "judged-top50-v1", "config_id": config_id,
                    "embedder": embedder, "reranker": reranker, "query_id": query_id,
                    "candidate_index": idx, "doc_id": doc_id, "score": float(score),
                    "model_sha256": rerank_model["sha256"],
                    "ordered_candidate_sha256": candidate_sha, "finite": math.isfinite(float(score)),
                })
            rerank_ms = (time.perf_counter_ns() - stage_start) / 1e6
        metrics = scoring.evaluate_ranking(final_doc_ids, candidate_ids, qrels)
        mono_end_ns = time.monotonic_ns()
        wall_total_ms = _elapsed_ms(mono_start_ns, mono_end_ns)
        stage_times = {
            "query_embedding": float(query_embedding_ms), "retrieval": float(retrieval_ms),
            "evaluation_filter": float(evaluation_filter_ms), "rerank": float(rerank_ms),
        }
        total_ms = sum(stage_times.values())
        times_ms = {**stage_times, "total": float(total_ms), "wall_total": float(wall_total_ms),
                    "transport_ms": None, "queue_ms": None,
                    "transport_queue_note": "Loopback HTTP transport is included in query_embedding/rerank; transport and queue were not separately measured."}
        if (not all(math.isfinite(v) and v >= 0 for v in stage_times.values()) or
                not all(math.isfinite(float(metrics[key])) for key in ("ndcg@5", "ndcg@10", "top1", "mrr@10", "hit@10"))):
            raise RunnerError("formal stage timing or required quality metric is nonfinite")
        # Every accepted official inference request must be enclosed by the wall interval.
        if not traces or any(not (mono_start_ns <= trace["started_ns"] < trace["finished_ns"] <= mono_end_ns)
                             for trace in traces):
            raise RunnerError("formal request trace falls outside its measured unit")
        guard.finish_unit(f"{config_id}/{query_id}/{attempt_id}")
        unit_started = False

        result = {
            "run_id": run_id, "protocol_id": "judged-top50-v1", "dataset_id": "acord-eng-eng",
            "config_id": config_id, "embedder": embedder, "reranker": reranker,
            "query_id": query_id, "candidate_sha256": candidate_sha,
            "final_doc_ids": final_doc_ids, "metrics": metrics, "times_ms": times_ms,
            "status": "ok", "truncated": False,
            "provenance": {"query_embedding": "fresh_inference",
                           "rerank": "not_applicable" if reranker == "standalone" else "fresh_inference",
                           "embedding_request_id": embed_trace["id"],
                           "rerank_request_id": rerank_request_id, "attempt_id": attempt_id,
                           "candidate_protocol": "judged-top50-v1",
                           "corpus_cache_sha256": corpus_hash},
        }
        timing = {"run_id": run_id, "protocol_id": "judged-top50-v1", "config_id": config_id,
                  "embedder": embedder, "reranker": reranker, "query_id": query_id,
                  "warmup": False, "repeat_id": 0, "source": "fresh_inference",
                  "times_ms": times_ms, "monotonic_start_ns": mono_start_ns,
                  "monotonic_end_ns": mono_end_ns}
        primary_hash = _primary_ranking_hash(commits, run_dir, embedder, query_id)
        retrieval = {"run_id": run_id, "protocol_id": "judged-top50-v1", "dataset_id": "acord-eng-eng",
                     "config_id": config_id, "embedder": embedder, "reranker": reranker,
                     "query_id": query_id, "embedding_request_id": embed_trace["id"],
                     "query_vector_sha256": embed_trace["output_vector_sha256"],
                     "corpus_cache_sha256": corpus_hash, "corpus_documents": len(corpus),
                     "full_ranking_sha256": ranking_sha, "ordered_candidate_sha256": candidate_sha,
                     "candidate_count": len(candidate_ids), "fresh_search": True,
                     "ranking": ranking if primary_hash is not None and primary_hash != ranking_sha else None}
        if reranker == "standalone":
            # Its own fresh search is the primary ranking if no commit existed.
            retrieval["ranking"] = None
        attempt_dir.mkdir(parents=True, exist_ok=True)
        write_json_atomic(attempt_dir / "query-result.json", result)
        write_json_atomic(attempt_dir / "timing-result.json", timing)
        write_json_atomic(attempt_dir / "retrieval-attempt.json", retrieval)
        write_json_atomic(attempt_dir / "request-traces.json", traces)
        write_json_atomic(attempt_dir / "reranker-scores.json", score_rows)
        if reranker == "standalone":
            write_json_atomic(attempt_dir / "candidate-list.json", candidate)
            full_row = {"run_id": run_id, "protocol_id": "judged-top50-v1",
                        "dataset_id": "acord-eng-eng", "embedder": embedder,
                        "query_id": query_id, "query_vector_sha256": embed_trace["output_vector_sha256"],
                        "ranking": ranking, "ranking_sha256": ranking_sha,
                        "provenance": {"fresh_search": True, "corpus_cache_sha256": corpus_hash,
                                       "source": "query_embedding_request"}}
            write_json_atomic(attempt_dir / "full-ranking.json", full_row)
        validity = {"status": "accepted", "run_id": run_id, "attempt_id": attempt_id,
                    "config_id": config_id, "query_id": query_id,
                    "traffic_epoch": guard.epoch, "candidate_hash": candidate_sha,
                    "query_result_sha256": file_sha(attempt_dir / "query-result.json"),
                    "timing_sha256": file_sha(attempt_dir / "timing-result.json"),
                    "retrieval_sha256": file_sha(attempt_dir / "retrieval-attempt.json"),
                    "request_traces_sha256": file_sha(attempt_dir / "request-traces.json"),
                    "reranker_scores_sha256": file_sha(attempt_dir / "reranker-scores.json"),
                    "finished_at": utc_now()}
        if reranker == "standalone":
            validity["candidate_sha256"] = file_sha(attempt_dir / "candidate-list.json")
            validity["full_ranking_sha256"] = file_sha(attempt_dir / "full-ranking.json")
        validity_path = attempt_dir / "validity.json"
        write_json_atomic(validity_path, validity)
        return {"attempt_id": attempt_id, "attempt_dir": attempt_dir,
                "result": result, "timing": timing, "retrieval": retrieval,
                "traces": traces, "scores": score_rows,
                "candidate": candidate if reranker == "standalone" else None,
                "full_ranking": full_row if reranker == "standalone" else None,
                "validity_sha256": file_sha(validity_path)}
    except CandidateDrift as exc:
        _store_failed_attempt(run_dir, attempt_dir, attempt_id, config_id, query_id,
                              str(exc), traces, mono_start_ns,
                              {"failure_kind": "candidate_drift", "evidence": exc.evidence})
        if unit_started:
            try:
                guard.abort_unit(f"{config_id}/{query_id}/{attempt_id}", str(exc))
            except Exception:
                pass
        raise
    except BaseException as exc:
        guard_failure = _guard_interference_after_exception(guard, exc, unit_started=unit_started)
        failed_traces = list(traces)
        error_trace = getattr(exc, "trace", None)
        if isinstance(error_trace, dict) and not any(row.get("id") == error_trace.get("id") for row in failed_traces):
            failed_traces.append(error_trace)
        try:
            _store_failed_attempt(run_dir, attempt_dir, attempt_id, config_id, query_id,
                                  f"{type(exc).__name__}: {exc}", failed_traces, mono_start_ns,
                                  {"failure_kind": "guard_interference" if isinstance(guard_failure, owned_guard.Interference) else
                                                   "deadline" if isinstance(guard_failure, owned_guard.DeadlineExceeded) else "execution_error",
                                   "original_exception_type": type(exc).__name__,
                                   "original_exception": str(exc),
                                   "original_http_trace": error_trace,
                                   "guard_interference": str(guard_failure) if isinstance(guard_failure, owned_guard.Interference) else None,
                                   "deadline_failure": str(guard_failure) if isinstance(guard_failure, owned_guard.DeadlineExceeded) else None})
        except Exception:
            pass
        if unit_started:
            try:
                guard.abort_unit(f"{config_id}/{query_id}/{attempt_id}", f"{type(exc).__name__}: {exc}")
            except Exception:
                pass
        if guard_failure is not None and guard_failure is not exc:
            raise guard_failure from exc
        raise


def commit_query(run_dir: Path, manifest: dict[str, Any], commits: dict[str, dict[str, Any]],
                 bundle: dict[str, Any]) -> None:
    result = bundle["result"]
    key = _attempt_key(result["config_id"], result["query_id"])
    if key in commits:
        raise RunnerError(f"query already committed: {key}")
    pointer = {"attempt": str(bundle["attempt_dir"].relative_to(run_dir)),
               "attempt_id": bundle["attempt_id"], "query_id": result["query_id"],
               "config_id": result["config_id"], "validity_sha256": bundle["validity_sha256"],
               "committed_at": utc_now()}
    commits[key] = pointer
    _atomic_committed(run_dir / "committed.json", commits)
    # Append only after the atomic pointer. A crash here is repaired by rebuilding
    # all aggregate JSONL from accepted pointers on resume.
    _append_bundle(run_dir, bundle)
    manifest["status"] = "running"
    manifest["execution"]["inference_started"] = True
    manifest["execution"]["formal_accepted_rows"] = len(commits)
    manifest["execution"]["error_count"] = len(read_jsonl(run_dir / "failed-attempts.jsonl"))
    write_json_atomic(run_dir / "run-manifest.json", manifest)
    write_progress(run_dir, manifest, commits, "official_running",
                   {"config_id": result["config_id"], "query_id": result["query_id"]},
                   manifest["execution"]["error_count"])


def run_official_batch(package_root: Path, workspace: Path, phase2_root: Path,
                       run_dir: Path, manifest: dict[str, Any],
                       full_manifest: dict[str, Any], audit: dict[str, Any],
                       preflight_evidence: Path,
                       guard: owned_guard.OwnedTrafficGuard,
                       core: Any) -> dict[str, Any]:
    batch = manifest["batch"]
    embedder = dict(BATCHES)[batch]
    run_id = manifest["run_id"]
    data = read_json(run_dir / "frozen-data/acord.json")
    protocol = read_json(run_dir / "frozen-data/scoring-protocol.json")
    validate_frozen_data(data, protocol)
    reference, reference_evidence = read_public_candidate_lists(run_dir, data)
    if embedder not in reference:
        raise RunnerError("pinned corrected candidate reference lacks this embedder")

    corpus_matrix, corpus_hash, cache_provenance = load_verified_corpus_cache(
        workspace, package_root, embedder, data, run_dir=None, phase2_root=phase2_root)
    expected_cache_hash = manifest.get("corpus_cache_sha256", {}).get(embedder)
    if expected_cache_hash is not None and expected_cache_hash != corpus_hash:
        raise RunnerError("resumed corpus cache hash differs from the frozen run manifest")
    manifest.setdefault("corpus_cache_sha256", {})[embedder] = corpus_hash
    write_json_atomic(run_dir / "corpus-cache-evidence.json", {
        "embedder": embedder, "corpus_cache_sha256": corpus_hash,
        "cache_provenance": cache_provenance,
        "reference_candidate_evidence": reference_evidence,
        "usage": "read-only corpus vectors used for fresh query embeddings and full-corpus search; historical query vectors are read only by the cache compatibility validator and never used in formal inference or retrieval",
    })
    write_json_atomic(run_dir / "run-manifest.json", manifest)

    doc_by_id = {str(row["id"]): row for row in data["corpus"]}
    query_by_id = {str(row["id"]): row for row in data["queries"]}
    query_order = [str(row["id"]) for row in data["queries"]]
    model_ids = [embedder, *[name for name in RERANKERS if name != "standalone"]]
    run_models = {name: _runtime_model(workspace, full_manifest["models"][name]) for name in model_ids}
    commits = load_commits(run_dir)
    if commits:
        rebuild_aggregates(run_dir, commits)
    write_progress(run_dir, manifest, commits, "official_running")

    servers: dict[str, Any] = {}
    event_path = run_dir / "server-events.jsonl"
    try:
        for reranker in RERANKERS:
            config_id = f"{embedder}__{reranker}"
            if reranker != "standalone":
                guard.wait_idle(guard.check_deadline)
                _ensure_server(core, guard, servers, workspace=workspace, out=run_dir,
                               full_manifest=full_manifest, model_id=reranker,
                               deadline=manifest["deadline_epoch"], server_event_path=event_path)
            for query_id in query_order:
                key = _attempt_key(config_id, query_id)
                if key in commits:
                    continue
                query = query_by_id[query_id]
                used_attempts = len(list((run_dir / "attempts" / config_id / query_id).glob("*/validity.json")))
                last_error = None
                while used_attempts < MAX_UNIT_ATTEMPTS:
                    if time.time() >= manifest["deadline_epoch"]:
                        raise DeadlineReached("fixed official wall deadline reached")

                    def ensure_servers():
                        embedding = _ensure_server(
                            core, guard, servers, workspace=workspace, out=run_dir,
                            full_manifest=full_manifest, model_id=embedder,
                            deadline=manifest["deadline_epoch"], server_event_path=event_path)
                        warm_loaded_server(core, guard, embedding, embedder, run_models[embedder], run_dir)
                        rerank = None
                        if reranker != "standalone":
                            rerank = _ensure_server(
                                core, guard, servers, workspace=workspace, out=run_dir,
                                full_manifest=full_manifest, model_id=reranker,
                                deadline=manifest["deadline_epoch"], server_event_path=event_path)
                            warm_loaded_server(core, guard, rerank, reranker, run_models[reranker], run_dir)
                        return embedding, rerank

                    try:
                        bundle = measure_query(
                            run_dir, manifest, commits, embedder=embedder, reranker=reranker,
                            query=query, corpus=data["corpus"], doc_by_id=doc_by_id,
                            qrels=data["qrels"][query_id], corpus_matrix=corpus_matrix,
                            corpus_hash=corpus_hash, embed_server=servers.get(embedder),
                            rerank_server=servers.get(reranker), embed_model=run_models[embedder],
                            rerank_model=run_models.get(reranker),
                            reference_candidates=reference[embedder][query_id], guard=guard,
                            ensure_servers=ensure_servers)
                        commit_query(run_dir, manifest, commits, bundle)
                        used_attempts += 1
                        last_error = None
                        break
                    except owned_guard.Interference as exc:
                        used_attempts += 1
                        last_error = str(exc)
                        write_progress(run_dir, manifest, commits, "waiting_for_traffic_quiet",
                                       {"config_id": config_id, "query_id": query_id,
                                        "attempts": used_attempts, "last_guard_error": last_error},
                                       len(read_jsonl(run_dir / "failed-attempts.jsonl")))
                        append_jsonl(run_dir / "traffic-interruptions.jsonl", {
                            "run_id": run_id, "config_id": config_id, "query_id": query_id,
                            "attempt": used_attempts, "reason": last_error,
                            "retrying_entire_query_unit": used_attempts < MAX_UNIT_ATTEMPTS,
                            "time": utc_now()})
                        if used_attempts >= MAX_UNIT_ATTEMPTS:
                            raise RunnerError(f"{config_id}/{query_id}: traffic retry limit reached") from exc
                    except owned_guard.DeadlineExceeded as exc:
                        raise DeadlineReached(str(exc)) from exc
                if last_error is not None and used_attempts >= MAX_UNIT_ATTEMPTS:
                    raise RunnerError(f"{config_id}/{query_id}: exhausted whole-unit retry budget")
                if (len(commits) % 5) == 0:
                    write_progress(run_dir, manifest, commits, "official_running",
                                   {"config_id": config_id, "query_id": query_id},
                                   len(read_jsonl(run_dir / "failed-attempts.jsonl")))
            if reranker != "standalone":
                guard.wait_idle(guard.check_deadline)
                _stop_server(guard, servers, reranker, event_path)
            write_progress(run_dir, manifest, commits, "official_running",
                           {"completed_config": config_id},
                           len(read_jsonl(run_dir / "failed-attempts.jsonl")))
        if len(commits) != 228:
            raise RunnerError(f"batch finished with {len(commits)}/228 committed rows")
        rebuild_aggregates(run_dir, commits)
        from . import independent_validate
        scope = independent_validate.Scope(embedders=(embedder,), rerankers=RERANKERS,
                                           registry_embedders=EMBEDDERS)
        validation = independent_validate.validate(run_dir, scope=scope)
        write_json_atomic(run_dir / "validation-report.json", validation)
        pending = {"status": "validated_pending_guard_close",
                   "run_id": run_id, "batch": batch, "embedder": embedder,
                   "counts": validation.get("counts"), "validation_status": validation.get("status"),
                   "preflight": check_preflight_compatibility(preflight_evidence, package_root,
                                                               full_manifest, audit),
                   "corpus_cache_sha256": corpus_hash,
                   "validated_at": datetime.now(ZoneInfo("Asia/Taipei")).isoformat(),
                   "server_events_file": str(event_path.relative_to(run_dir)),
                   "traffic_events_file": "traffic-events.jsonl"}
        write_json_atomic(run_dir / "batch-validation-pending.json", pending)
        manifest["status"] = "validated_pending_guard_close"
        manifest["execution"]["formal_accepted_rows"] = len(commits)
        manifest["execution"]["error_count"] = len(read_jsonl(run_dir / "failed-attempts.jsonl"))
        write_json_atomic(run_dir / "run-manifest.json", manifest)
        write_progress(run_dir, manifest, commits, manifest["status"], errors=manifest["execution"]["error_count"])
        return pending
    finally:
        original_error_pending = sys.exc_info()[0] is not None
        cleanup_errors = []
        for model_id in list(servers):
            try:
                _stop_server(guard, servers, model_id, event_path)
            except BaseException as exc:
                cleanup_errors.append({"model_id": model_id,
                                       "error": f"{type(exc).__name__}: {exc}"})
        if cleanup_errors:
            try:
                write_json_atomic(run_dir / "owned-server-cleanup-errors.json", cleanup_errors)
            except Exception:
                pass
            # Do not mask an existing failure, but never return validated completion
            # after any owned process shutdown error.
            if not original_error_pending:
                raise RunnerError("owned server cleanup failed; batch cannot be finalized")


def _record_status(run_dir: Path, event: str, **fields: Any) -> None:
    append_jsonl(run_dir / "status-events.jsonl", {"event": event, "time": utc_now(),
                                                     "pid": os.getpid(), **fields})


def _finalize_preflight_after_guard_close(run_dir: Path, manifest: dict[str, Any],
                                          pending: dict[str, Any]) -> dict[str, Any]:
    """Freeze preflight completion hashes only after servers and guard are closed."""
    if pending.get("status") != "validated_pending_guard_close" or len(pending.get("models", [])) != 10:
        raise RunnerError("preflight validation pending record is incomplete")
    traffic_path = run_dir / pending["traffic_events_file"]
    server_path = run_dir / pending["server_events_file"]
    request_path = run_dir / "preflight-request-trace.jsonl"
    preflight_manifest_path = run_dir / "preflight-manifest.json"
    preflight_manifest = read_json(preflight_manifest_path)
    preflight_manifest["final_event_evidence"] = {
        "guard_closed": True,
        "traffic_events_sha256": file_sha(traffic_path),
        "traffic_events": len(read_jsonl(traffic_path)),
        "server_events_sha256": file_sha(server_path),
        "server_events": len(read_jsonl(server_path)),
        "request_trace_sha256": file_sha(request_path),
    }
    write_json_atomic(preflight_manifest_path, preflight_manifest)
    complete = {key: value for key, value in pending.items()
                if key not in ("status", "server_events_file", "traffic_events_file")}
    complete.update({
        "status": "passed", "protocol_id": "judged-top50-v1",
        "preflight_manifest_sha256": file_sha(preflight_manifest_path),
        "request_trace_sha256": file_sha(request_path),
        "guard_closed": True,
        "guard_events_sha256": file_sha(traffic_path),
        "traffic_events": len(read_jsonl(traffic_path)),
        "server_event_sha256": file_sha(server_path),
        "server_events": len(read_jsonl(server_path)),
        "completed_at": datetime.now(ZoneInfo("Asia/Taipei")).isoformat(),
    })
    write_json_atomic(run_dir / "preflight-complete.json", complete)
    manifest["status"] = "preflight_passed"
    manifest.setdefault("execution", {}).update({
        "inference_started": True, "guard_started": True,
        "preflight_models_passed": 10,
        "preflight_complete_sha256": file_sha(run_dir / "preflight-complete.json"),
        "request_trace_sha256": complete["request_trace_sha256"],
        "guard_events_sha256": complete["guard_events_sha256"],
        "server_event_sha256": complete["server_event_sha256"],
    })
    write_json_atomic(run_dir / "run-manifest.json", manifest)
    write_json_atomic(run_dir / "progress.json", {
        "run_id": manifest["run_id"], "mode": "preflight", "status": "preflight_passed",
        "accepted_rows": 0, "models_passed": 10, "updated_at": utc_now(),
    })
    return complete


def _finalize_official_after_guard_close(run_dir: Path, manifest: dict[str, Any],
                                         pending: dict[str, Any]) -> dict[str, Any]:
    """Write the final batch audit only after owned servers and guard have stopped."""
    if pending.get("status") != "validated_pending_guard_close":
        raise RunnerError("official validation pending record is missing or invalid")
    traffic_path = run_dir / pending["traffic_events_file"]
    server_path = run_dir / pending["server_events_file"]
    validation_path = run_dir / "validation-report.json"
    validation = read_json(validation_path)
    if validation.get("status") != pending.get("validation_status"):
        raise RunnerError("validation status changed after the pending completion record")
    complete = {key: value for key, value in pending.items()
                if key not in ("status", "validation_status", "server_events_file", "traffic_events_file")}
    clean = validation.get("status") == "passed"
    complete.update({
        "status": "passed" if clean else "blocked",
        "guard_closed": True,
        "guard_events_sha256": file_sha(traffic_path),
        "traffic_events": len(read_jsonl(traffic_path)),
        "server_events_sha256": file_sha(server_path),
        "server_events": len(read_jsonl(server_path)),
        "validation_report_sha256": file_sha(validation_path),
        "completed_at": datetime.now(ZoneInfo("Asia/Taipei")).isoformat(),
    })
    write_json_atomic(run_dir / "batch-completion-audit.json", complete)
    manifest["status"] = "complete" if clean else "blocked_validation"
    manifest["completion_audit_sha256"] = file_sha(run_dir / "batch-completion-audit.json")
    manifest.setdefault("execution", {}).update({
        "formal_accepted_rows": 228,
        "error_count": len(read_jsonl(run_dir / "failed-attempts.jsonl")),
        "guard_events_sha256": complete["guard_events_sha256"],
        "server_events_sha256": complete["server_events_sha256"],
    })
    write_json_atomic(run_dir / "run-manifest.json", manifest)
    commits = load_commits(run_dir)
    write_progress(run_dir, manifest, commits, manifest["status"],
                   errors=manifest["execution"]["error_count"])
    return complete


def execute(args: argparse.Namespace) -> int:
    package_root = PACKAGE_ROOT.resolve()
    workspace = Path(args.workspace).expanduser().resolve()
    phase2_root = Path(args.phase2_root).expanduser().resolve() if args.phase2_root else workspace / "embedding-study-phase2-20261023"
    output_root = Path(args.output_root).expanduser()
    if not output_root.is_absolute():
        output_root = (package_root / output_root).resolve()
    output_root = output_root.resolve()
    if not output_root.is_relative_to(package_root):
        raise RunnerError("output-root must remain under this isolated retest project")
    if args.wall_hours <= 0 or args.wall_hours > MAX_WALL_HOURS or not math.isfinite(args.wall_hours):
        raise RunnerError("--wall-hours must be finite and within (0, 12]; official deadline cannot be extended")
    mode = "preflight" if args.preflight_only else "official"
    batch = "ALL" if mode == "preflight" else args.batch
    if mode == "official" and args.batch not in dict(BATCHES):
        raise RunnerError("official run requires one of A01–A07")
    if mode == "official" and args.preflight_evidence is None:
        raise RunnerError("official run requires --preflight-evidence pointing to the passed ten-model smoke/token audit")
    if mode == "official":
        preflight_evidence = Path(args.preflight_evidence).expanduser().resolve()
    else:
        preflight_evidence = None

    full_manifest = read_json(package_root / "models-manifest.json")
    audit = verify_live_audits(workspace, package_root, full_manifest)
    data = read_json(package_root / "frozen-data/acord.json")
    protocol = read_json(package_root / "frozen-data/scoring-protocol.json")
    validate_frozen_data(data, protocol)
    reference, _reference_evidence = read_public_candidate_lists(package_root, data)
    validate_source_data(package_root, phase2_root, data, protocol)
    deadline = time.time() + float(args.wall_hours) * 3600.0
    run_dir, manifest = create_run_root(
        package_root, workspace, phase2_root, output_root, batch, args.segment, mode,
        deadline_epoch=deadline, full_manifest=full_manifest, audit=audit,
        resume=bool(args.resume), preflight_evidence=preflight_evidence)
    deadline = float(manifest["deadline_epoch"])

    def status(event: str, **fields: Any) -> None:
        _record_status(run_dir, event, **fields)

    lock_path = phase2_root / ".phase2-benchmark.lock"
    guard = owned_guard.OwnedTrafficGuard(run_dir / "traffic-events.jsonl", deadline,
                                           idle_seconds=30, period_seconds=1.0)
    core = None
    result: dict[str, Any] | None = None
    guard_closed = False
    try:
        with GlobalBenchmarkLock(lock_path, deadline, status):
            manifest["status"] = "lock_acquired"
            manifest["execution"]["global_lock"] = True
            manifest["execution"]["runner_pid"] = os.getpid()
            manifest["execution"]["runner_started_at"] = datetime.now(ZoneInfo("Asia/Taipei")).isoformat()
            write_json_atomic(run_dir / "run-manifest.json", manifest)
            guard.start()
            manifest["execution"]["guard_started"] = True
            write_json_atomic(run_dir / "run-manifest.json", manifest)
            guard.wait_idle(guard.check_deadline)
            core = runtime.import_core(workspace,
                                       workspace / full_manifest["server"]["binary_path_relative_to_gguf"])
            if mode == "preflight":
                result = run_preflight_models(package_root, workspace, run_dir, full_manifest,
                                              audit, data, reference, deadline, guard, core)
                manifest = read_json(run_dir / "run-manifest.json")
                status("preflight_validated_pending_guard_close",
                       result=result["status"], models=len(result["models"]))
            else:
                result = run_official_batch(package_root, workspace, phase2_root, run_dir,
                                            manifest, full_manifest, audit,
                                            preflight_evidence, guard, core)
                status("official_batch_validated_pending_guard_close", result=result["status"],
                       accepted_rows=result.get("counts", {}).get("quality_rows"))
    except DeadlineReached as exc:
        manifest["status"] = "partial_deadline"
        manifest["deadline_reached_at"] = datetime.now(ZoneInfo("Asia/Taipei")).isoformat()
        manifest["deadline_reason"] = str(exc)
        if mode == "official":
            commits = load_commits(run_dir)
            rebuild_aggregates(run_dir, commits)
            write_progress(run_dir, manifest, commits, "partial_deadline",
                           errors=len(read_jsonl(run_dir / "failed-attempts.jsonl")))
        write_json_atomic(run_dir / "run-manifest.json", manifest)
        status("fixed_deadline_reached", reason=str(exc))
        return 2
    except KeyboardInterrupt:
        manifest["status"] = "interrupted_by_operator"
        manifest["interrupted_at"] = datetime.now(ZoneInfo("Asia/Taipei")).isoformat()
        if mode == "official":
            commits = load_commits(run_dir)
            rebuild_aggregates(run_dir, commits)
            write_progress(run_dir, manifest, commits, "interrupted_by_operator",
                           errors=len(read_jsonl(run_dir / "failed-attempts.jsonl")))
        write_json_atomic(run_dir / "run-manifest.json", manifest)
        status("operator_interrupt")
        return 130
    except BaseException as exc:
        manifest["status"] = "failed_closed"
        manifest["failure"] = {"type": type(exc).__name__, "message": str(exc), "at": utc_now()}
        try:
            if mode == "official":
                commits = load_commits(run_dir)
                rebuild_aggregates(run_dir, commits)
                write_progress(run_dir, manifest, commits, "failed_closed",
                               errors=len(read_jsonl(run_dir / "failed-attempts.jsonl")))
            write_json_atomic(run_dir / "run-manifest.json", manifest)
            status("failed_closed", error_type=type(exc).__name__, error=str(exc))
        except Exception:
            pass
        raise
    finally:
        try:
            guard.close()
            guard_closed = True
        except Exception as exc:
            status("guard_close_error", error=str(exc))

    if result is not None:
        try:
            manifest = read_json(run_dir / "run-manifest.json")
            if not guard_closed or guard.fatal_reason is not None:
                reason = guard.fatal_reason or "guard did not close cleanly"
                manifest["status"] = "failed_closed"
                manifest["failure"] = {"type": "GuardCloseFailure", "message": reason,
                                       "at": utc_now()}
                write_json_atomic(run_dir / "run-manifest.json", manifest)
                status("finalization_blocked", reason=reason)
                return 2
            if mode == "preflight":
                result = _finalize_preflight_after_guard_close(run_dir, manifest, result)
                status("preflight_completed", result=result["status"], models=len(result["models"]))
            else:
                result = _finalize_official_after_guard_close(run_dir, manifest, result)
                status("official_batch_completed", result=result["status"],
                       accepted_rows=result.get("counts", {}).get("quality_rows"))
            manifest = read_json(run_dir / "run-manifest.json")
        except BaseException as exc:
            try:
                manifest = read_json(run_dir / "run-manifest.json")
                manifest["status"] = "failed_closed"
                manifest["failure"] = {"type": type(exc).__name__, "message": str(exc),
                                       "at": utc_now()}
                write_json_atomic(run_dir / "run-manifest.json", manifest)
                status("finalization_failed_closed", error_type=type(exc).__name__, error=str(exc))
            except Exception:
                pass
            return 2

    print(json.dumps({"status": manifest.get("status"), "run_dir": str(run_dir),
                      "run_id": manifest.get("run_id"), "deadline_epoch": deadline},
                     ensure_ascii=False, indent=2))
    return 0 if manifest.get("status") in ("complete", "preflight_passed") else 2


def parser() -> argparse.ArgumentParser:
    value = argparse.ArgumentParser(description=__doc__)
    value.add_argument("--workspace", type=Path, required=True,
                       help="GGUF workspace root containing models and llama.cpp")
    value.add_argument("--phase2-root", type=Path,
                       help="Phase-2 study root containing datasets.json, accepted commits and corpus caches")
    value.add_argument("--output-root", type=Path, default=Path("run-output"))
    value.add_argument("--batch", choices=[row[0] for row in BATCHES])
    value.add_argument("--segment", default="segment-01")
    value.add_argument("--wall-hours", type=float, default=12.0)
    value.add_argument("--execute", action="store_true",
                       help="Required to start the guard or any model/server process")
    value.add_argument("--preflight-only", action="store_true",
                       help="Run the ten-model token audits and fixed/ACORD smoke checks; no formal result rows")
    value.add_argument("--preflight-evidence", type=Path,
                       help="Completed preflight run root required before an official batch")
    value.add_argument("--resume", action="store_true",
                       help="Resume an existing exact segment with its original run ID and deadline")
    return value


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    try:
        if not args.execute:
            plan = {"mode": "preflight" if args.preflight_only else "official",
                    "batch": "ALL" if args.preflight_only else args.batch,
                    "status": "offline_plan_only", "inference_started": False,
                    "execute_required": True,
                    "wall_hours_max": MAX_WALL_HOURS,
                    "preflight_requires_all_10_models": True,
                    "official_requires_completed_preflight": True,
                    "guard": {"poll_seconds": 1, "rolling_quiet_seconds": 30,
                              "maximum_whole_unit_attempts": MAX_UNIT_ATTEMPTS,
                              "shared_lock": ".phase2-benchmark.lock",
                              "inference_concurrency": 1}}
            if args.batch:
                plan.update(plan_for_batch(args.batch))
            print(json.dumps(plan, ensure_ascii=False, indent=2))
            return 0
        if args.preflight_only and args.batch:
            raise RunnerError("--preflight-only covers all ten models; omit --batch")
        if not args.preflight_only and args.batch is None:
            raise RunnerError("official execution requires --batch A01–A07")
        return execute(args)
    except (RunnerError, OSError, ValueError, KeyError, zipfile.BadZipFile) as exc:
        print(json.dumps({"status": "failed_closed", "error": f"{type(exc).__name__}: {exc}"},
                         ensure_ascii=False, indent=2), file=sys.stderr)
        return 2


if __name__ == "__main__":
    old_handlers = {}
    def _interrupt(signum, _frame):
        raise KeyboardInterrupt(f"received signal {signum}")
    for _sig in (signal.SIGINT, signal.SIGTERM):
        old_handlers[_sig] = signal.signal(_sig, _interrupt)
    try:
        raise SystemExit(main())
    finally:
        for _sig, _handler in old_handlers.items():
            signal.signal(_sig, _handler)

