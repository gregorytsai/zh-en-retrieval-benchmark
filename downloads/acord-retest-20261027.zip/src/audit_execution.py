#!/usr/bin/env python3
"""Independent, read-only audit of completed runtime evidence (no runner imports)."""
import argparse
import hashlib
import json
import math
from pathlib import Path


class EvidenceError(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise EvidenceError(message)


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def rows(path):
    with path.open(encoding="utf-8") as stream:
        return [json.loads(line) for line in stream if line.strip()]


def sha(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1048576), b""):
            digest.update(block)
    return digest.hexdigest()


def audit_guard_units(events, query_rows, timing_rows):
    """Every accepted row needs an uninterrupted guarded measured interval."""
    starts, finishes, aborted = {}, {}, set()
    for event in events:
        kind = event.get("event")
        unit = event.get("unit_id")
        if kind == "guard_unit_started":
            require(unit not in starts, "duplicate guard unit start")
            require(event.get("quiet_seconds", 0) >= 30, "insufficient quiet window")
            require(event.get("poll_period_seconds") == 1, "guard period differs from one second")
            starts[unit] = event
        elif kind == "guard_unit_finished":
            require(unit not in finishes, "duplicate guard unit finish")
            finishes[unit] = event
        elif kind == "guard_unit_aborted":
            aborted.add(unit)
    timing = {(row["config_id"], row["query_id"]): row for row in timing_rows}
    require(len(timing) == len(timing_rows), "duplicate timing key")
    checked = 0
    for row in query_rows:
        unit = f'{row["config_id"]}/{row["query_id"]}/{row["provenance"]["attempt_id"]}'
        require(unit in starts and unit in finishes and unit not in aborted,
                "accepted result lacks successful guard unit")
        start, end = starts[unit], finishes[unit]
        require(start["traffic_epoch"] == end["traffic_epoch"], "traffic epoch changed")
        require(start["owned_pids"] == end["owned_pids"] and bool(start["owned_pids"]),
                "owned model processes changed during measured unit")
        measured = timing.get((row["config_id"], row["query_id"]))
        require(measured is not None, "missing measured timing")
        lo, hi = float(start["monotonic"]), float(end["monotonic"])
        t0, t1 = measured["monotonic_start_ns"] / 1e9, measured["monotonic_end_ns"] / 1e9
        require(all(math.isfinite(x) for x in (lo, hi, t0, t1)), "nonfinite clock")
        # Monotonic seconds/ns share the OS clock; permit only conversion rounding.
        require(lo - 1e-6 <= t0 < t1 <= hi + 1e-6, "timing outside guarded unit")
        snapshots = [e for e in events if e.get("event") == "snapshot"
                     and lo <= e["monotonic"] <= hi]
        require(bool(snapshots), "no traffic snapshots during measured unit")
        require(all(e.get("reason") is None and e.get("epoch") == start["traffic_epoch"]
                    for e in snapshots), "interference inside accepted unit")
        times = sorted([lo, hi] + [e["monotonic"] for e in snapshots])
        require(max(b-a for a, b in zip(times, times[1:])) <= 5,
                "traffic evidence exceeds stale-monitor limit")
        checked += 1
    return {"accepted_guard_units": checked, "aborted_guard_units": len(aborted)}


def audit_server_events(events):
    loaded, stopped = {}, set()
    for event in events:
        if event.get("event") == "server_loaded":
            pid = event["pid"]
            require(pid not in loaded or pid in stopped, "server PID loaded twice without stop")
            offload = event.get("gpu_offload", [])
            require(len(offload) == 2 and offload[0] == offload[1] and offload[0] > 0,
                    "missing full GPU offload")
            command = event["command"]
            for flag, value in {"--n-gpu-layers": "all", "--ctx-size": "8192",
                                "--parallel": "1", "--batch-size": "4096",
                                "--ubatch-size": "4096"}.items():
                require(flag in command and command[command.index(flag)+1] == value,
                        "runtime launch parameter mismatch")
            loaded[pid] = event
            stopped.discard(pid)
        elif event.get("event") == "server_stopped":
            require(event["pid"] in loaded, "stopped PID absent from owned launch evidence")
            stopped.add(event["pid"])
    require(bool(loaded), "no owned GPU launch evidence")
    require(set(loaded) <= stopped, "owned server lacks stop evidence")
    return {"models_loaded": sorted({e["model_id"] for e in loaded.values()}),
            "owned_pids_observed": len(loaded)}


def audit(root):
    root = Path(root)
    try:
        manifest = read(root / "run-manifest.json")
        audit_path = root / "batch-completion-audit.json"
        preflight = not audit_path.exists()
        if preflight:
            audit_path = root / "preflight-complete.json"
        complete = read(audit_path)
        require(complete.get("status") == "passed" and complete.get("guard_closed") is True,
                "completion evidence has not passed/closed")
        require(sha(root / "traffic-events.jsonl") == complete["guard_events_sha256"],
                "final traffic hash differs")
        server_hash = complete.get("server_events_sha256", complete.get("server_event_sha256"))
        require(sha(root / "server-events.jsonl") == server_hash, "final server hash differs")
        traffic = rows(root / "traffic-events.jsonl")
        require(traffic[-1].get("event") == "guard_closed", "guard closure is not final event")
        require(any(e.get("event") == "guard_owned_servers_stopped" for e in traffic),
                "missing clean guard-owned process closure")
        launches = audit_server_events(rows(root / "server-events.jsonl"))
        if preflight:
            require(len(complete["models"]) == 10 and len(launches["models_loaded"]) == 10,
                    "preflight does not cover ten models")
            for model in complete["models"]:
                require(all(model.get(k) == "passed" for k in
                            ("token_status", "fixture_status", "acord_smoke_status")),
                        "model preflight failed")
            units = {"formal_rows": 0}
        else:
            require(manifest.get("status") == "complete", "batch not complete")
            query_rows = rows(root / "query-results.jsonl")
            require(len(query_rows) == 228, "batch does not contain 228 formal rows")
            units = audit_guard_units(traffic, query_rows, rows(root / "timing-results.jsonl"))
        return {"status": "passed", "run_id": manifest["run_id"], "preflight": preflight,
                **launches, **units,
                "scope": "Final log hashes, GPU launch parameters, owned cleanup, guarded timing intervals. Numerical/data validation is separate."}
    except (OSError, ValueError, KeyError, TypeError, IndexError) as exc:
        return {"status": "incomplete", "error": f"{type(exc).__name__}: {exc}"}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run_root", type=Path)
    args = parser.parse_args()
    result = audit(args.run_root)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    raise SystemExit(0 if result["status"] == "passed" else 1)
