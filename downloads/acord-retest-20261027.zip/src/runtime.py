"""Pinned llama.cpp runtime bridge, detailed token audit, and traced inference."""
from __future__ import annotations

import hashlib
import importlib.util
import json
import re
import struct
import subprocess
import sys
import time
import urllib.error
import urllib.request
import uuid
from pathlib import Path
from typing import Any, Callable

import numpy as np

from .scoring import canonical_float32_vector_hash, sha256_canonical

ACORD_EMBEDDERS = ("qwen-4b", "qwen-8b", "embeddinggemma-2", "qwen-0.6b",
                   "bge-m3", "f2llm-v2-0.6b", "granite-97m-r2")


class RuntimeGateError(RuntimeError):
    pass


class HttpInferenceError(RuntimeError):
    def __init__(self, message: str, trace: dict[str, Any]):
        self.trace = trace
        super().__init__(message)


def read_gguf_fields(path: Path, wanted: set[str], *, include_prefixes: tuple[str, ...] = (),
                     required: bool = True) -> dict[str, Any]:
    """Read selected GGUF metadata only; tensor payloads are never loaded."""
    scalar = {
        0: ("<B", 1), 1: ("<b", 1), 2: ("<H", 2), 3: ("<h", 2),
        4: ("<I", 4), 5: ("<i", 4), 6: ("<f", 4), 7: ("<?", 1),
        10: ("<Q", 8), 11: ("<q", 8), 12: ("<d", 8),
    }
    found: dict[str, Any] = {}
    def exact(handle, n: int) -> bytes:
        if n < 0 or n > 1_073_741_824:
            raise RuntimeGateError(f"unreasonable GGUF metadata length {n}")
        raw = handle.read(n)
        if len(raw) != n:
            raise RuntimeGateError("truncated GGUF metadata")
        return raw
    def u32(handle) -> int:
        return struct.unpack("<I", exact(handle, 4))[0]
    def u64(handle) -> int:
        return struct.unpack("<Q", exact(handle, 8))[0]
    def string(handle) -> str:
        return exact(handle, u64(handle)).decode("utf-8")
    with Path(path).open("rb") as handle:
        if exact(handle, 4) != b"GGUF":
            raise RuntimeGateError("invalid GGUF magic")
        version = u32(handle)
        if version not in (2, 3):
            raise RuntimeGateError(f"unsupported GGUF version {version}")
        _tensor_count = u64(handle)
        metadata_count = u64(handle)
        if metadata_count > 1_000_000:
            raise RuntimeGateError("unreasonable GGUF metadata count")
        for _ in range(metadata_count):
            key = string(handle)
            kind = u32(handle)
            keep = key in wanted or any(key.startswith(prefix) for prefix in include_prefixes)
            value: Any = None
            if kind == 8:
                if keep:
                    value = string(handle)
                else:
                    handle.seek(u64(handle), 1)
            elif kind == 9:
                item_kind, count = u32(handle), u64(handle)
                if count > 1_000_000_000:
                    raise RuntimeGateError(f"unreasonable GGUF array count for {key}")
                if item_kind == 8:
                    if keep:
                        value = [string(handle) for _ in range(count)]
                    else:
                        for _ in range(count):
                            handle.seek(u64(handle), 1)
                elif item_kind in scalar:
                    fmt, width = scalar[item_kind]
                    if keep:
                        value = [struct.unpack(fmt, exact(handle, width))[0] for _ in range(count)]
                    else:
                        handle.seek(width * count, 1)
                else:
                    raise RuntimeGateError(f"unsupported GGUF array type {item_kind} in {key}")
            elif kind in scalar:
                fmt, width = scalar[kind]
                raw = exact(handle, width)
                if keep:
                    value = struct.unpack(fmt, raw)[0]
            else:
                raise RuntimeGateError(f"unsupported GGUF metadata value type {kind} in {key}")
            if keep:
                found[key] = value
    missing = wanted - found.keys()
    if required and missing:
        raise RuntimeGateError(f"required GGUF metadata fields missing: {sorted(missing)}")
    return found


def traced_token_count(core: Any, server: Any, text: str, *, add_special: bool,
                       parse_special: bool, check: Callable[[], None]) -> int:
    check()
    response, _elapsed = core.request(
        server, "/tokenize",
        {"content": text, "add_special": bool(add_special), "parse_special": bool(parse_special)},
        timeout=180.0,
    )
    tokens = response.get("tokens")
    if not isinstance(tokens, list) or any(type(token) is not int for token in tokens):
        raise RuntimeGateError("/tokenize response lacks an integer token list")
    return len(tokens)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def import_core(gguf_workspace: Path, binary: Path):
    """Load the frozen Phase-2 core snapshot without executing its run entrypoint."""
    legacy = Path(__file__).resolve().parent / "legacycore"
    if str(legacy) not in sys.path:
        sys.path.insert(0, str(legacy))
    spec = importlib.util.spec_from_file_location("acord_phase2_core_snapshot", legacy / "core.py")
    if spec is None or spec.loader is None:
        raise RuntimeGateError("cannot load pinned llama.cpp core snapshot")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    module.configure(Path(gguf_workspace), Path(binary))
    # The imported core's server helper uses these module globals for cwd/logs.
    module.base.WORKSPACE = Path(gguf_workspace).resolve()
    return module


def verify_runtime_pins(gguf_workspace: Path, manifest: dict[str, Any], *,
                        model_ids: list[str], expected_binary_sha: str) -> dict[str, Any]:
    binary_rel = manifest["server"]["binary_path_relative_to_gguf"]
    binary = Path(gguf_workspace) / binary_rel
    if not binary.is_file():
        raise RuntimeGateError(f"llama-server binary is missing: {binary_rel}")
    binary_sha = sha256_file(binary)
    if binary_sha != expected_binary_sha or binary_sha != manifest["server"]["binary_sha256"]:
        raise RuntimeGateError("llama-server binary SHA differs from frozen model/runtime pin")
    model_checks = {}
    for model_id in model_ids:
        row = manifest["models"].get(model_id)
        if not isinstance(row, dict):
            raise RuntimeGateError(f"model missing from models-manifest: {model_id}")
        path = Path(gguf_workspace) / row["path_relative_to_gguf"]
        if not path.is_file():
            raise RuntimeGateError(f"model file missing for {model_id}: {row['path_relative_to_gguf']}")
        stat = path.stat()
        if stat.st_size != row["bytes"]:
            raise RuntimeGateError(f"model bytes changed for {model_id}: {stat.st_size}")
        digest = sha256_file(path)
        if digest != row["sha256"]:
            raise RuntimeGateError(f"model SHA changed for {model_id}: {digest}")
        model_checks[model_id] = {"sha256": digest, "bytes": stat.st_size,
                                  "path_relative_to_gguf": row["path_relative_to_gguf"]}
    if not model_ids:
        raise RuntimeGateError("no model pins selected")
    return {"binary_sha256": binary_sha, "binary_bytes": binary.stat().st_size,
            "models": model_checks}


def start_owned_server(core: Any, guard: Any, *, out: Path, model_id: str,
                       model_path: Path, mode: str, pooling: str, deadline_epoch: float,
                       event_path: Path) -> Any:
    if time.time() >= deadline_epoch:
        raise TimeoutError("original wall deadline reached before server startup")
    name = f"{model_id}-{time.time_ns()}"
    core.base.ROOT = Path(out)
    core.base.ROOT.mkdir(parents=True, exist_ok=True)
    core.base.WORKSPACE = core.WORKSPACE
    server = core.Server(model_path, mode, name, deadline_epoch, pooling)
    guard.register(name, server)
    started_epoch = time.time()
    try:
        server.start(timeout_s=max(1.0, min(1200.0, deadline_epoch - time.time())))
        guard.check()
        command = server._command(server.port)
        required_flags = {
            "--n-gpu-layers": "all", "--log-verbosity": "4", "--ctx-size": "8192",
            "--parallel": "1", "--threads": "8", "--threads-batch": "8",
            "--batch-size": "4096", "--ubatch-size": "4096",
        }
        for flag, expected in required_flags.items():
            if flag not in command or command[command.index(flag) + 1] != expected:
                raise RuntimeGateError(f"required server setting changed: {flag}={expected}")
        log_path = Path(command[command.index("--log-file") + 1])
        if not log_path.is_file():
            raise RuntimeGateError("server log missing; cannot verify actual GPU offload")
        offloads = re.findall(r"offloaded\s+(\d+)/(\d+) layers to GPU", log_path.read_text(errors="replace"))
        if (not offloads or int(offloads[-1][0]) <= 0 or
                int(offloads[-1][0]) != int(offloads[-1][1])):
            raise RuntimeGateError(f"model lacks complete n_gpu_layers=all offload evidence: {model_id}")
        props = core.base.get_json(server.url + "/props")
        row = {"event": "server_loaded", "model_id": model_id, "pid": server.process.pid,
               "port": server.port, "mode": mode, "load_ms": server.load_ms,
               "started_epoch": started_epoch, "command": command,
               "gpu_offload": [int(offloads[-1][0]), int(offloads[-1][1])],
               "server_props": props, "log_sha256": sha256_file(log_path)}
        event_path.parent.mkdir(parents=True, exist_ok=True)
        with event_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n")
        return server
    except BaseException as start_error:
        try:
            stop_owned_server(guard, server, model_id, event_path)
        except BaseException as cleanup_error:
            try:
                guard._mark_fatal(
                    f"failed to clean up owned {model_id} server after startup error: "
                    f"{type(cleanup_error).__name__}: {cleanup_error}")
            except Exception:
                pass
            if isinstance(start_error, KeyboardInterrupt):
                raise start_error
            raise RuntimeGateError(
                f"startup failed and owned server cleanup also failed for {model_id}") from cleanup_error
        raise


def stop_owned_server(guard: Any, server: Any, model_id: str, event_path: Path) -> None:
    name = getattr(server, "run_tag", model_id)
    process = getattr(server, "process", None)
    stop_error: BaseException | None = None
    try:
        server.stop()
    except BaseException as exc:
        stop_error = exc
    if process is not None and process.poll() is None:
        # The Server.stop implementation normally handles TERM/KILL itself. Keep
        # this owned-PID fallback so a shutdown exception cannot orphan a test server.
        try:
            process.terminate()
        except ProcessLookupError:
            pass
        try:
            process.wait(timeout=3)
        except subprocess.TimeoutExpired:
            try:
                process.kill()
            except ProcessLookupError:
                pass
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                pass
    if process is not None and process.poll() is None:
        guard._mark_fatal(f"owned server {model_id} remained alive after stop/kill")
        raise RuntimeGateError(f"owned server {model_id} did not exit; guard remains fail-closed")
    guard.unregister(name, server)
    event_path.parent.mkdir(parents=True, exist_ok=True)
    with event_path.open("a", encoding="utf-8") as f:
        f.write(json.dumps({"event": "server_stopped", "model_id": model_id,
                            "pid": getattr(process, "pid", None),
                            "returncode": getattr(process, "returncode", None),
                            "sampled_peak_rss_mb": getattr(server, "peak_rss_mb", None),
                            "stop_error": None if stop_error is None else
                                f"{type(stop_error).__name__}: {stop_error}"},
                           ensure_ascii=False, allow_nan=False) + "\n")
    if stop_error is not None:
        raise stop_error


def detailed_token_audit(core: Any, server: Any, *, model_id: str, model: dict[str, Any],
                         data: dict[str, Any], out: Path,
                         check: Callable[[], None],
                         candidate_lists_by_embedder: dict[str, dict[str, list[str]]] | None = None,
                         corpus_cache: dict[str, dict[str, Any]] | None = None) -> dict[str, Any]:
    """Tokenize every frozen query/document on the pinned server; never truncate."""
    registry = model["registry"]
    is_embed = registry["kind"] == "embedding"
    is_bge = model_id == "bge-reranker"
    docs = []
    queries = []
    token_root = Path(out) / "token-audit" / model_id
    token_root.mkdir(parents=True, exist_ok=True)
    token_path = token_root / f"items-{uuid.uuid4()}.jsonl"
    token_path.parent.mkdir(parents=True, exist_ok=True)
    # This attempt-scoped file is append-only; all record text stays private and is
    # excluded from the public allowlist.
    def record(kind: str, item_id: str, prefix: str, text: str, raw_reranker_input: bool = False) -> int:
        check()
        full_text = prefix + text
        count = core.token_count(server, full_text, raw_reranker_input=raw_reranker_input)
        row = {"model_id": model_id, "kind": kind, "item_id": str(item_id),
               "token_count": int(count), "input_utf8_bytes": len(full_text.encode("utf-8")),
               "prefix_sha256": hashlib.sha256(prefix.encode("utf-8")).hexdigest(),
               "input_sha256": hashlib.sha256(full_text.encode("utf-8")).hexdigest(),
               "add_special": not raw_reranker_input,
               "parse_special": False if raw_reranker_input else None}
        with token_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n")
        return int(count)

    if is_embed:
        doc_prefix = registry.get("document_prefix", "")
        query_prefix = registry.get("query_prefix") or registry.get("prompt", "")
        for doc in data["corpus"]:
            docs.append((doc["id"], record("document", doc["id"], doc_prefix, doc["text"])))
        for query in data["queries"]:
            queries.append((query["id"], record("query", query["id"], query_prefix, query["text"])))
        max_doc, max_query = 4096, 4096
        pair_reserve = None
    else:
        # Raw side lengths are diagnostic only; pair-level code below applies
        # the exact model template and its own special-token policy.
        raw_special = True
        for doc in data["corpus"]:
            docs.append((doc["id"], record("reranker_document", doc["id"], "", doc["text"], raw_special)))
        for query in data["queries"]:
            queries.append((query["id"], record("reranker_query", query["id"], "", query["text"], raw_special)))
        max_doc, max_query = 4096, 4096
        # Pair-level context is measured below using the GGUF template or the
        # verified BGE fallback; no heuristic reserve is substituted for it.
        pair_reserve = 3 if is_bge else None
    largest_doc = max(docs, key=lambda x: x[1])
    largest_query = max(queries, key=lambda x: x[1])
    issues = []
    if any(n >= max_doc for _, n in docs):
        issues.append({"kind": "document_limit", "limit": max_doc})
    if any(n >= max_query for _, n in queries):
        issues.append({"kind": "query_limit", "limit": max_query})
    pair_summary = None
    if not is_embed:
        pair_summary = _audit_reranker_pairs(
            core, server, model_id=model_id, model=model, data=data, out=out, check=check,
            candidate_lists_by_embedder=candidate_lists_by_embedder or {},
            corpus_cache=corpus_cache or {}, query_lengths=dict(queries), doc_lengths=dict(docs))
        issues.extend(pair_summary["issues"])
    summary = {"model_id": model_id, "kind": registry["kind"],
               "corpus_documents": len(docs), "queries": len(queries),
               "maximum_document": {"id": largest_doc[0], "tokens": largest_doc[1]},
               "maximum_query": {"id": largest_query[0], "tokens": largest_query[1]},
               "pair_template_reserve": pair_reserve,
               "pair_token_upper_bound": None,
               "pair_audit": pair_summary,
               "item_token_log": str(token_path.relative_to(out)),
               "truncated": False, "issues": issues,
               "status": "passed" if not issues else "blocked"}
    summary_path = token_root / f"summary-{uuid.uuid4()}.json"
    summary["summary_file"] = str(summary_path.relative_to(out))
    summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    if issues:
        raise RuntimeGateError(f"token audit blocked for {model_id}: {issues}")
    return summary


def _audit_reranker_pairs(core: Any, server: Any, *, model_id: str, model: dict[str, Any],
                          data: dict[str, Any], out: Path, check: Callable[[], None],
                          candidate_lists_by_embedder: dict[str, dict[str, list[str]]],
                          corpus_cache: dict[str, dict[str, Any]],
                          query_lengths: dict[str, int], doc_lengths: dict[str, int]) -> dict[str, Any]:
    """Measure exact reranker token lengths for every corrected judged Top50 pair."""
    corpus = {str(row["id"]): row for row in data["corpus"]}
    queries = {str(row["id"]): row for row in data["queries"]}
    if set(candidate_lists_by_embedder) != set(ACORD_EMBEDDERS):
        raise RuntimeGateError(
            "reranker pair token audit must cover all seven embedder candidate sets")
    sources: dict[tuple[str, str], set[str]] = {}
    for embedder, by_query in candidate_lists_by_embedder.items():
        if set(by_query) != set(queries):
            raise RuntimeGateError(f"{embedder}: pair token audit lacks the 57-query candidate set")
        if embedder not in corpus_cache:
            raise RuntimeGateError(f"{embedder}: pair token audit lacks accepted cache evidence")
        for query_id, ids in by_query.items():
            if len(ids) != 50 or len(set(ids)) != 50:
                raise RuntimeGateError(f"{embedder}/{query_id}: token audit expects 50 unique candidates")
            if any(doc_id not in data["qrels"][query_id] or doc_id not in corpus for doc_id in ids):
                raise RuntimeGateError(f"{embedder}/{query_id}: unknown candidate in token audit")
            for doc_id in ids:
                sources.setdefault((query_id, doc_id), set()).add(embedder)
    expected_raw_pairs = len(ACORD_EMBEDDERS) * len(queries) * 50
    observed_raw_pairs = sum(len(ids) for by_query in candidate_lists_by_embedder.values()
                             for ids in by_query.values())
    if observed_raw_pairs != expected_raw_pairs or not sources:
        raise RuntimeGateError("reranker pair token audit has incomplete/empty candidate coverage")
    model_path = Path(model["absolute_path"])
    common_fields = {
        "general.architecture", "tokenizer.ggml.model", "tokenizer.ggml.bos_token_id",
        "tokenizer.ggml.eos_token_id", "tokenizer.ggml.add_bos_token",
        "tokenizer.ggml.add_eos_token", "tokenizer.ggml.add_sep_token",
    }
    if model_id == "bge-reranker":
        metadata = read_gguf_fields(model_path, common_fields,
                                    include_prefixes=("tokenizer.chat_template",), required=False)
        fallback = core.validate_bge_reranker_metadata(metadata)
        template = None
        template_sha = None
    else:
        metadata = read_gguf_fields(
            model_path, {"tokenizer.chat_template.rerank", "tokenizer.chat_templates"},
            include_prefixes=("tokenizer.chat_template",), required=True)
        template = metadata.get("tokenizer.chat_template.rerank")
        names = metadata.get("tokenizer.chat_templates", [])
        if not isinstance(template, str) or not template or "rerank" not in names:
            raise RuntimeGateError(f"{model_id}: no GGUF rerank chat template was found")
        template_sha = hashlib.sha256(template.encode("utf-8")).hexdigest()
        fallback = None

    pair_log = Path(out) / "reranker-pair-token-audit" / model_id / f"pairs-{uuid.uuid4()}.jsonl"
    pair_log.parent.mkdir(parents=True, exist_ok=True)
    template_path = None
    if template is not None:
        template_path = pair_log.parent / "rerank-template.txt"
        if template_path.exists() and hashlib.sha256(template_path.read_bytes()).hexdigest() != template_sha:
            template_path = pair_log.parent / f"rerank-template-{template_sha}.txt"
        if not template_path.exists():
            template_path.write_text(template, encoding="utf-8")
    maximum = None
    issues = []
    pair_count = 0
    with pair_log.open("x", encoding="utf-8") as stream:
        for (query_id, doc_id), embedder_names in sorted(sources.items()):
            check()
            if model_id == "bge-reranker":
                query_tokens = query_lengths[query_id]
                document_tokens = doc_lengths[doc_id]
                total = query_tokens + document_tokens + int(fallback["fallback_pair_overhead"])
                parse_special = False
            else:
                # Mirrors server-common.cpp:1884-1900 exactly: copy rerank template,
                # replace {query} first and then {document}, tokenize with
                # add_special=false and parse_special=true.
                prompt = template.replace("{query}", queries[query_id]["text"])
                prompt = prompt.replace("{document}", corpus[doc_id]["text"])
                total = traced_token_count(core, server, prompt, add_special=False,
                                           parse_special=True, check=check)
                query_tokens = query_lengths[query_id]
                document_tokens = doc_lengths[doc_id]
                parse_special = True
            row = {"model_id": model_id, "query_id": query_id, "doc_id": doc_id,
                   "candidate_embedders": sorted(embedder_names),
                   "candidate_order_hashes": {name: corpus_cache[name]["candidate_hashes"][query_id]
                                              for name in sorted(embedder_names)},
                   "query_tokens_without_pair_template": query_tokens,
                   "document_tokens_without_pair_template": document_tokens,
                   "pair_token_count": total, "token_limit": 4096,
                   "add_special": False, "parse_special": parse_special,
                   "template_sha256": template_sha, "fallback_verification": fallback,
                   "truncated": False, "status": "ok" if total <= 4096 else "blocked"}
            stream.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n")
            pair_count += 1
            if maximum is None or total > maximum["pair_token_count"]:
                maximum = row
            if total > 4096:
                issues.append({"kind": "reranker_pair_exceeds_batch", "model_id": model_id,
                               "query_id": query_id, "doc_id": doc_id,
                               "tokens": total, "limit": 4096})
    return {"unique_query_document_pairs": pair_count,
            "candidate_embedders": sorted(candidate_lists_by_embedder),
            "pair_log": str(pair_log.relative_to(out)),
            "template_text_file": str(template_path.relative_to(out)) if template_path else None,
            "template_sha256": template_sha, "template_text": template,
            "tokenization": {"add_special": False, "parse_special": True} if template else None,
            "fallback_verification": fallback, "maximum_pair": maximum,
            "truncated": False, "issues": issues}


def fixed_fixtures() -> list[tuple[str, str, str]]:
    """The ten fixed Phase-2 cross-language positive/negative fixtures."""
    return list(__import__("acord_phase2_core_snapshot").FIXTURES)


def embedding_smoke(core: Any, server: Any, model_id: str, registry: dict[str, Any], check: Callable[[], None]) -> dict[str, Any]:
    prefix = registry.get("query_prefix") or registry.get("prompt", "")
    doc_prefix = registry.get("document_prefix", "")
    dim = int(registry["dimension"])
    fixtures = fixed_fixtures()
    evidence = []
    for query, positive, negative in fixtures:
        check()
        vectors, _ = core.embed(server, [prefix + query, doc_prefix + positive, doc_prefix + negative], dim)
        good = float(vectors[0] @ vectors[1])
        bad = float(vectors[0] @ vectors[2])
        if not (np.isfinite(vectors).all() and good > bad):
            raise RuntimeGateError(f"embedding fixture failed for {model_id}")
        evidence.append({"positive_score": good, "negative_score": bad, "positive_wins": True})
    repeats = [core.embed(server, [prefix + fixtures[0][0]], dim)[0][0] for _ in range(3)]
    repeat_max_abs_diff = max(float(np.max(np.abs(repeats[0] - x))) for x in repeats[1:])
    if repeat_max_abs_diff > 1e-5:
        raise RuntimeGateError(f"embedding repeatability failed for {model_id}")
    return {"model_id": model_id, "status": "passed", "fixture_count": len(evidence),
            "repeat_max_abs_diff": repeat_max_abs_diff, "timing_included_in_formal": False,
            "fixtures": evidence}


def reranker_smoke(core: Any, server: Any, model_id: str, check: Callable[[], None]) -> dict[str, Any]:
    fixtures = fixed_fixtures()
    evidence = []
    distractors = [f"Fixed neutral distractor clause {i:02d}." for i in range(48)]
    for query, positive, negative in fixtures:
        check()
        documents = [positive, negative, *distractors]
        order, _, scores = core.rerank(server, query, documents)
        if len(order) != 50 or len(scores) != 50 or set(order) != set(range(50)):
            raise RuntimeGateError(f"reranker smoke did not return exactly 50 indexed scores: {model_id}")
        if order[0] != 0 or not (math_isfinite(scores[0]) and math_isfinite(scores[1]) and scores[0] > scores[1]):
            raise RuntimeGateError(f"reranker positive/negative fixture failed: {model_id}")
        evidence.append({"positive_rank": order.index(0) + 1, "positive_score": scores[0],
                         "negative_score": scores[1], "candidate_count": 50})
    return {"model_id": model_id, "status": "passed", "fixture_count": len(evidence),
            "timing_included_in_formal": False, "fixtures": evidence}


def math_isfinite(value: float) -> bool:
    return bool(np.isfinite(float(value)))


def post_json_traced(server: Any, body: dict[str, Any], *, kind: str, model_id: str,
                     model_sha: str, run_id: str, config_id: str, query_id: str,
                     input_ids_hash: str, attempt_id: str) -> tuple[dict[str, Any], dict[str, Any], float]:
    """Single exact legacy endpoint POST with monotonic request-boundary evidence."""
    request_id = str(uuid.uuid4())
    payload = json.dumps(body, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        server.url + ("/v1/embeddings" if kind == "query_embedding" else "/v1/rerank"),
        data=payload, headers={"Content-Type": "application/json"}, method="POST")
    start_ns = time.monotonic_ns()
    status = None
    try:
        with urllib.request.urlopen(req, timeout=900.0) as response:
            status = int(response.status)
            raw = response.read()
        finish_ns = time.monotonic_ns()
        if status != 200:
            raise RuntimeError(f"unexpected HTTP status {status}")
        parsed = json.loads(raw.decode("utf-8"))
        trace = {"id": request_id, "run_id": run_id, "config_id": config_id,
                 "query_id": query_id, "kind": kind, "model_id": model_id,
                 "model_sha256": model_sha, "input_sha256": sha256_canonical(body),
                 "input_ids_sha256": input_ids_hash, "payload_field_names": sorted(body),
                 "grade_fields_absent": True, "started_ns": start_ns, "finished_ns": finish_ns,
                 "status": "ok", "http_status": status, "attempt_id": attempt_id,
                 "output_vector_sha256": None}
        return parsed, trace, (finish_ns - start_ns) / 1e6
    except urllib.error.HTTPError as exc:
        finish_ns = time.monotonic_ns()
        trace = {"id": request_id, "run_id": run_id, "config_id": config_id,
                 "query_id": query_id, "kind": kind, "model_id": model_id,
                 "model_sha256": model_sha, "input_sha256": sha256_canonical(body),
                 "input_ids_sha256": input_ids_hash, "payload_field_names": sorted(body),
                 "grade_fields_absent": True, "started_ns": start_ns, "finished_ns": finish_ns,
                 "status": "http_error", "http_status": int(exc.code), "attempt_id": attempt_id,
                 "output_vector_sha256": None}
        raise HttpInferenceError(f"HTTP {exc.code} from {kind}", trace) from exc
    except Exception as exc:
        finish_ns = time.monotonic_ns()
        trace = {"id": request_id, "run_id": run_id, "config_id": config_id,
                 "query_id": query_id, "kind": kind, "model_id": model_id,
                 "model_sha256": model_sha, "input_sha256": sha256_canonical(body),
                 "input_ids_sha256": input_ids_hash, "payload_field_names": sorted(body),
                 "grade_fields_absent": True, "started_ns": start_ns, "finished_ns": finish_ns,
                 "status": "failed", "http_status": status, "attempt_id": attempt_id,
                 "output_vector_sha256": None}
        raise HttpInferenceError(f"{type(exc).__name__}: {exc}", trace) from exc


def traced_embedding(server: Any, *, query: dict[str, Any], prefix: str, dimension: int,
                     model_id: str, model_sha: str, run_id: str, config_id: str,
                     attempt_id: str) -> tuple[np.ndarray, dict[str, Any], float]:
    body = {"input": [prefix + query["text"]], "encoding_format": "float"}
    parsed, trace, request_ms = post_json_traced(
        server, body, kind="query_embedding", model_id=model_id, model_sha=model_sha,
        run_id=run_id, config_id=config_id, query_id=str(query["id"]),
        input_ids_hash=sha256_canonical([str(query["id"])]), attempt_id=attempt_id)
    data = parsed.get("data")
    if not isinstance(data, list) or len(data) != 1 or data[0].get("index") != 0:
        raise RuntimeGateError("embedding response index/cardinality mismatch")
    vector = np.asarray(data[0].get("embedding"), dtype=np.float32)
    if vector.shape != (dimension,) or not np.isfinite(vector).all():
        raise RuntimeGateError(f"embedding output shape/nonfinite mismatch: {vector.shape}")
    norm = float(np.linalg.norm(vector))
    if not np.isfinite(norm) or norm <= 0 or abs(norm - 1.0) >= 0.01:
        raise RuntimeGateError(f"embedding output not normalized: norm={norm}")
    vector = np.asarray(vector / np.float32(norm), dtype=np.float32)
    trace["output_vector_sha256"] = canonical_float32_vector_hash(vector)
    return vector, trace, request_ms


def traced_rerank(server: Any, *, query: dict[str, Any], documents: list[dict[str, Any]],
                  model_id: str, model_sha: str, run_id: str, config_id: str,
                  attempt_id: str) -> tuple[list[float], dict[str, Any], float]:
    if len(documents) != 50:
        raise RuntimeGateError(f"rerank request must contain exactly 50 candidates; got {len(documents)}")
    document_ids = [str(d.get("id")) for d in documents]
    if any(not doc_id or doc_id == "None" for doc_id in document_ids) or len(set(document_ids)) != 50:
        raise RuntimeGateError("rerank request must contain 50 unique nonempty candidate IDs")
    body = {"query": query["text"], "documents": [d["text"] for d in documents], "top_n": 50}
    ids_hash = sha256_canonical(document_ids)
    parsed, trace, request_ms = post_json_traced(
        server, body, kind="rerank", model_id=model_id, model_sha=model_sha,
        run_id=run_id, config_id=config_id, query_id=str(query["id"]),
        input_ids_hash=ids_hash, attempt_id=attempt_id)
    results = parsed.get("results")
    if (not isinstance(results, list) or len(results) != 50 or
            any(not isinstance(row, dict) or type(row.get("index")) is not int for row in results) or
            sorted(row["index"] for row in results) != list(range(50))):
        raise RuntimeGateError("rerank response did not return exactly one score for each of 50 candidates")
    values = [0.0] * 50
    for row in results:
        index = row["index"]
        score = float(row.get("relevance_score", row.get("score")))
        if not np.isfinite(score):
            raise RuntimeGateError("non-finite rerank score")
        values[index] = score
    return values, trace, request_ms
