"""Pure ACORD judged-top50-v1 ranking, hashing, and metric functions.

This module is the runner-side scorer only. The independent validator is maintained
separately by the parent agent and must recompute outputs from frozen qrels.
"""
from __future__ import annotations

import hashlib
import json
import math
from typing import Any, Iterable, Mapping, Sequence

import numpy as np

PROTOCOL_ID = "judged-top50-v1"
CANDIDATE_K = 50
RELEVANT_GRADE = 2


class ScoringError(ValueError):
    pass


def canonical_json_bytes(value: Any) -> bytes:
    return json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("utf-8")


def sha256_canonical(value: Any) -> str:
    return hashlib.sha256(canonical_json_bytes(value)).hexdigest()


def stable_full_ranking(doc_ids: Sequence[str], scores: Sequence[float]) -> list[dict[str, Any]]:
    """Sort float32 cosine scores descending, with ascending doc_id ties."""
    ids = [str(x) for x in doc_ids]
    if len(ids) != len(scores) or len(ids) != len(set(ids)):
        raise ScoringError("ranking requires one score per unique document ID")
    vals = np.asarray(scores, dtype=np.float32)
    if vals.ndim != 1 or len(vals) != len(ids) or not np.isfinite(vals).all():
        raise ScoringError("ranking scores must be finite one-dimensional float32 values")
    order = sorted(range(len(ids)), key=lambda i: (-float(vals[i]), ids[i]))
    return [
        {"rank": rank, "doc_id": ids[i], "similarity": float(vals[i]), "judged": False}
        for rank, i in enumerate(order, 1)
    ]


def filter_judged_top50(
    full_ranking: Sequence[Mapping[str, Any]], qrels: Mapping[str, int], k: int = CANDIDATE_K
) -> tuple[list[str], list[int]]:
    """Filter unknowns before cutoff; explicit grade zero remains judged."""
    if k != CANDIDATE_K:
        raise ScoringError("judged-top50-v1 fixes k=50")
    seen: set[str] = set()
    ids: list[str] = []
    ranks: list[int] = []
    judged = {str(doc_id) for doc_id in qrels}
    previous: tuple[float, str] | None = None
    for expected_rank, entry in enumerate(full_ranking, 1):
        doc_id = str(entry["doc_id"])
        rank = int(entry["rank"])
        score = float(entry["similarity"])
        if rank != expected_rank or not math.isfinite(score):
            raise ScoringError("full ranking has invalid position or nonfinite similarity")
        if doc_id in seen:
            raise ScoringError(f"duplicate document in retrieval ranking: {doc_id}")
        current = (-score, doc_id)
        if previous is not None and current < previous:
            raise ScoringError("full ranking is not sorted by score descending/doc_id ascending")
        previous = current
        seen.add(doc_id)
        if len(ids) < k and doc_id in judged:
            ids.append(doc_id)
            ranks.append(rank)
    if len(ids) != k:
        raise ScoringError(f"only {len(ids)} judged documents in full ranking; expected {k}")
    return ids, ranks


def _validate_judgments(qrels: Mapping[str, int]) -> dict[str, int]:
    grades: dict[str, int] = {}
    for doc_id, grade in qrels.items():
        if type(grade) is not int or not 0 <= grade <= 4:
            raise ScoringError(f"ACORD grade outside integer 0..4: {doc_id}={grade!r}")
        grades[str(doc_id)] = grade
    if not grades:
        raise ScoringError("query has no judged qrels")
    return grades


def evaluate_ranking(
    ranked_doc_ids: Sequence[str],
    candidate_ids: Sequence[str],
    qrels: Mapping[str, int],
) -> dict[str, float | int | None]:
    """Score one complete standalone ranking or one ordered judged top-50 rerank."""
    grades = _validate_judgments(qrels)
    ranked = [str(x) for x in ranked_doc_ids]
    candidates = [str(x) for x in candidate_ids]
    if not ranked or len(ranked) != len(set(ranked)):
        raise ScoringError("final ranking must be nonempty and have unique document IDs")
    if any(doc not in grades for doc in ranked):
        raise ScoringError("final ranking contains an unjudged/unknown document")
    if len(candidates) != CANDIDATE_K or len(candidates) != len(set(candidates)):
        raise ScoringError("candidate list must contain exactly 50 unique document IDs")
    if any(doc not in grades for doc in candidates):
        raise ScoringError("candidate list contains an unjudged/unknown document")
    positive = {doc for doc, grade in grades.items() if grade >= RELEVANT_GRADE}
    def ndcg(k: int) -> float | None:
        dcg = sum(grades[doc] / math.log2(i + 2) for i, doc in enumerate(ranked[:k]))
        ideal = sorted(grades.values(), reverse=True)[:k]
        idcg = sum(grade / math.log2(i + 2) for i, grade in enumerate(ideal))
        return dcg / idcg if idcg else None

    rel_positions = [i for i, doc in enumerate(ranked[:10], 1) if doc in positive]
    top10_hits = sum(doc in positive for doc in ranked[:10])
    result: dict[str, float | int | None] = {
        "ndcg@5": ndcg(5),
        "ndcg@10": ndcg(10),
        "top1": int(ranked[0] in positive),
        "mrr@10": 1.0 / rel_positions[0] if rel_positions else 0.0,
        "hit@10": int(bool(rel_positions)),
        "recall@10": top10_hits / len(positive) if positive else None,
        "candidate_recall@50": sum(doc in positive for doc in candidates) / len(positive) if positive else None,
    }
    for threshold in (2, 3, 4):
        key = f"normalized_p5_grade_ge_{threshold}"
        denom = min(5, sum(grade >= threshold for grade in grades.values()))
        result[key] = (
            sum(grades[doc] >= threshold for doc in ranked[:5]) / denom if denom else None
        )
    return result


def canonical_float32_vector_hash(vector: Sequence[float]) -> str:
    values = np.asarray(vector, dtype="<f4")
    if values.ndim != 1 or not np.isfinite(values).all():
        raise ScoringError("query vector must be finite one-dimensional float32")
    return hashlib.sha256(values.tobytes(order="C")).hexdigest()


def ranked_entry_hash(ranking: Sequence[Mapping[str, Any]]) -> str:
    return sha256_canonical(list(ranking))


def ordered_candidate_hash(candidate_ids: Sequence[str]) -> str:
    return sha256_canonical([str(x) for x in candidate_ids])

