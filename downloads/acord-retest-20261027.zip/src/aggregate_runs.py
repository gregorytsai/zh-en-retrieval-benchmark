#!/usr/bin/env python3
"""Build a byte-preserving, provenance-checked ACORD aggregate after all runs finish.

This is offline packaging code. It never starts models and never edits source runs.
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import hashlib
import json
import os
import shutil
import sys
from pathlib import Path
from typing import Iterable

try:
    from . import independent_validate as validate
    from . import audit_execution
    from . import runner
except ImportError:  # python src/aggregate_runs.py
    import independent_validate as validate
    import audit_execution
    import runner

ARTIFACTS = (
    'query-results.jsonl', 'timing-results.jsonl', 'request-trace.jsonl',
    'retrieval-attempts.jsonl', 'full-retrieval-rankings.jsonl',
    'candidates.jsonl', 'reranker-scores.jsonl',
)
ORIGIN_ARTIFACTS = (
    'query-results.jsonl', 'timing-results.jsonl', 'request-trace.jsonl',
    'retrieval-attempts.jsonl', 'full-retrieval-rankings.jsonl',
)
COPY_SOURCE_EVIDENCE = (
    'run-manifest.json', 'batch-completion-audit.json', 'committed.json',
    'progress.json', 'query-results.jsonl', 'timing-results.jsonl',
    'request-trace.jsonl', 'retrieval-attempts.jsonl',
    'full-retrieval-rankings.jsonl', 'candidates.jsonl', 'reranker-scores.jsonl',
    'traffic-events.jsonl', 'server-events.jsonl', 'token-audit-summary.json',
    'config.json', 'environment.json',
    'failed-attempts.jsonl', 'errors.jsonl',
)
METRIC_COLUMNS = (
    'ndcg@5', 'ndcg@10', 'top1', 'mrr@10', 'hit@10', 'recall@10',
    'candidate_recall@50', 'normalized_p5_grade_ge_2',
    'normalized_p5_grade_ge_3', 'normalized_p5_grade_ge_4',
)
TIME_COLUMNS = ('query_embedding', 'retrieval', 'evaluation_filter', 'rerank', 'total', 'wall_total')


def read_json(path: Path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def jsonl(path: Path):
    return list(validate.lines(path))


def file_sha(path: Path) -> str:
    return validate.file_hash(path)


def write_json(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + '.tmp')
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    os.replace(temp, path)


def write_rows(path: Path, rows: Iterable[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + '.tmp')
    with temp.open('w', encoding='utf-8', newline='') as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False, separators=(',', ':'), allow_nan=False) + '\n')
    os.replace(temp, path)


def _check_one_run(run_dir: Path, registry_embedders: tuple) -> tuple[dict, dict, dict]:
    run_dir = run_dir.resolve()
    manifest = read_json(run_dir / 'run-manifest.json')
    if manifest.get('mode') != 'official' or manifest.get('status') != 'complete':
        raise ValueError(f"source run is not complete official: {manifest.get('run_id')} ({manifest.get('status')})")
    batch = manifest.get('batch')
    embedder = dict(runner.BATCHES).get(batch)
    if not embedder or manifest.get('embedder') != embedder:
        raise ValueError(f"batch/embedder mismatch: {batch}/{manifest.get('embedder')}")
    completion = read_json(run_dir / 'batch-completion-audit.json')
    validation_report_path = run_dir / 'validation-report.json'
    expected_validation_sha = completion.get('validation_report_sha256')
    if (completion.get('run_id') != manifest.get('run_id')
            or completion.get('batch') != batch
            or completion.get('status') != 'passed'
            or not expected_validation_sha
            or not validation_report_path.is_file()
            or file_sha(validation_report_path) != expected_validation_sha):
        raise ValueError(f"batch completion audit failed: {manifest.get('run_id')}")
    validation_report = read_json(validation_report_path)
    if (validation_report.get('status') != 'passed'
            or validation_report.get('run_id') != manifest.get('run_id')
            or validation_report.get('counts', {}).get('quality_rows') != 228):
        raise ValueError(f"batch validation report failed: {manifest.get('run_id')}")
    numeric = validate.validate(run_dir, validate.Scope(embedders=(embedder,), registry_embedders=registry_embedders))
    if numeric.get('status') != 'passed' or numeric['counts']['quality_rows'] != 228:
        raise ValueError(f"independent batch validation failed: {numeric}")
    execution = audit_execution.audit(run_dir)
    if execution.get('status') != 'passed' or execution.get('accepted_guard_units') != 228:
        raise ValueError(f"independent execution audit failed: {execution}")
    for name in ARTIFACTS:
        if not (run_dir / name).is_file():
            raise ValueError(f"source artifact missing: {run_dir / name}")
    return manifest, numeric, execution


def _copy_exact(source: Path, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)
    if file_sha(source) != file_sha(target):
        raise IOError(f"copy hash mismatch: {source}")


def _frozen_input_snapshot(source_dir: Path, target: Path, manifest: dict) -> dict[str, str]:
    pins = manifest.get('frozen_files_sha256', {})
    if not pins:
        raise ValueError('source manifest has no frozen input pins')
    for relative, expected in pins.items():
        src = source_dir / relative
        if not src.is_file() or file_sha(src) != expected:
            raise ValueError(f'frozen source snapshot mismatch: {relative}')
        _copy_exact(src, target / relative)
    return dict(pins)


def _copy_source_run(run_dir: Path, target: Path, manifest: dict, output_dir: Path) -> dict:
    run_id = manifest['run_id']
    target.mkdir(parents=True, exist_ok=False)
    copied = []
    for name in COPY_SOURCE_EVIDENCE:
        src = run_dir / name
        if src.is_file():
            dst = target / name
            _copy_exact(src, dst)
            copied.append(name)
    for name in ORIGIN_ARTIFACTS:
        if name not in copied:
            raise ValueError(f'missing provenance artifact {name} in {run_id}')
    mhash = file_sha(target / 'run-manifest.json')
    rel_target = target.relative_to(output_dir).as_posix()
    spec = {'manifest_path': f'{rel_target}/run-manifest.json',
            'manifest_sha256': mhash, 'artifacts': {}}
    for name in ORIGIN_ARTIFACTS:
        p = target / name
        spec['artifacts'][name] = {'path': f'{rel_target}/{name}', 'sha256': file_sha(p)}
    return spec


def _write_summary_csv(path: Path, summaries: list[dict]) -> None:
    fields = ['config_id', 'embedder', 'reranker', 'n', 'failed']
    for name in METRIC_COLUMNS:
        fields += [f'{name}_mean', f'{name}_valid_n']
    for name in TIME_COLUMNS:
        fields += [f'{name}_mean_ms', f'{name}_p50_ms', f'{name}_p95_ms', f'{name}_n']
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', encoding='utf-8', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction='ignore')
        writer.writeheader()
        for s in sorted(summaries, key=lambda x: x['config_id']):
            row = {k: s.get(k) for k in ('config_id', 'embedder', 'reranker', 'n', 'failed')}
            for name in METRIC_COLUMNS:
                value = s['metrics'][name]
                row[f'{name}_mean'] = value['mean']  # repr/CSV round-trips binary64
                row[f'{name}_valid_n'] = value['valid_n']
            for name in TIME_COLUMNS:
                value = s['times_ms'][name]
                for stat in ('mean', 'p50', 'p95', 'n'):
                    row[f'{name}_{stat}_ms' if stat != 'n' else f'{name}_n'] = value[stat]
            writer.writerow(row)


def _failure_ledger(package_root: Path, source_dirs: list[Path], accepted_rows: int) -> dict:
    status_path = package_root / 'RUN_STATUS.json'
    status = read_json(status_path) if status_path.is_file() else {}
    history = status.get('history', {})
    raw_historical = history.get('historical_attempts', [])
    tooling_path = package_root / 'POSTRUN_TOOLING_HISTORY.json'
    tooling_history = read_json(tooling_path) if tooling_path.is_file() else {}

    def classify(text: str) -> str:
        lower = str(text).lower()
        if 'permission' in lower or 'sandbox' in lower or '/bin/ps' in lower:
            return 'guard_process_inspection_blocked'
        if 'run_status' in lower or 'input' in lower and 'missing' in lower:
            return 'isolated_run_input_missing'
        if 'nameerror' in lower or 'exception' in lower:
            return 'execution_code_failure_after_or_during_request'
        return 'historical_setup_or_execution_failure'

    historical = []
    superseded_preflights = []
    historical_failed_query_attempts = 0
    for row in raw_historical:
        normalized = {
            'stage': row.get('stage'), 'path': row.get('path'), 'run_id': row.get('run_id'),
            'result': row.get('result'), 'accepted_rows': row.get('accepted_rows', 0),
            'failed_attempts': row.get('failed_attempts', 0),
            'query_embedding_http_200_requests': row.get('query_embedding_http_200_requests', 0),
            'rerank_requests': row.get('rerank_requests', 0),
            'models_passed': row.get('models_passed'),
            'owned_server_stopped': row.get('owned_server_stopped'),
            'failure_category': classify(row.get('failure', row.get('stale_reason', ''))),
            'reason': row.get('failure') or row.get('stale_reason'),
        }
        if row.get('result') == 'passed_but_stale':
            superseded_preflights.append(normalized)
        else:
            historical.append(normalized)
            historical_failed_query_attempts += int(row.get('failed_attempts', 0) or 0)
    source_failures = []
    for run_dir in source_dirs:
        manifest = read_json(run_dir / 'run-manifest.json')
        for name in ('failed-attempts.jsonl', 'errors.jsonl'):
            path = run_dir / name
            if path.is_file():
                rows = jsonl(path)
                if rows:
                    source_failures.append({'run_id': manifest.get('run_id'), 'artifact': name,
                                           'record_count': len(rows),
                                           'failure_categories': sorted({classify(r.get('error', r.get('reason', ''))) for r in rows})})
    accepted_errors = sum(1 for run_dir in source_dirs
                          for f in [run_dir / 'query-results.jsonl'] if f.is_file()
                          for r in jsonl(f) if r.get('status') != 'ok')
    return {
        'protocol_id': validate.PROTOCOL,
        'official_accepted_rows': accepted_rows,
        'accepted_result_errors': accepted_errors,
        'historical_setup_or_execution_failures': historical,
        'historical_failure_count': len(historical),
        'historical_failed_query_attempt_count': historical_failed_query_attempts,
        'superseded_preflights': superseded_preflights,
        'superseded_preflight_count': len(superseded_preflights),
        'controller_schema_failures': tooling_history.get('controller_schema_failures', []),
        'controller_schema_failure_count': len(tooling_history.get('controller_schema_failures', [])),
        'offline_tooling_failures': tooling_history.get('offline_tooling_failures', []),
        'offline_tooling_failure_count': len(tooling_history.get('offline_tooling_failures', [])),
        'historical_failure_record_count_excluding_superseded_preflights': (
            len(historical) + len(tooling_history.get('controller_schema_failures', []))
            + len(tooling_history.get('offline_tooling_failures', []))),
        'failed_attempts_in_successful_source_runs': source_failures,
        'source_run_failure_record_count': sum(x['record_count'] for x in source_failures),
        'interpretation': 'Accepted final results have their own error count. Historical setup/execution failures and retried attempts remain separately reported and are not erased by a clean final matrix.'
    }


def aggregate_runs(source_dirs: list[Path], output_dir: Path) -> dict:
    source_dirs = [Path(p).resolve() for p in source_dirs]
    output_dir = Path(output_dir).resolve()
    if output_dir.exists() and any(output_dir.iterdir()):
        raise FileExistsError(f'aggregate output must be new or empty: {output_dir}')
    output_dir.mkdir(parents=True, exist_ok=True)
    package_root = Path(__file__).resolve().parents[1]
    expected = dict(runner.BATCHES)
    if len(source_dirs) != 7:
        raise ValueError('expected exactly seven complete official batch runs')
    checked = []
    seen_batches = set()
    registry = tuple(embedder for _batch, embedder in runner.BATCHES)
    for run_dir in source_dirs:
        manifest, numeric, execution = _check_one_run(run_dir, registry)
        if manifest['batch'] in seen_batches:
            raise ValueError(f'duplicate source batch {manifest["batch"]}')
        seen_batches.add(manifest['batch'])
        checked.append((run_dir, manifest, numeric, execution))
    if seen_batches != set(expected):
        raise ValueError(f'batch coverage mismatch: {sorted(seen_batches)}')
    checked.sort(key=lambda item: list(expected).index(item[1]['batch']))

    # Take an immutable input snapshot from A01's exact run copy.
    first_dir, first_manifest, _, _ = checked[0]
    frozen = _frozen_input_snapshot(first_dir, output_dir, first_manifest)
    dataset = validate.read(output_dir / 'frozen-data/acord.json')
    models = validate.read(output_dir / 'models-manifest.json')
    run_id = 'acord-aggregate-' + dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ')

    source_runs = {}
    source_dirs_by_id = {}
    for run_dir, manifest, _numeric, _execution in checked:
        rid = manifest['run_id']
        if rid in source_runs:
            raise ValueError(f'duplicate run_id: {rid}')
        # Keep an independent exact-byte source packet. The live source run is never moved or edited.
        dest = output_dir / 'source-runs' / rid
        spec = _copy_source_run(run_dir, dest, manifest, output_dir)
        source_runs[rid] = spec
        source_dirs_by_id[rid] = dest

    # Source artifacts remain byte-exact in source-runs/. The aggregate JSONL
    # records are concatenated in canonical batch order without changing fields.
    aggregate_rows = {name: [] for name in ARTIFACTS}
    candidate_rows = {}
    rank_rows = {}
    corpus_cache = {}
    for run_dir, manifest, _numeric, _execution in checked:
        embedder = manifest['embedder']
        cache = manifest.get('corpus_cache_sha256', {})
        if cache.get(embedder) is None:
            raise ValueError(f'missing corpus cache SHA in {manifest["run_id"]}')
        corpus_cache[embedder] = cache[embedder]
        for name in ARTIFACTS:
            rows = jsonl(run_dir / name)
            if name == 'candidates.jsonl':
                for row in rows:
                    key = (row['embedder'], row['query_id'])
                    previous = candidate_rows.get(key)
                    # Multiple config runs repeat candidate records; assert identical pool and rank evidence.
                    if previous is not None:
                        for field in ('candidate_ids', 'original_ranks', 'ordered_candidate_sha256', 'similarity_sha256', 'source_ranking_sha256'):
                            if previous[field] != row[field]:
                                raise ValueError(f'candidate drift across configs for {key}: {field}')
                    if previous is None:
                        candidate_rows[key] = row
                continue
            if name == 'full-retrieval-rankings.jsonl':
                for row in rows:
                    key = (row['embedder'], row['query_id'])
                    previous = rank_rows.get(key)
                    if previous is not None and previous['ranking_sha256'] != row['ranking_sha256']:
                        raise ValueError(f'full ranking drift across configs for {key}')
                    if previous is None:
                        rank_rows[key] = row
                continue
            aggregate_rows[name].extend(rows)
    aggregate_rows['candidates.jsonl'] = list(candidate_rows.values())
    aggregate_rows['full-retrieval-rankings.jsonl'] = list(rank_rows.values())
    for name, rows in aggregate_rows.items():
        rows.sort(key=lambda r: (r.get('embedder',''), r.get('config_id',''), r.get('query_id',''),
                                 r.get('candidate_index',-1), r.get('rank',-1), r.get('id','')))
        write_rows(output_dir / name, rows)

    # Summary JSON is rebuilt from primitive result rows; CSV keeps full binary64 repr.
    summaries = runner.build_summary(run_id, aggregate_rows['query-results.jsonl'])
    write_json(output_dir / 'summary.json', summaries)
    _write_summary_csv(output_dir / 'summary.csv', summaries)
    write_json(output_dir / 'failure-ledger.json', _failure_ledger(package_root, source_dirs, len(aggregate_rows['query-results.jsonl'])))
    source_manifest = {
        'run_id': run_id, 'protocol_id': validate.PROTOCOL, 'dataset_id': 'acord-eng-eng',
        'mode': 'aggregate', 'status': 'aggregate_validation_pending',
        'created_at': dt.datetime.now(dt.timezone.utc).isoformat(),
        'source_runs': source_runs, 'corpus_cache_sha256': corpus_cache,
        'frozen_files_sha256': frozen,
        'scope': {'embedders': list(registry), 'rerankers': list(validate.RERANKERS),
                  'queries': 57, 'corpus_docs': 3931, 'qrels': 61988,
                  'expected_rows': 1596, 'expected_candidates': 399, 'expected_pair_scores': 59850},
        'source_preservation': 'Source run manifests and required artifact bytes were copied unchanged under source-runs/<run_id>/. Aggregate rows retain the original run_id.'
    }
    write_json(output_dir / 'run-manifest.json', source_manifest)
    # Run the independent all-matrix numerical validator before marking aggregate valid.
    result = validate.validate(output_dir)
    if result.get('status') != 'passed' or result['counts']['quality_rows'] != 1596:
        raise ValueError(f'aggregate validator failed: {result}')
    source_manifest['status'] = 'complete'
    write_json(output_dir / 'run-manifest.json', source_manifest)
    # Validate again after final manifest write (the root manifest is not self-pinned).
    result = validate.validate(output_dir)
    report = {'status': 'passed', 'numeric_validation': result,
              'batch_execution_audits': [{'run_id': m['run_id'], 'batch': m['batch'], 'audit': ex}
                                          for _p,m,_n,ex in checked],
              'source_runs': [{'run_id': m['run_id'], 'batch': m['batch'],
                               'manifest_sha256': file_sha(source_dirs_by_id[m['run_id']] / 'run-manifest.json'),
                               'source_artifact_hashes_preserved': True}
                              for _p,m,_n,_ex in checked],
              'timestamp_utc': dt.datetime.now(dt.timezone.utc).isoformat()}
    write_json(output_dir / 'validation-report.json', report)
    return report


def build_failure_ledger_cli():
    p = argparse.ArgumentParser()
    p.add_argument('--package-root', type=Path, required=True)
    p.add_argument('--source-run', type=Path, action='append', required=True)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    runs = [x.resolve() for x in args.source_run]
    rows = sum(len(jsonl(x/'query-results.jsonl')) for x in runs)
    write_json(args.output, _failure_ledger(args.package_root.resolve(), runs, rows))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source-run', type=Path, action='append', required=True,
                   help='completed official source run directory; pass once for each of A01-A07')
    p.add_argument('--output', type=Path, required=True, help='new private aggregate output directory')
    args = p.parse_args()
    report = aggregate_runs(args.source_run, args.output)
    print(json.dumps({'status': report['status'], 'output': str(args.output.resolve()),
                      'counts': report['numeric_validation']['counts']}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
