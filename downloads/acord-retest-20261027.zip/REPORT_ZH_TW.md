# ACORD 法律條款檢索修正重測

Run: `acord-aggregate-20261027T130905Z` · Protocol: `judged-top50-v1`

本報告由完整逐題檔案重算並經獨立數值驗證。最終 complete 狀態仍須查 validation-report.json 的完整執行證據與交付稽核。

57 題、3,931 篇條款、61,988 個明確 qrels；28 組、1,596 筆正式品質結果。每組 57 題等權。

## 28 組結果

| Configuration | nDCG@5 | nDCG@10 | Top-1 | 4★ normalized P@5 | 5★ normalized P@5 (n) | Candidate Recall@50 | Total mean / p50 / p95 ms | Weights GiB |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| f2llm-v2-0.6b__qwen-reranker-4b | 0.686 | 0.729 | 73.68% | 51.87% | 44.77% (29) | 91.64% | 7298.96 / 7231.74 / 10517.96 | 4.581 |
| bge-m3__qwen-reranker-4b | 0.683 | 0.728 | 73.68% | 50.47% | 38.45% (29) | 85.30% | 8763.93 / 8537.30 / 11466.45 | 4.577 |
| qwen-0.6b__qwen-reranker-4b | 0.686 | 0.728 | 73.68% | 51.52% | 41.32% (29) | 90.80% | 6549.83 / 6379.19 / 9196.25 | 4.581 |
| qwen-4b__qwen-reranker-4b | 0.683 | 0.728 | 73.68% | 51.08% | 37.87% (29) | 95.26% | 7204.17 / 7198.69 / 9603.41 | 7.972 |
| qwen-8b__qwen-reranker-4b | 0.685 | 0.726 | 73.68% | 51.08% | 37.87% (29) | 93.73% | 7111.71 / 7127.46 / 9813.55 | 11.480 |
| granite-97m-r2__qwen-reranker-4b | 0.682 | 0.713 | 73.68% | 50.23% | 46.49% (29) | 74.05% | 7112.69 / 7373.97 / 8928.74 | 4.093 |
| qwen-4b__standalone | 0.672 | 0.703 | 68.42% | 50.12% | 38.28% (29) | 95.26% | 45.53 / 43.64 / 61.80 | 3.986 |
| embeddinggemma-2__qwen-reranker-4b | 0.660 | 0.698 | 73.68% | 48.89% | 35.29% (29) | 78.64% | 6246.02 / 6037.51 / 8445.10 | 4.274 |
| qwen-0.6b__qwen-reranker-0.6b | 0.650 | 0.685 | 66.67% | 47.34% | 33.28% (29) | 90.80% | 1240.02 / 1213.09 / 1703.29 | 1.191 |
| qwen-0.6b__bge-reranker | 0.644 | 0.685 | 70.18% | 48.19% | 23.33% (29) | 90.80% | 1019.74 / 1005.99 / 1395.52 | 1.187 |
| qwen-8b__qwen-reranker-0.6b | 0.643 | 0.685 | 66.67% | 45.50% | 33.28% (29) | 93.73% | 1362.00 / 1362.17 / 1818.54 | 8.090 |
| f2llm-v2-0.6b__qwen-reranker-0.6b | 0.649 | 0.684 | 66.67% | 47.25% | 33.28% (29) | 91.64% | 1359.05 / 1339.17 / 1890.23 | 1.191 |
| qwen-4b__qwen-reranker-0.6b | 0.652 | 0.684 | 66.67% | 47.60% | 33.28% (29) | 95.26% | 1365.17 / 1355.81 / 1791.82 | 4.581 |
| bge-m3__qwen-reranker-0.6b | 0.652 | 0.682 | 66.67% | 47.69% | 35.57% (29) | 85.30% | 1595.29 / 1543.15 / 2077.24 | 1.186 |
| f2llm-v2-0.6b__bge-reranker | 0.643 | 0.681 | 70.18% | 48.51% | 26.78% (29) | 91.64% | 1127.32 / 1076.82 / 1652.57 | 1.188 |
| qwen-8b__bge-reranker | 0.642 | 0.679 | 70.18% | 48.27% | 23.33% (29) | 93.73% | 1130.01 / 1121.56 / 1517.33 | 8.086 |
| granite-97m-r2__qwen-reranker-0.6b | 0.655 | 0.678 | 66.67% | 47.34% | 36.72% (29) | 74.05% | 1321.68 / 1343.84 / 1630.25 | 0.702 |
| qwen-4b__bge-reranker | 0.649 | 0.675 | 70.18% | 49.68% | 23.33% (29) | 95.26% | 1134.95 / 1153.29 / 1480.34 | 4.578 |
| qwen-8b__standalone | 0.632 | 0.662 | 70.18% | 42.11% | 36.09% (29) | 93.73% | 54.56 / 53.82 / 57.61 | 7.494 |
| embeddinggemma-2__qwen-reranker-0.6b | 0.632 | 0.661 | 66.67% | 44.71% | 32.41% (29) | 78.64% | 1190.10 / 1143.25 / 1545.81 | 0.884 |
| granite-97m-r2__bge-reranker | 0.651 | 0.658 | 73.68% | 49.30% | 33.10% (29) | 74.05% | 1092.18 / 1101.39 / 1365.53 | 0.699 |
| bge-m3__bge-reranker | 0.634 | 0.652 | 68.42% | 47.49% | 23.33% (29) | 85.30% | 1345.49 / 1318.16 / 1823.90 | 1.183 |
| embeddinggemma-2__bge-reranker | 0.631 | 0.647 | 68.42% | 48.16% | 24.48% (29) | 78.64% | 969.87 / 926.10 / 1271.16 | 0.881 |
| f2llm-v2-0.6b__standalone | 0.626 | 0.646 | 71.93% | 42.87% | 35.57% (29) | 91.64% | 19.98 / 18.82 / 23.20 | 0.596 |
| qwen-0.6b__standalone | 0.595 | 0.623 | 64.91% | 40.64% | 15.98% (29) | 90.80% | 19.53 / 18.32 / 22.79 | 0.595 |
| bge-m3__standalone | 0.568 | 0.572 | 61.40% | 38.25% | 16.44% (29) | 85.30% | 14.48 / 13.88 / 20.24 | 0.591 |
| embeddinggemma-2__standalone | 0.521 | 0.532 | 56.14% | 34.91% | 22.18% (29) | 78.64% | 14.35 / 13.08 / 21.76 | 0.289 |
| granite-97m-r2__standalone | 0.501 | 0.517 | 57.89% | 30.61% | 24.08% (29) | 74.05% | 7.24 / 7.00 / 9.21 | 0.107 |

主要觀察：本輪最高 nDCG@10 為 f2llm-v2-0.6b__qwen-reranker-4b（0.729）。相鄰組合差異很小，不能據此宣稱穩定勝出。重排未必改善結果，應比較下表每個 Embedder 的配對差異；高星等指標僅有29題可評估，不能解讀成法律答案正確率。

權重容量是檔案大小相加，不是實測 RAM。未提供可靠 peak-memory 值，故保持 null。完整精度、其他指標、時間各階段與有效題數請見 summary.json／query-results.jsonl。

## 加入重排器的逐題配對差異

| Configuration | Δ nDCG@10 | Wins / losses / ties | Δ 4★ normalized P@5 | Δ 5★ normalized P@5 |
|---|---:|---:|---:|---:|
| qwen-4b__bge-reranker | -0.028 | 25 / 31 / 1 | -0.44% | -14.94% |
| qwen-4b__qwen-reranker-0.6b | -0.019 | 22 / 35 / 0 | -2.51% | -5.00% |
| qwen-4b__qwen-reranker-4b | 0.025 | 35 / 22 / 0 | 0.96% | -0.40% |
| qwen-8b__bge-reranker | 0.017 | 29 / 27 / 1 | 6.17% | -12.76% |
| qwen-8b__qwen-reranker-0.6b | 0.023 | 31 / 25 / 1 | 3.39% | -2.82% |
| qwen-8b__qwen-reranker-4b | 0.065 | 38 / 19 / 0 | 8.98% | 1.78% |
| embeddinggemma-2__bge-reranker | 0.116 | 43 / 14 / 0 | 13.25% | 2.30% |
| embeddinggemma-2__qwen-reranker-0.6b | 0.129 | 45 / 12 / 0 | 9.80% | 10.23% |
| embeddinggemma-2__qwen-reranker-4b | 0.166 | 49 / 7 / 1 | 13.98% | 13.10% |
| qwen-0.6b__bge-reranker | 0.062 | 38 / 19 / 0 | 7.54% | 7.36% |
| qwen-0.6b__qwen-reranker-0.6b | 0.062 | 34 / 23 / 0 | 6.70% | 17.30% |
| qwen-0.6b__qwen-reranker-4b | 0.105 | 47 / 10 / 0 | 10.88% | 25.34% |
| bge-m3__bge-reranker | 0.080 | 43 / 14 / 0 | 9.24% | 6.90% |
| bge-m3__qwen-reranker-0.6b | 0.110 | 49 / 8 / 0 | 9.44% | 19.14% |
| bge-m3__qwen-reranker-4b | 0.156 | 49 / 8 / 0 | 12.22% | 22.01% |
| f2llm-v2-0.6b__bge-reranker | 0.035 | 37 / 20 / 0 | 5.64% | -8.79% |
| f2llm-v2-0.6b__qwen-reranker-0.6b | 0.038 | 34 / 23 / 0 | 4.39% | -2.30% |
| f2llm-v2-0.6b__qwen-reranker-4b | 0.083 | 43 / 14 / 0 | 9.01% | 9.20% |
| granite-97m-r2__bge-reranker | 0.141 | 47 / 10 / 0 | 18.68% | 9.02% |
| granite-97m-r2__qwen-reranker-0.6b | 0.161 | 47 / 9 / 1 | 16.73% | 12.64% |
| granite-97m-r2__qwen-reranker-4b | 0.196 | 52 / 5 / 0 | 19.62% | 22.41% |

百分比差異表示百分點；比較對象是相同 Embedder 的 standalone。

## 候選限制與候選內排序

| Embedder | Candidate Recall@50 | Candidate oracle nDCG@10 | 1 − oracle | Oracle − BGE | Oracle − Qwen 0.6B | Oracle − Qwen 4B |
|---|---:|---:|---:|---:|---:|---:|
| qwen-4b | 95.26% | 0.983 | 0.017 | 0.308 | 0.299 | 0.255 |
| qwen-8b | 93.73% | 0.979 | 0.021 | 0.300 | 0.294 | 0.253 |
| embeddinggemma-2 | 78.64% | 0.902 | 0.098 | 0.255 | 0.242 | 0.205 |
| qwen-0.6b | 90.80% | 0.969 | 0.031 | 0.284 | 0.284 | 0.241 |
| bge-m3 | 85.30% | 0.947 | 0.053 | 0.294 | 0.265 | 0.218 |
| f2llm-v2-0.6b | 91.64% | 0.972 | 0.028 | 0.292 | 0.288 | 0.243 |
| granite-97m-r2 | 74.05% | 0.897 | 0.103 | 0.239 | 0.219 | 0.184 |

Oracle 只用於事後診斷：在已固定候選內按真實 grade 理想排序，IDCG 仍取完整 qrels。1−oracle 是候選造成的品質上限損失；oracle−實測是候選內排序仍可改善的空間。標籤未提供給模型，也未用來挑候選。

## 指定組合配對比較

Left: `qwen-4b__qwen-reranker-0.6b` · Right: `bge-m3__qwen-reranker-0.6b`

| Metric | Mean left − right | Valid n | Wins / losses / ties |
|---|---:|---:|---:|
| ndcg@5 | -0.000 | 57 | 6 / 6 / 45 |
| ndcg@10 | 0.002 | 57 | 13 / 13 / 31 |
| top1 | 0.000 | 57 | 0 / 0 / 57 |
| mrr@10 | 0.000 | 57 | 0 / 0 / 57 |
| hit@10 | 0.000 | 57 | 0 / 0 / 57 |
| recall@10 | -0.002 | 57 | 6 / 7 / 44 |
| candidate_recall@50 | 0.100 | 57 | 30 / 2 / 25 |
| normalized_p5_grade_ge_2 | -0.004 | 57 | 2 / 4 / 51 |
| normalized_p5_grade_ge_3 | -0.001 | 57 | 2 / 3 / 52 |
| normalized_p5_grade_ge_4 | -0.023 | 29 | 1 / 1 / 27 |

兩組的候選池可能不同，因此差異不能全部歸因於同一重排器。完整逐題差異與勝負平手已存 analysis.json，不在文章新增真實題目案例。

### 官方 category／type 分項（僅描述性）

| Field | Label | n | Δ nDCG@10 | Wins / losses / ties |
|---|---|---:|---:|---:|
| category | Affirmative Covenants | 3 | n < 5 | — |
| category | Governing Law | 2 | n < 5 | — |
| category | IP Ownership/License | 3 | n < 5 | — |
| category | Indemnification | 14 | -0.004 | 1 / 2 / 11 |
| category | Limitation of Liability | 28 | -0.006 | 7 / 9 / 12 |
| category | Liquidated Damages | 1 | n < 5 | — |
| category | Restrictive Covenants | 4 | n < 5 | — |
| category | Term | 1 | n < 5 | — |
| category | third party beneficiary clause | 1 | n < 5 | — |
| type | cuad1 | 15 | 0.023 | 5 / 2 / 8 |
| type | cuad2 | 42 | -0.005 | 8 / 11 / 23 |

小於5題的分項只列題數；達門檻仍只是探索性描述，不能視為穩定優勢。僅使用官方標籤，未自行編造法律領域、難度或多跳分類。

## 協定與限制

- 已標註配對篩選使用了 qrels 的「是否受標註」資訊；未知配對移除，grade=0 保留。這不是一般 RAG 可取得的資訊。主協定 judged coverage 必然100%，不表示模型改善。
- nDCG 使用線性 grade 和完整 qrels IDCG；二元相關門檻 grade>=2。normalized P@5 分母為 min(5,完整 qrels 達門檻數)，並非一般固定分母 Precision@5。5星有效題數29；零分母存null並排除平均。
- 時間每組涵蓋57題，正式查詢實際執行 query embedding、完整搜尋、評估篩選與指定重排。total 為四階段加總，wall_total 另以單調時鐘量測。loopback HTTP 傳輸包含於對應推論階段；模型載入、語料準備與暖機另記。HTTP 傳輸及服務端排隊未能可靠拆分，仍包含於推論階段；獨立排隊時間保存 null。分位數採線性插值 type7。
- 完整語料與 query 向量快取僅可供經回歸驗證的品質準備；正式時間不可由快取讀取替代推論。詳見來源與 run manifest。
- 這57題可能有來源相依性，不將28×57視為1,596個獨立樣本。未確認可靠來源群聚，因此未做bootstrap或信賴區間；未做多重比較校正，不宣稱統計顯著。
- 本輪使用凍結 test 子集、Q8_0 GGUF、7個指定 Embedder、3個指定 Reranker 與 judged Top50。論文模型、切分與流程不同（原文兩階段範例為BM25 Top100）；不宣稱完整複製官方leaderboard。
- ACORD維持獨立法律專項，不納入首頁五分項或六分項平均。未發布網站。
- launcher與十模型原始SHA符合歷史pins；本輪另凍結動態函式庫hash。歷史manifest未提供所有動態函式庫hash，不能聲稱逐一歷史位元組身份已核實。

資料：ACORD，CC BY 4.0。revision `7ba1c6f2e0baaa32e78c78c2b02e9c57b102af4e`。本輪衍生變更為候選與評分協定，保留來源文字與標籤。

[ACORD paper, C.5 and F.1](https://aclanthology.org/2025.acl-long.1206.pdf) · [Dataset](https://huggingface.co/datasets/theatticusproject/acord)
