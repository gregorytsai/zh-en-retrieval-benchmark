"""Adversarial tests for the verifier; all fixture IDs/text are synthetic."""
import copy
import importlib.util
import json
import math
import random
import statistics
import sys
import tempfile
import unittest
from pathlib import Path

spec = importlib.util.spec_from_file_location('independent_validate', Path(__file__).resolve().parents[1] / 'src/independent_validate.py')
v = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = v
spec.loader.exec_module(v)


def dump(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')


def write_rows(path, rows):
    path.write_text(''.join(json.dumps(r, ensure_ascii=False) + '\n' for r in rows))


def fixture(root):
    docs = [f'd{i:03d}' for i in range(56)]
    qrels = {'q0': {d: 0 for d in docs[2:54]}, 'q1': {d: 0 for d in docs[1:55]}}
    qrels['q0'].update(d005=4, d006=2, d020=1)
    qrels['q1'].update(d001=1, d005=3, d020=2)
    data = {'corpus': [{'id': d, 'text': f'Synthetic document {d}'} for d in docs],
            'queries': [{'id': q, 'text': f'Synthetic query {q}'} for q in qrels], 'qrels': qrels}
    dump(root / 'frozen-data/acord.json', data)
    models = {m: {'sha256': 'a' * 64, 'registry': {'query_prefix': 'synthetic-prefix '}}
              for m in ('synthetic',) + v.RERANKERS[1:]}
    dump(root / 'models-manifest.json', {'models': models})
    run_id = 'synthetic-unit-test-only'
    dump(root / 'run-manifest.json', {'run_id': run_id, 'protocol_id': v.PROTOCOL,
         'corpus_cache_sha256': {'synthetic': 'c' * 64},
         'frozen_files_sha256': {'frozen-data/acord.json': v.file_hash(root / 'frozen-data/acord.json'),
                                'models-manifest.json': v.file_hash(root / 'models-manifest.json')}})
    scope = v.Scope(embedders=('synthetic',), queries=2, corpus=56, judgments=106,
                    judged_range=(52, 54), five_star_queries=1)
    full, pools, scores, results, times, summaries, traces, retrievals = [], [], [], [], [], [], [], []
    for q, judgments in qrels.items():
        ranking = [{'rank': i + 1, 'doc_id': d, 'similarity': (56 - i) / 64,
                    'judged': d in judgments} for i, d in enumerate(docs)]
        full.append({'run_id': run_id, 'embedder': 'synthetic', 'query_id': q,
                     'ranking': ranking, 'ranking_sha256': v.canonical_hash(ranking)})
        judged = [x for x in ranking if x['judged']]
        candidates = [x['doc_id'] for x in judged[:50]]
        ch = v.canonical_hash(candidates)
        pools.append({'embedder': 'synthetic', 'query_id': q, 'candidate_ids': candidates,
                      'original_ranks': [x['rank'] for x in judged[:50]],
                      'source_ranking_sha256': v.canonical_hash(ranking),
                      'similarity_sha256': v.canonical_hash([x['similarity'] for x in judged[:50]]),
                      'filter_protocol': 'judged-qrels-membership-v1', 'ordered_candidate_sha256': ch})
        for r in v.RERANKERS:
            config = f'synthetic__{r}'
            if r == 'standalone':
                order = [x['doc_id'] for x in judged]
            else:
                raw = {d: float(i % 5) for i, d in enumerate(candidates)}
                order = sorted(raw, key=lambda d: (-raw[d], d))
                for i, d in enumerate(candidates):
                    scores.append({'config_id': config, 'embedder': 'synthetic', 'reranker': r, 'query_id': q,
                                   'candidate_index': i, 'doc_id': d, 'score': raw[d], 'finite': True,
                                   'model_sha256': 'a' * 64, 'ordered_candidate_sha256': ch})
            stages = {'query_embedding': 1.25, 'retrieval': .125, 'evaluation_filter': .025,
                      'rerank': 0. if r == 'standalone' else 8.}
            stages['total'] = sum(stages.values())
            stages['wall_total'] = stages['total'] + .01
            start_ns = 1_000_000_000 + len(results) * 1_000_000_000
            end_ns = start_ns + round(stages['wall_total'] * 1e6)
            emb_request = f'{config}/{q}/embedding'
            rerank_request = f'{config}/{q}/rerank' if r != 'standalone' else None
            emb_body = {'input': [f'synthetic-prefix Synthetic query {q}'], 'encoding_format': 'float'}
            bodies = [('query_embedding', emb_request, 'synthetic', emb_body, v.canonical_hash([q]), 0, 1_000_000)]
            if r != 'standalone':
                body = {'query': f'Synthetic query {q}',
                        'documents': [f'Synthetic document {d}' for d in candidates], 'top_n': 50}
                bodies.append(('rerank', rerank_request, r, body, ch, 1_400_000, 9_000_000))
            for kind, rid, model, body, idhash, offset_a, offset_b in bodies:
                traces.append({'id': rid, 'run_id': run_id, 'attempt_id': 'synthetic-attempt',
                    'config_id': config, 'query_id': q, 'kind': kind, 'model_id': model,
                    'model_sha256': models[model]['sha256'], 'input_sha256': v.canonical_hash(body),
                    'input_ids_sha256': idhash, 'started_ns': start_ns + offset_a,
                    'finished_ns': start_ns + offset_b, 'status': 'ok', 'http_status': 200,
                    'output_vector_sha256': 'd' * 64 if kind == 'query_embedding' else None,
                    'grade_fields_absent': True, 'payload_field_names': sorted(body)})
            results.append({'run_id': run_id, 'protocol_id': v.PROTOCOL, 'config_id': config,
                'embedder': 'synthetic', 'reranker': r, 'query_id': q, 'status': 'ok',
                'candidate_sha256': ch, 'final_doc_ids': order,
                'metrics': v.recompute(order, judgments, candidates), 'times_ms': stages,
                'provenance': {'query_embedding': 'fresh_inference', 'attempt_id': 'synthetic-attempt',
                               'embedding_request_id': emb_request, 'rerank_request_id': rerank_request,
                               'rerank': 'not_applicable' if r == 'standalone' else 'fresh_inference'}})
            times.append({'run_id': run_id, 'config_id': config, 'query_id': q, 'times_ms': stages,
                          'monotonic_start_ns': start_ns, 'monotonic_end_ns': end_ns,
                          'warmup': False, 'repeat_id': 0, 'source': 'fresh_inference'})
            retrievals.append({'run_id': run_id, 'config_id': config, 'embedder': 'synthetic', 'query_id': q,
                              'embedding_request_id': emb_request, 'query_vector_sha256': 'd' * 64,
                              'corpus_cache_sha256': 'c' * 64, 'corpus_documents': 56,
                              'full_ranking_sha256': v.canonical_hash(ranking), 'ordered_candidate_sha256': ch})
    for r in v.RERANKERS:
        config = f'synthetic__{r}'
        subset = [x for x in results if x['config_id'] == config]
        metrics = {}
        for name in subset[0]['metrics']:
            values = [x['metrics'][name] for x in subset if x['metrics'][name] is not None]
            metrics[name] = {'mean': statistics.mean(values) if values else None, 'valid_n': len(values)}
        timings = {}
        for name in v.STAGES:
            values = [x['times_ms'][name] for x in subset]
            timings[name] = {'mean': statistics.mean(values), 'n': len(values),
                             'p50': v.quantile(values, .5), 'p95': v.quantile(values, .95)}
        summaries.append({'config_id': config, 'embedder': 'synthetic', 'reranker': r,
                          'n': 2, 'failed': 0, 'metrics': metrics, 'times_ms': timings})
    for name, values in [('full-retrieval-rankings.jsonl', full), ('candidates.jsonl', pools),
                          ('reranker-scores.jsonl', scores), ('query-results.jsonl', results),
                          ('timing-results.jsonl', times), ('request-trace.jsonl', traces),
                          ('retrieval-attempts.jsonl', retrievals)]:
        write_rows(root / name, values)
    dump(root / 'summary.json', summaries)
    return scope


class MathTests(unittest.TestCase):
    def test_linear_complete_qrels_idcg_hand_calculation(self):
        j = {'a': 4, 'b': 2, 'c': 0, 'd': 1}
        got = v.recompute(['c', 'b', 'd'], j, ['c', 'b', 'd'])
        expected = (2 / math.log2(3) + 1 / math.log2(4)) / (4 + 2 / math.log2(3) + 1 / math.log2(4))
        self.assertAlmostEqual(got['ndcg@5'], expected)
        self.assertEqual(got['top1'], 0)
        self.assertEqual(got['mrr@10'], .5)
        self.assertEqual(got['hit@10'], 1)
        self.assertEqual(got['recall@10'], .5)
        self.assertEqual(got['candidate_recall@50'], .5)
        self.assertEqual(got['normalized_p5_grade_ge_2'], .5)

    def test_grade_zero_is_valid_unknown_is_error(self):
        self.assertEqual(v.recompute(['z', 'a'], {'z': 0, 'a': 2}, ['z', 'a'])['top1'], 0)
        with self.assertRaises(v.Invalid):
            v.recompute(['missing', 'a'], {'z': 0, 'a': 2}, ['z', 'a'])

    def test_grade_one_is_not_binary_relevant(self):
        got = v.recompute(['x', 'y'], {'x': 1, 'y': 2}, ['x', 'y'])
        self.assertEqual(got['mrr@10'], .5)
        self.assertEqual(got['top1'], 0)

    def test_null_denominators_and_normalized_precision(self):
        got = v.recompute(['b', 'a'], {'a': 2, 'b': 0}, ['b', 'a'])
        self.assertEqual(got['normalized_p5_grade_ge_2'], 1)
        self.assertIsNone(got['normalized_p5_grade_ge_4'])
        zero = v.recompute(['a'], {'a': 0}, ['a'])
        self.assertIsNone(zero['ndcg@10'])
        self.assertIsNone(zero['recall@10'])
        self.assertEqual(zero['hit@10'], 0)

    def test_duplicate_and_empty_rank_rejected(self):
        for order in ([], ['a', 'a']):
            with self.assertRaises(v.Invalid):
                v.recompute(order, {'a': 2}, ['a'])

    def test_type7_quantile(self):
        self.assertEqual(v.quantile([0, 10], .95), 9.5)
        self.assertEqual(v.quantile([5], .5), 5)

    def test_duplicate_json_keys_rejected(self):
        with self.assertRaises(v.Invalid):
            v.decode('{"a":0,"a":4}')

    def test_cross_implementation_randomized_metrics(self):
        # The validator itself imports no runner functions. This test deliberately
        # compares the two separately maintained algorithms over 100 fixed cases.
        sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
        try:
            import scoring
        finally:
            sys.path.pop(0)
        rng = random.Random(20261027)
        for _ in range(100):
            ids = [f'synthetic-doc-{i:03d}' for i in range(75)]
            j = {d: rng.randrange(5) for d in ids}
            j[ids[0]] = 2
            rng.shuffle(ids)
            pool = ids[:50]
            final = pool.copy()
            rng.shuffle(final)
            a = v.recompute(final, j, pool)
            b = scoring.evaluate_ranking(final, pool, j)
            self.assertEqual(set(a), set(b))
            for metric in a:
                if a[metric] is None:
                    self.assertIsNone(b[metric])
                else:
                    self.assertAlmostEqual(a[metric], b[metric], places=13)


class MutationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.scope = fixture(self.root)

    def tearDown(self):
        self.temp.cleanup()

    def mutate(self, filename, change):
        path = self.root / filename
        rows = list(v.lines(path)) if filename.endswith('jsonl') else v.read(path)
        change(rows)
        if filename.endswith('jsonl'):
            write_rows(path, rows)
        else:
            dump(path, rows)
        with self.assertRaises(v.Invalid):
            v.validate(self.root, self.scope)

    def test_valid_complete_synthetic_packet(self):
        result = v.validate(self.root, self.scope)
        self.assertEqual(result['status'], 'passed')
        self.assertEqual(result['counts']['pair_scores'], 300)

    def test_missing_final_row(self):
        self.mutate('query-results.jsonl', lambda rows: rows.pop())

    def test_duplicate_row(self):
        self.mutate('query-results.jsonl', lambda rows: rows.append(copy.deepcopy(rows[0])))

    def test_filter_after_top50_rejected(self):
        def change(rows):
            rows[0]['candidate_ids'] = rows[0]['candidate_ids'][:48]
            rows[0]['ordered_candidate_sha256'] = v.canonical_hash(rows[0]['candidate_ids'])
        self.mutate('candidates.jsonl', change)

    def test_unknown_marked_judged_even_with_updated_hash(self):
        def change(rows):
            rows[0]['ranking'][0]['judged'] = True
            rows[0]['ranking_sha256'] = v.canonical_hash(rows[0]['ranking'])
        self.mutate('full-retrieval-rankings.jsonl', change)

    def test_full_score_order_error(self):
        def change(rows):
            rows[0]['ranking'][0]['similarity'] = -1
            rows[0]['ranking_sha256'] = v.canonical_hash(rows[0]['ranking'])
        self.mutate('full-retrieval-rankings.jsonl', change)

    def test_nan_score(self):
        self.mutate('reranker-scores.jsonl', lambda rows: rows[0].update(score=float('nan')))

    def test_duplicate_score(self):
        self.mutate('reranker-scores.jsonl', lambda rows: rows.append(copy.deepcopy(rows[0])))

    def test_candidate_index_wrong(self):
        self.mutate('reranker-scores.jsonl', lambda rows: rows[0].update(candidate_index=1))

    def test_pair_model_missing(self):
        self.mutate('reranker-scores.jsonl', lambda rows: rows[0].pop('model_sha256'))

    def test_candidate_hash_wrong(self):
        self.mutate('query-results.jsonl', lambda rows: rows[1].update(candidate_sha256='0'*64))

    def test_final_tie_rule_wrong(self):
        def change(rows):
            order = rows[1]['final_doc_ids']
            order[0], order[1] = order[1], order[0]
        self.mutate('query-results.jsonl', change)

    def test_summary_forged(self):
        self.mutate('summary.json', lambda rows: rows[0]['metrics']['ndcg@10'].update(mean=1))

    def test_null_metric_replaced_with_zero(self):
        self.mutate('query-results.jsonl', lambda rows: rows[-1]['metrics'].update(normalized_p5_grade_ge_4=0))

    def test_valid_n_wrong(self):
        self.mutate('summary.json', lambda rows: rows[0]['metrics']['normalized_p5_grade_ge_4'].update(valid_n=2))

    def test_stage_sum_wrong(self):
        self.mutate('query-results.jsonl', lambda rows: rows[0]['times_ms'].update(total=50))

    def test_cached_query_timing(self):
        self.mutate('query-results.jsonl', lambda rows: rows[0]['provenance'].update(query_embedding='cached'))

    def test_warmup_in_formal_timing(self):
        self.mutate('timing-results.jsonl', lambda rows: rows[0].update(warmup=True))

    def test_repeat_in_formal_timing(self):
        self.mutate('timing-results.jsonl', lambda rows: rows[0].update(repeat_id=1))

    def test_truncation(self):
        self.mutate('query-results.jsonl', lambda rows: rows[0].update(truncated=True))

    def test_changed_frozen_dataset(self):
        self.mutate('frozen-data/acord.json', lambda data: data['queries'][0].update(text='changed'))

    def test_model_hash_wrong_but_well_formed(self):
        self.mutate('reranker-scores.jsonl', lambda rows: rows[0].update(model_sha256='b'*64))

    def test_request_body_hash_wrong(self):
        self.mutate('request-trace.jsonl', lambda rows: rows[0].update(input_sha256='b'*64))

    def test_request_unknown_label_field(self):
        self.mutate('request-trace.jsonl', lambda rows: rows[0]['payload_field_names'].append('grade'))

    def test_failed_http_request(self):
        self.mutate('request-trace.jsonl', lambda rows: rows[0].update(http_status=500))

    def test_request_outside_interval(self):
        self.mutate('request-trace.jsonl', lambda rows: rows[0].update(started_ns=1))

    def test_wrong_monotonic_wall_time(self):
        self.mutate('timing-results.jsonl', lambda rows: rows[0].update(monotonic_end_ns=2_000_000_000))

    def test_request_trace_reuse(self):
        self.mutate('query-results.jsonl', lambda rows: rows[1]['provenance'].update(
                    embedding_request_id=rows[0]['provenance']['embedding_request_id']))

    def test_retrieval_not_from_new_embedding(self):
        self.mutate('retrieval-attempts.jsonl', lambda rows: rows[0].update(embedding_request_id='historical'))

    def test_retrieval_changed_without_evidence(self):
        self.mutate('retrieval-attempts.jsonl', lambda rows: rows[0].update(full_ranking_sha256='b'*64))

    def test_search_vector_different_from_response(self):
        self.mutate('request-trace.jsonl', lambda rows: rows[0].update(output_vector_sha256='e'*64))

    def test_retrieval_not_whole_corpus(self):
        self.mutate('retrieval-attempts.jsonl', lambda rows: rows[0].update(corpus_documents=50))

    def test_retrieval_substituted_corpus(self):
        self.mutate('retrieval-attempts.jsonl', lambda rows: rows[0].update(corpus_cache_sha256='e'*64))


if __name__ == '__main__':
    unittest.main()
