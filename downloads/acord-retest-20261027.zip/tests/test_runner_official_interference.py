"""Guard-confirmed HTTP failures retry whole official/warmup units."""
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import numpy as np

from src import owned_guard, runner, runtime


class EpochChangingGuard:
    def __init__(self):
        self.checks = 0
        self.aborted = []
        self.epoch = 4

    def wait_idle(self, check_deadline):
        check_deadline()

    def check_deadline(self):
        return None

    def begin_unit(self, unit_id):
        self.unit_id = unit_id

    def check(self):
        self.checks += 1
        if self.checks >= 2:
            raise owned_guard.Interference("external traffic invalidated active epoch")

    def abort_unit(self, unit_id, reason):
        self.aborted.append((unit_id, reason))

    def finish_unit(self, unit_id):
        return None


class OfficialInterferenceTests(unittest.TestCase):
    def test_guard_killed_embedding_http_preserves_trace_and_raises_interference(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            runner.write_json_atomic(root / "run-manifest.json", {"run_id": "run-test"})
            guard = EpochChangingGuard()
            trace = {"id": "req-failed", "kind": "query_embedding", "status": "error"}
            failure = runtime.HttpInferenceError("ConnectionResetError: server was stopped", trace)
            with patch.object(runtime, "traced_embedding", side_effect=failure):
                with self.assertRaises(owned_guard.Interference):
                    runner.measure_query(
                        root, {"run_id": "run-test"}, {}, embedder="qwen-4b",
                        reranker="standalone", query={"id": "q1", "text": "query"},
                        corpus=[{"id": "d1", "text": "doc"}],
                        doc_by_id={"d1": {"id": "d1", "text": "doc"}},
                        qrels={"d1": 2}, corpus_matrix=np.ones((1, 2), dtype=np.float32),
                        corpus_hash="a" * 64, embed_server=object(), rerank_server=None,
                        embed_model={"sha256": "b" * 64,
                                     "registry": {"query_prefix": "", "dimension": 2}},
                        rerank_model=None, reference_candidates=["d1"], guard=guard,
                        ensure_servers=lambda: (object(), None))

            self.assertEqual(len(guard.aborted), 1)
            attempts = runner.read_jsonl(root / "failed-attempts.jsonl")
            self.assertEqual(len(attempts), 1)
            self.assertEqual(attempts[0]["failure_kind"], "guard_interference")
            self.assertEqual(attempts[0]["original_exception_type"], "HttpInferenceError")
            self.assertEqual(attempts[0]["original_http_trace"], trace)
            validity = next(root.glob("attempts/*/q1/*/validity.json"))
            self.assertEqual(runner.read_json(validity)["original_http_trace"], trace)
            self.assertEqual(runner.read_json(validity.parent / "request-traces.json"), [trace])

    def test_guard_interference_during_server_warmup_is_reclassified(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            runner.write_json_atomic(root / "run-manifest.json", {"run_id": "run-test"})
            guard = EpochChangingGuard()

            class BrokenCore:
                def embed(self, *args, **kwargs):
                    raise runtime.HttpInferenceError(
                        "ConnectionResetError: warmup server stopped",
                        {"id": "warmup-request", "kind": "embedding", "status": "error"})

            server = SimpleNamespace()
            model = {"sha256": "c" * 64,
                     "registry": {"kind": "embedding", "query_prefix": "",
                                  "document_prefix": "", "dimension": 2}}
            with patch.object(runtime, "fixed_fixtures", return_value=[("query", "positive", "negative")]):
                with self.assertRaises(owned_guard.Interference):
                    runner.warm_loaded_server(BrokenCore(), guard, server, "qwen-4b", model, root)

            self.assertEqual(len(guard.aborted), 1)
            events = runner.read_jsonl(root / "warmup-events.jsonl")
            self.assertEqual(len(events), 1)
            self.assertEqual(events[0]["status"], "rejected")
            self.assertEqual(events[0]["failure"].split(":", 1)[0], "HttpInferenceError")
            self.assertEqual(events[0]["guard_interference"], "external traffic invalidated active epoch")

    def test_ordinary_http_failure_is_not_reclassified_without_guard_evidence(self):
        guard = EpochChangingGuard()
        guard.check = lambda: None
        error = runtime.HttpInferenceError("ordinary HTTP failure", {"id": "req-ordinary"})
        result = runner._guard_interference_after_exception(guard, error, unit_started=True)
        self.assertIsNone(result)


if __name__ == "__main__":
    unittest.main()
