import json
import tempfile
import threading
import time
import unittest
from pathlib import Path
from unittest.mock import patch

from src import owned_guard as g


class FakeProcess:
    def __init__(self, pid):
        self.pid = pid
        self.terminated = 0
        self.killed = 0
        self.returncode = None

    def poll(self):
        return self.returncode

    def terminate(self):
        self.terminated += 1

    def kill(self):
        self.killed += 1
        self.returncode = -9


class FakeServer:
    def __init__(self, pid):
        self.process = FakeProcess(pid)


class IgnoreTermProcess(FakeProcess):
    def terminate(self):
        self.terminated += 1


class FastExitProcess(FakeProcess):
    def terminate(self):
        self.terminated += 1
        self.returncode = 0


class GuardTests(unittest.TestCase):
    def make_guard(self, path, clock=lambda: 100.0):
        return g.OwnedTrafficGuard(Path(path), deadline_epoch=9999999999, clock=clock)

    def test_metrics_require_complete_fail_closed_fields(self):
        body = "\n".join([
            "llamacpp:requests_processing 0",
            "llamacpp:requests_deferred 0",
            "llamacpp:n_decode_total 2",
            "llamacpp:prompt_tokens_total 10",
            "llamacpp:tokens_predicted_total 5",
        ])
        self.assertEqual(g.parse_metrics(body)["n_decode_total"], 2)
        with self.assertRaises(ValueError):
            g.parse_metrics("llamacpp:requests_processing 0")

    def test_metrics_reject_nonfinite_and_negative_values(self):
        base = "\n".join([
            "llamacpp:requests_processing 0",
            "llamacpp:requests_deferred 0",
            "llamacpp:n_decode_total 2",
            "llamacpp:prompt_tokens_total 10",
            "llamacpp:tokens_predicted_total 5",
        ])
        for bad in ("nan", "inf", "-inf", "-1"):
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                g.parse_metrics(base.replace("llamacpp:n_decode_total 2", f"llamacpp:n_decode_total {bad}"))

    def test_discover_excludes_only_explicit_owned_pids(self):
        output = "\n".join([
            "100 1 /opt/llama-server --port 8001",
            "101 200 /opt/llama-server --port 8002",
            "102 1 /opt/llama-server --models-preset preset --port 8003",
        ])
        with patch.object(g.subprocess, "run", return_value=type("R", (), {"stdout": output})()):
            workers, routers = g.discover({101})
        self.assertEqual(workers, {100: 8001})
        self.assertEqual(routers, {102: 8003})

    def test_external_activity_terminates_every_owned_server_only_once(self):
        with tempfile.TemporaryDirectory() as td:
            guard = self.make_guard(Path(td) / "events.jsonl")
            embed = FakeServer(101)
            rerank = FakeServer(102)
            guard.register("embed", embed)
            guard.register("rerank", rerank)
            guard._terminate_owned("external request")
            guard._terminate_owned("same continuing request")
            self.assertEqual((embed.process.terminated, rerank.process.terminated), (1, 1))
            self.assertEqual((embed.process.killed, rerank.process.killed), (0, 0))
            guard._escalate_terminated(103.0)
            self.assertEqual((embed.process.killed, rerank.process.killed), (1, 1))
            guard._pool.shutdown(wait=True)

    def test_dead_process_pid_is_not_excluded_as_owned(self):
        with tempfile.TemporaryDirectory() as td:
            guard = self.make_guard(Path(td) / "events.jsonl")
            alive = FakeServer(111)
            dead = FakeServer(112)
            dead.process.returncode = 0
            guard.register("alive", alive)
            guard.register("dead", dead)
            seen = {}
            original_discover = g.discover
            def discover(pids):
                seen["pids"] = pids
                return {}, {}
            with patch.object(g, "discover", side_effect=discover):
                guard.snapshot()
            self.assertEqual(seen["pids"], {111})
            guard.unregister("alive", alive)
            guard.unregister("dead", dead)
            guard._pool.shutdown(wait=True)

    def test_log_failure_terminates_all_owned_servers(self):
        with tempfile.TemporaryDirectory() as td:
            guard = self.make_guard(Path(td) / "events.jsonl")
            embed = FakeServer(121)
            rerank = FakeServer(122)
            guard.register("embed", embed)
            guard.register("rerank", rerank)
            guard.snapshot = lambda: {"workers": {}, "routers": {}}
            def broken_write(event, **fields):
                if event == "snapshot":
                    raise OSError("disk full")
            guard._write = broken_write
            guard.poll()
            self.assertEqual((embed.process.terminated, rerank.process.terminated), (1, 1))
            self.assertIn("log unavailable", guard.reason)
            guard._pool.shutdown(wait=True)

    def test_deadman_kills_servers_when_monitor_stalls(self):
        with tempfile.TemporaryDirectory() as td:
            clock = lambda: 100.0
            guard = self.make_guard(Path(td) / "events.jsonl", clock=clock)
            owned = FakeServer(131)
            guard.register("embed", owned)
            guard._thread = type("ThreadAlive", (), {"is_alive": lambda self: True})()
            with guard._heartbeat_lock:
                guard._heartbeat = 90.0
            self.assertFalse(guard._deadman_check())
            self.assertEqual(owned.process.terminated, 1)
            self.assertIn("heartbeat stale", guard.reason)
            guard._pool.shutdown(wait=True)

    def test_stale_monitor_check_terminates_owned_servers(self):
        with tempfile.TemporaryDirectory() as td:
            guard = self.make_guard(Path(td) / "events.jsonl", clock=lambda: 100.0)
            owned = FakeServer(141)
            guard.register("reranker", owned)
            guard._last_poll = 90.0
            guard._reason = None
            with self.assertRaises(g.Interference):
                guard.check_environment()
            self.assertEqual(owned.process.terminated, 1)
            guard._pool.shutdown(wait=True)

    def test_all_servers_get_term_before_a_blocked_event_log(self):
        with tempfile.TemporaryDirectory() as td:
            guard = self.make_guard(Path(td) / "events.jsonl")
            embed = FakeServer(151)
            rerank = FakeServer(152)
            guard.register("embed", embed)
            guard.register("rerank", rerank)
            guard._event_lock.acquire()
            worker = threading.Thread(target=guard._terminate_owned, args=("failure",))
            worker.start()
            limit = time.monotonic() + 1.0
            while time.monotonic() < limit and (embed.process.terminated, rerank.process.terminated) != (1, 1):
                time.sleep(0.01)
            observed = (embed.process.terminated, rerank.process.terminated)
            guard._event_lock.release()
            worker.join(timeout=2)
            self.assertEqual(observed, (1, 1))
            self.assertFalse(worker.is_alive())
            guard._pool.shutdown(wait=True)

    def test_reaper_kills_term_ignoring_server_after_monitor_death(self):
        with tempfile.TemporaryDirectory() as td:
            now = [100.0]
            guard = self.make_guard(Path(td) / "events.jsonl", clock=lambda: now[0])
            owned = FakeServer(161)
            owned.process = IgnoreTermProcess(161)
            guard.register("embed", owned)
            guard._thread = type("DeadThread", (), {"is_alive": lambda self: False})()
            reaper = threading.Thread(target=guard._reaper_loop, daemon=True)
            guard._reaper_thread = reaper
            reaper.start()
            self.assertFalse(guard._deadman_check())
            limit = time.monotonic() + 1.0
            while time.monotonic() < limit and owned.process.terminated == 0:
                time.sleep(0.01)
            self.assertEqual(owned.process.terminated, 1)
            now[0] = 103.0
            limit = time.monotonic() + 1.0
            while time.monotonic() < limit and owned.process.killed == 0:
                time.sleep(0.01)
            guard._reaper_stop.set()
            reaper.join(timeout=1)
            self.assertEqual(owned.process.killed, 1)
            self.assertFalse(reaper.is_alive())
            guard._pool.shutdown(wait=True)

    def test_wait_idle_aborts_on_fatal_guard(self):
        with tempfile.TemporaryDirectory() as td:
            guard = self.make_guard(Path(td) / "events.jsonl")
            guard._fatal_reason = "monitor cannot write evidence"
            with self.assertRaises(g.Interference):
                guard.wait_idle(lambda: None)
            guard._pool.shutdown(wait=True)

    def test_preflight_failure_cleanup_stops_both_owned_servers_not_external(self):
        with tempfile.TemporaryDirectory() as td:
            guard = self.make_guard(Path(td) / "events.jsonl")
            guard.snapshot = lambda: {"workers": {}, "routers": {}}
            guard.start()
            owned = FakeServer(171)
            owned.process = FastExitProcess(171)
            owned_reranker = FakeServer(173)
            owned_reranker.process = FastExitProcess(173)
            external = FakeServer(172)
            external.process = FastExitProcess(172)
            def failed_preflight():
                guard.register("preflight-owned-reranker", owned)
                guard.register("preflight-owned-embedder", owned_reranker)
                raise RuntimeError("synthetic token audit failure")
            with self.assertRaisesRegex(RuntimeError, "synthetic token audit failure"):
                try:
                    failed_preflight()
                finally:
                    guard.close()

            self.assertEqual(owned.process.terminated, 1)
            self.assertEqual(owned_reranker.process.terminated, 1)
            self.assertEqual(external.process.terminated, 0)
            events = [json.loads(line)["event"] for line in
                      (Path(td) / "events.jsonl").read_text().splitlines()]
            self.assertEqual(events[-1], "guard_closed")

    def test_poll_fails_closed_and_advances_epoch_on_external_busy(self):
        with tempfile.TemporaryDirectory() as td:
            guard = self.make_guard(Path(td) / "events.jsonl")
            owned = FakeServer(201)
            guard.register("embedding", owned)
            guard._previous = {"workers": {}, "routers": {}}
            guard.snapshot = lambda: {
                "workers": {999: {"busy": True, "counters": {"n_decode_total": 1}}},
                "routers": {},
            }
            guard.poll()
            self.assertEqual(guard.epoch, 1)
            self.assertIn("processing", guard.reason)
            self.assertEqual(owned.process.terminated, 1)
            guard._pool.shutdown(wait=True)

    def test_unit_finish_rejects_epoch_change(self):
        with tempfile.TemporaryDirectory() as td:
            guard = self.make_guard(Path(td) / "events.jsonl")
            guard._thread = None
            snapshot = {"workers": {}, "routers": {}}
            guard._previous = snapshot
            guard._last_poll = guard.clock()
            guard._last_activity = guard.clock() - 31
            guard._reason = None
            guard.snapshot = lambda: snapshot
            guard.begin_unit("qwen-4b__standalone/q0/attempt-1")
            guard._epoch += 1
            with self.assertRaises(g.Interference):
                guard.finish_unit("qwen-4b__standalone/q0/attempt-1")
            guard._pool.shutdown(wait=True)


if __name__ == "__main__":
    unittest.main()
