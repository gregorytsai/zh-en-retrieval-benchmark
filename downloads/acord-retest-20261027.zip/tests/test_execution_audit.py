import copy
import unittest
from src.audit_execution import EvidenceError, audit_guard_units, audit_server_events


class ExecutionEvidenceTests(unittest.TestCase):
    def setUp(self):
        self.unit = 'e__standalone/q/a'
        self.events = [
            {'event': 'guard_unit_started', 'unit_id': self.unit, 'traffic_epoch': 2,
             'quiet_seconds': 30, 'poll_period_seconds': 1, 'owned_pids': {'e': 100}, 'monotonic': 10.0},
            {'event': 'snapshot', 'epoch': 2, 'reason': None, 'monotonic': 10.5},
            {'event': 'guard_unit_finished', 'unit_id': self.unit, 'traffic_epoch': 2,
             'owned_pids': {'e': 100}, 'monotonic': 11.0}]
        self.query = [{'config_id': 'e__standalone', 'query_id': 'q', 'provenance': {'attempt_id': 'a'}}]
        self.timing = [{'config_id': 'e__standalone', 'query_id': 'q',
                        'monotonic_start_ns': 10200000000, 'monotonic_end_ns': 10800000000}]

    def test_clean_interval(self):
        self.assertEqual(audit_guard_units(self.events, self.query, self.timing)['accepted_guard_units'], 1)

    def test_rejected_attempt_cannot_be_accepted(self):
        self.events.append({'event': 'guard_unit_aborted', 'unit_id': self.unit})
        with self.assertRaises(EvidenceError):
            audit_guard_units(self.events, self.query, self.timing)

    def test_interference_not_hidden_by_final_epoch(self):
        self.events[1]['reason'] = 'external activity'
        with self.assertRaises(EvidenceError):
            audit_guard_units(self.events, self.query, self.timing)

    def test_stale_gap(self):
        self.events[-1]['monotonic'] = 20
        with self.assertRaises(EvidenceError):
            audit_guard_units(self.events, self.query, self.timing)

    def test_timing_outside_guard(self):
        self.timing[0]['monotonic_start_ns'] = 9000000000
        with self.assertRaises(EvidenceError):
            audit_guard_units(self.events, self.query, self.timing)

    def test_full_gpu_and_shutdown_required(self):
        command = ['server', '--n-gpu-layers', 'all', '--ctx-size', '8192', '--parallel', '1',
                   '--batch-size', '4096', '--ubatch-size', '4096']
        events = [{'event': 'server_loaded', 'model_id': 'e', 'pid': 100,
                   'gpu_offload': [29, 29], 'command': command},
                  {'event': 'server_stopped', 'pid': 100}]
        self.assertEqual(audit_server_events(events)['models_loaded'], ['e'])
        with self.assertRaises(EvidenceError):
            audit_server_events(events[:1])
        bad = copy.deepcopy(events)
        bad[0]['gpu_offload'] = [28, 29]
        with self.assertRaises(EvidenceError):
            audit_server_events(bad)


if __name__ == '__main__':
    unittest.main()
