import copy
import unittest

from src import analyze_results as a
from src import independent_validate as v


class AnalysisTests(unittest.TestCase):
    def test_pairing_is_by_query_and_null_excluded(self):
        left = {'b': {'metrics': {'x': None}}, 'a': {'metrics': {'x': .7}}}
        right = {'a': {'metrics': {'x': .2}}, 'b': {'metrics': {'x': 0.}}}
        r = a.paired(left, right, {'a', 'b'}, ['x'])['x']
        self.assertEqual(r['valid_n'], 1)
        self.assertEqual(r['wins'], 1)
        self.assertEqual(r['excluded_query_ids'], ['b'])
        self.assertAlmostEqual(r['mean_difference'], .5)

    def test_tie_policy_is_explicit(self):
        r = a.paired({'q': {'metrics': {'x': .5 + 1e-14}}},
                     {'q': {'metrics': {'x': .5}}}, ['q'], ['x'])['x']
        self.assertEqual((r['wins'], r['losses'], r['ties']), (0, 0, 1))

    def test_study_cluster_not_promoted(self):
        r = a.dependency_metadata([{'id': 'q', 'metadata': {'parent_query_id': ''},
                                   'study_metadata': {'cluster_id': 'invented'}}])
        self.assertEqual(r['official_fields']['cluster_id']['nonempty_queries'], 0)
        self.assertFalse(r['bootstrap_performed'])

    def fixture(self):
        data = {'queries': [{'id': 'q', 'metadata': {'category': 'synthetic'}, 'text': 'DO_NOT_PUBLISH_QUERY_TEXT'}],
                'qrels': {'q': {'a': 4, 'b': 2, 'c': 0}}}
        candidates, results, summaries = [], [], []
        for e in v.EMBEDDERS:
            candidates.append({'embedder': e, 'query_id': 'q', 'candidate_ids': ['a', 'b']})
            for rr in v.RERANKERS:
                config = f'{e}__{rr}'
                order = ['b', 'a'] if rr == 'standalone' else ['a', 'b']
                metrics = v.recompute(order, data['qrels']['q'], ['a', 'b'])
                results.append({'config_id': config, 'query_id': 'q', 'metrics': metrics})
                summaries.append({'config_id': config, 'embedder': e, 'reranker': rr,
                    'metrics': {k: {'mean': val, 'valid_n': 1} for k, val in metrics.items()},
                    'times_ms': {'total': {'mean': 10., 'p50': 10., 'p95': 10., 'n': 1}}})
        models = {name: {'bytes': 1024} for name in (*v.EMBEDDERS, *v.RERANKERS[1:])}
        return data, results, candidates, models, summaries

    def test_candidate_oracle_gaps_are_zero_for_ideal_reranker(self):
        r = a.build_analysis(*self.fixture())
        for row in r['candidate_capacity']:
            self.assertAlmostEqual(row['candidate_limit_gap_ndcg@10']['mean'], 0.)
            for gap in row['within_candidate_ordering_gap_ndcg@10'].values():
                self.assertAlmostEqual(gap['mean'], 0.)
        self.assertEqual(r['specified_pair']['left'], a.PAIR_LEFT)
        self.assertEqual(r['specified_pair']['right'], a.PAIR_RIGHT)
        self.assertFalse(r['official_metadata_strata'][0]['descriptive_comparison_included'])

    def test_duplicate_query_rejected(self):
        args = list(self.fixture()); args[1].append(copy.deepcopy(args[1][0]))
        with self.assertRaises(v.Invalid):
            a.build_analysis(*args)

    def test_reports_have_no_query_text_or_false_completion(self):
        args = self.fixture(); result = a.build_analysis(*args)
        for language in (True, False):
            text = a.render_report(result, args[4], 'synthetic-test', language)
            self.assertNotIn('DO_NOT_PUBLISH_QUERY_TEXT', text)
            self.assertIn('validation-report.json', text)
            self.assertIn(a.PAIR_LEFT, text)
            self.assertIn(a.PAIR_RIGHT, text)
        self.assertIsNone(result['weight_capacity'][0]['measured_peak_ram_gib'])


if __name__ == '__main__':
    unittest.main()
