import math
import unittest

from src.scoring import (
    ScoringError,
    evaluate_ranking,
    filter_judged_top50,
    ordered_candidate_hash,
    ranked_entry_hash,
    sha256_canonical,
    stable_full_ranking,
)


class ScoringTests(unittest.TestCase):
    def test_float32_rank_and_doc_id_tie_break(self):
        rows = stable_full_ranking(["z", "b", "a"], [1.0, 1.0, 0.5])
        self.assertEqual([r["doc_id"] for r in rows], ["b", "z", "a"])
        self.assertEqual([r["rank"] for r in rows], [1, 2, 3])
        self.assertTrue(all(r["judged"] is False for r in rows))
        self.assertEqual(rows[0]["similarity"], 1.0)

    def test_filter_unknown_before_top50_and_keep_explicit_zero(self):
        qrels = {f"d{i:02d}": (0 if i == 0 else 1) for i in range(51)}
        full = []
        for i in range(10):
            full.append({"rank": i + 1, "doc_id": f"unknown{i}", "similarity": 1.0-i/100, "judged": False})
        full.extend({"rank": i + 11, "doc_id": f"d{i:02d}", "similarity": 0.5-i/100, "judged": True} for i in range(51))
        ids, ranks = filter_judged_top50(full, qrels)
        self.assertEqual(len(ids), 50)
        self.assertEqual(ids[0], "d00")
        self.assertEqual(ids[-1], "d49")
        self.assertEqual(ranks, list(range(11, 61)))
        self.assertNotIn("d50", ids)

    def test_judged_filter_fails_if_fewer_than_50(self):
        qrels = {f"d{i}": 0 for i in range(49)}
        full = [{"rank":i+1,"doc_id":f"d{i}","similarity":1.0-i/100} for i in range(49)]
        with self.assertRaises(ScoringError):
            filter_judged_top50(full, qrels)

    def test_duplicate_after_candidate_cutoff_still_fails(self):
        qrels = {f"d{i:02d}": 0 for i in range(50)}
        full = [
            {"rank": i + 1, "doc_id": f"d{i:02d}", "similarity": 1.0 - i / 1000}
            for i in range(50)
        ]
        # The valid top 50 are already collected; validators must still scan the
        # full ranking and reject a duplicate appearing in its tail.
        full.append({"rank": 51, "doc_id": "d00", "similarity": 0.0})
        with self.assertRaises(ScoringError):
            filter_judged_top50(full, qrels)

    def test_metrics_use_linear_grade_and_full_qrels_idcg(self):
        qrels = {"a":4,"b":3,"c":2,"d":1,"e":0,"f":0}
        candidates = ["a","b","c","d","e","f"] + [f"x{i}" for i in range(44)]
        # Candidate protocol requires judged IDs only, so fill with additional explicit-zero judgments.
        qrels.update({f"z{i}":0 for i in range(44)})
        candidates = ["a","b","c","d","e","f"] + [f"z{i}" for i in range(44)]
        ranked = ["a","e","b","c","d","f"]
        m = evaluate_ranking(ranked, candidates, qrels)
        numerator = 4 + 0/math.log2(3) + 3/math.log2(4) + 2/math.log2(5) + 1/math.log2(6)
        denominator = 4 + 3/math.log2(3) + 2/math.log2(4) + 1/math.log2(5)
        self.assertAlmostEqual(m["ndcg@5"], numerator/denominator)
        self.assertEqual(m["top1"], 1)
        self.assertEqual(m["hit@10"], 1)
        self.assertEqual(m["mrr@10"], 1.0)
        self.assertAlmostEqual(m["recall@10"], 1.0)
        self.assertAlmostEqual(m["candidate_recall@50"], 1.0)
        self.assertEqual(m["normalized_p5_grade_ge_2"], 1.0)
        self.assertEqual(m["normalized_p5_grade_ge_3"], 1.0)
        self.assertEqual(m["normalized_p5_grade_ge_4"], 1.0)

    def test_zero_positive_threshold_returns_null(self):
        qrels = {"a":3, "b":2, **{f"z{i}":0 for i in range(48)}}
        candidates = ["a","b"]+[f"z{i}" for i in range(48)]
        m = evaluate_ranking(["a","b"], candidates, qrels)
        self.assertIsNone(m["normalized_p5_grade_ge_4"])

    def test_all_zero_qrels_keep_zero_metrics_and_null_positive_denominators(self):
        qrels = {f"z{i:02d}": 0 for i in range(50)}
        ids = list(qrels)
        m = evaluate_ranking(ids[:10], ids, qrels)
        self.assertIsNone(m["ndcg@5"])
        self.assertIsNone(m["ndcg@10"])
        self.assertEqual(m["top1"], 0)
        self.assertEqual(m["mrr@10"], 0.0)
        self.assertEqual(m["hit@10"], 0)
        self.assertIsNone(m["recall@10"])
        self.assertIsNone(m["candidate_recall@50"])
        for threshold in (2, 3, 4):
            self.assertIsNone(m[f"normalized_p5_grade_ge_{threshold}"])

    def test_nonfinite_and_duplicate_ids_rejected(self):
        with self.assertRaises(ScoringError):
            stable_full_ranking(["a"], [float("nan")])
        with self.assertRaises(ScoringError):
            stable_full_ranking(["a","a"], [0.1,0.2])
        with self.assertRaises(ScoringError):
            evaluate_ranking(["a","a"], ["a"]+[f"x{i}" for i in range(49)], {"a":2})

    def test_final_ranking_and_candidates_must_be_judged(self):
        qrels = {"a":2, **{f"z{i}":0 for i in range(50)}}
        candidates = ["a"]+[f"z{i}" for i in range(49)]
        with self.assertRaises(ScoringError):
            evaluate_ranking(["unknown"], candidates, qrels)
        with self.assertRaises(ScoringError):
            evaluate_ranking(["a"], ["unknown"]+[f"z{i}" for i in range(49)], qrels)

    def test_canonical_hash_is_order_sensitive_and_deterministic(self):
        self.assertEqual(sha256_canonical({"b":2,"a":1}), sha256_canonical({"a":1,"b":2}))
        self.assertNotEqual(ordered_candidate_hash(["a","b"]), ordered_candidate_hash(["b","a"]))
        self.assertEqual(ranked_entry_hash([{"rank":1,"doc_id":"a"}]), ranked_entry_hash([{"rank":1,"doc_id":"a"}]))
        with self.assertRaises(ValueError):
            sha256_canonical({"bad": float("inf")})


if __name__ == "__main__":
    unittest.main()

