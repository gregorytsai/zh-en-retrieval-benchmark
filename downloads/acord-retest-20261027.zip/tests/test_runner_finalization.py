"""Post-guard-close evidence must pin final event logs exactly."""
import json
import tempfile
import unittest
from pathlib import Path

from src import runner


class RunnerFinalizationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def json_file(self, relative, value):
        path = self.root / relative
        runner.write_json_atomic(path, value)
        return path

    def jsonl_file(self, relative, *rows):
        path = self.root / relative
        for row in rows:
            runner.append_jsonl(path, row)
        return path

    def test_official_audit_hashes_post_close_traffic_and_server_logs(self):
        traffic = self.jsonl_file("traffic-events.jsonl", {"event": "poll"})
        servers = self.jsonl_file("server-events.jsonl", {"event": "server_loaded"})
        # These rows model the events appended while stopping owned servers and
        # closing the guard; finalization must hash the complete files.
        runner.append_jsonl(traffic, {"event": "guard_closed"})
        runner.append_jsonl(servers, {"event": "server_stopped"})
        self.json_file("validation-report.json", {"status": "passed", "counts": {"quality_rows": 228}})
        self.json_file("failed-attempts.jsonl", {})
        manifest = {"run_id": "r1", "mode": "official", "batch": "A01",
                    "embedder": "qwen-4b", "deadline_epoch": 9999999999,
                    "execution": {}}
        pending = {"status": "validated_pending_guard_close", "run_id": "r1",
                   "batch": "A01", "embedder": "qwen-4b",
                   "counts": {"quality_rows": 228}, "validation_status": "passed",
                   "preflight": {"status": "passed"}, "corpus_cache_sha256": "a" * 64,
                   "server_events_file": "server-events.jsonl",
                   "traffic_events_file": "traffic-events.jsonl"}

        complete = runner._finalize_official_after_guard_close(self.root, manifest, pending)

        self.assertEqual(complete["status"], "passed")
        self.assertEqual(complete["guard_events_sha256"], runner.file_sha(traffic))
        self.assertEqual(complete["server_events_sha256"], runner.file_sha(servers))
        self.assertEqual(complete["traffic_events"], 2)
        self.assertEqual(complete["server_events"], 2)
        self.assertEqual(runner.read_json(self.root / "run-manifest.json")["status"], "complete")

    def test_preflight_completion_pins_closed_event_logs_and_manifest(self):
        traffic = self.jsonl_file("traffic-events.jsonl", {"event": "guard_closed"})
        servers = self.jsonl_file("server-events.jsonl", {"event": "server_stopped"})
        request = self.jsonl_file("preflight-request-trace.jsonl", {"id": "smoke"})
        manifest = {"run_id": "preflight1", "mode": "preflight", "deadline_epoch": 9999999999,
                    "execution": {}}
        self.json_file("preflight-manifest.json", {"run_id": "preflight1"})
        self.json_file("run-manifest.json", manifest)
        pending = {"status": "validated_pending_guard_close", "protocol_id": "judged-top50-v1",
                   "run_id": "preflight1", "dataset_sha256": "b" * 64,
                   "models": [{"model_id": str(i), "status": "passed"} for i in range(10)],
                   "request_trace_sha256": runner.file_sha(request),
                   "server_events_file": "server-events.jsonl",
                   "traffic_events_file": "traffic-events.jsonl"}

        complete = runner._finalize_preflight_after_guard_close(self.root, manifest, pending)

        self.assertEqual(complete["status"], "passed")
        self.assertEqual(complete["guard_events_sha256"], runner.file_sha(traffic))
        self.assertEqual(complete["server_event_sha256"], runner.file_sha(servers))
        self.assertEqual(complete["request_trace_sha256"], runner.file_sha(request))
        self.assertEqual(complete["preflight_manifest_sha256"], runner.file_sha(self.root / "preflight-manifest.json"))
        self.assertEqual(runner.read_json(self.root / "run-manifest.json")["status"], "preflight_passed")


if __name__ == "__main__":
    unittest.main()
