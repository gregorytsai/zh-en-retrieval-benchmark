"""Boundary tests using fake transport; no model loading or inference."""
import unittest
from unittest.mock import patch

import numpy as np

from src import runtime as r


class RuntimeReviewTests(unittest.TestCase):
    def inputs(self):
        return {'query': {'id': 'q', 'text': 'synthetic query', 'grade': 4},
                'documents': [{'id': f'd{i}', 'text': f'synthetic clause {i}', 'grade': 4} for i in range(50)],
                'model_id': 'synthetic-reranker', 'model_sha': 'a' * 64,
                'run_id': 'synthetic-run', 'config_id': 'synthetic-config', 'attempt_id': 'synthetic-attempt'}

    def response(self):
        return {'results': [{'index': i, 'relevance_score': float(i)} for i in reversed(range(50))]}

    def test_transport_receives_only_raw_texts_and_order_is_restored(self):
        def transport(server, body, **kwargs):
            self.assertEqual(set(body), {'query', 'documents', 'top_n'})
            self.assertEqual(body['query'], 'synthetic query')
            self.assertEqual(body['documents'], [f'synthetic clause {i}' for i in range(50)])
            return self.response(), {'id': 'fake'}, 1.
        with patch.object(r, 'post_json_traced', side_effect=transport):
            scores, _, _ = r.traced_rerank(None, **self.inputs())
        self.assertEqual(scores, list(map(float, range(50))))

    def test_nonfinite_any_candidate_rejected(self):
        response = self.response(); response['results'][21]['relevance_score'] = float('nan')
        with patch.object(r, 'post_json_traced', return_value=(response, {}, 1.)):
            with self.assertRaises(r.RuntimeGateError):
                r.traced_rerank(None, **self.inputs())

    def test_duplicate_response_index_rejected(self):
        response = self.response(); response['results'][0]['index'] = 0
        with patch.object(r, 'post_json_traced', return_value=(response, {}, 1.)):
            with self.assertRaises(r.RuntimeGateError):
                r.traced_rerank(None, **self.inputs())

    def test_fractional_index_is_not_silently_coerced(self):
        response = self.response()
        for row in response['results']:
            row['index'] += .5
        with patch.object(r, 'post_json_traced', return_value=(response, {}, 1.)):
            with self.assertRaises(r.RuntimeGateError):
                r.traced_rerank(None, **self.inputs())

    def test_bad_candidate_count_never_calls_transport(self):
        args = self.inputs(); args['documents'].pop()
        with patch.object(r, 'post_json_traced', return_value=(self.response(), {}, 1.)) as post:
            with self.assertRaises(r.RuntimeGateError):
                r.traced_rerank(None, **args)
            post.assert_not_called()

    def test_embedding_zero_vector_rejected(self):
        response = {'data': [{'index': 0, 'embedding': [0., 0.]}]}
        with patch.object(r, 'post_json_traced', return_value=(response, {}, 1.)):
            with self.assertRaises(r.RuntimeGateError):
                r.traced_embedding(None, query={'id': 'q', 'text': 'synthetic'}, prefix='', dimension=2,
                    model_id='synthetic', model_sha='a' * 64, run_id='test', config_id='test', attempt_id='test')


if __name__ == '__main__':
    unittest.main()
