import unittest

from src import runner


class RunnerTimingTests(unittest.TestCase):
    def test_elapsed_ms_converts_monotonic_nanoseconds(self):
        self.assertEqual(runner._elapsed_ms(1_000_000, 3_500_000), 2.5)

    def test_elapsed_ms_rejects_reversed_interval(self):
        with self.assertRaises(runner.RunnerError):
            runner._elapsed_ms(20, 19)

    def test_elapsed_ms_requires_native_integer_endpoints(self):
        with self.assertRaises(runner.RunnerError):
            runner._elapsed_ms(True, 2)
        with self.assertRaises(runner.RunnerError):
            runner._elapsed_ms(1, 2.0)


if __name__ == "__main__":
    unittest.main()
