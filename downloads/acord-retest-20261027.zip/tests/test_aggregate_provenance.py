import copy
import json
import tempfile
import unittest
from pathlib import Path

from tests.test_independent_validate import fixture, dump, write_rows, v


def aggregate_fixture(root):
    scope = fixture(root)
    original = v.read(root / 'run-manifest.json')
    for name in ('src/scoring.py', 'src/runtime.py', 'src/owned_guard.py', 'src/runner.py'):
        p = root / name
        p.parent.mkdir(exist_ok=True)
        p.write_text('# Synthetic frozen source for provenance tests only.\n')
        original['frozen_files_sha256'][name] = v.file_hash(p)
    manifest = copy.deepcopy(original)
    manifest['run_id'] = 'synthetic-aggregate'
    manifest['source_runs'] = {}
    names = ('query-results.jsonl', 'timing-results.jsonl', 'request-trace.jsonl',
             'retrieval-attempts.jsonl', 'full-retrieval-rankings.jsonl')
    contents = {name: list(v.lines(root / name)) for name in names}
    for i, q in enumerate(('q0', 'q1')):
        run_id = f'synthetic-segment-{i}'
        directory = root / 'source-runs' / run_id
        directory.mkdir(parents=True)
        source_manifest = copy.deepcopy(original); source_manifest['run_id'] = run_id
        dump(directory / 'run-manifest.json', source_manifest)
        spec = {'manifest_path': str((directory / 'run-manifest.json').relative_to(root)),
                'manifest_sha256': v.file_hash(directory / 'run-manifest.json'), 'artifacts': {}}
        for name, rows in contents.items():
            subset = [r for r in rows if r['query_id'] == q]
            for r in subset:
                r['run_id'] = run_id
            write_rows(directory / name, subset)
            spec['artifacts'][name] = {'path': str((directory / name).relative_to(root)),
                                        'sha256': v.file_hash(directory / name)}
        manifest['source_runs'][run_id] = spec
    for name, rows in contents.items():
        write_rows(root / name, rows)
    dump(root / 'run-manifest.json', manifest)
    return scope


class AggregateProvenanceTests(unittest.TestCase):
    def test_two_source_runs_preserve_original_ids(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td); scope = aggregate_fixture(root)
            r = v.validate(root, scope)
            self.assertEqual(r['status'], 'passed')
            self.assertEqual(r['source_run_ids'], ['synthetic-segment-0', 'synthetic-segment-1'])

    def test_source_hash_changed_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td); scope = aggregate_fixture(root)
            p = root / 'source-runs/synthetic-segment-0/query-results.jsonl'
            p.write_text(p.read_text() + '\n')
            with self.assertRaises(v.Invalid) as e:
                v.validate(root, scope)
            self.assertEqual(e.exception.code, 'hash_mismatch')

    def test_rewritten_aggregate_row_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td); scope = aggregate_fixture(root)
            p = root / 'query-results.jsonl'; rows = list(v.lines(p))
            rows[0]['extra_silent_modification'] = True
            write_rows(p, rows)
            with self.assertRaises(v.Invalid) as e:
                v.validate(root, scope)
            self.assertIn('differs from original', str(e.exception))

    def test_cross_run_code_change_rejected_even_if_manifest_hash_updated(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td); scope = aggregate_fixture(root)
            p = root / 'source-runs/synthetic-segment-0/run-manifest.json'
            original = v.read(p); original['frozen_files_sha256']['src/scoring.py'] = '0' * 64
            dump(p, original)
            manifest = v.read(root / 'run-manifest.json')
            manifest['source_runs']['synthetic-segment-0']['manifest_sha256'] = v.file_hash(p)
            dump(root / 'run-manifest.json', manifest)
            with self.assertRaises(v.Invalid) as e:
                v.validate(root, scope)
            self.assertIn('frozen condition mismatch', str(e.exception))


if __name__ == '__main__':
    unittest.main()
