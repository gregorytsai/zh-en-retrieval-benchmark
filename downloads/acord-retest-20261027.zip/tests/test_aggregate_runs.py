import csv
import json
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from src import aggregate_runs as a


class AggregateHelperTests(unittest.TestCase):
    def _write_minimal_official_run(self, root: Path, *, validation_sha_override=None):
        run_id = 'acord-official-a01-test'
        embedder = dict(a.runner.BATCHES)['A01']
        (root / 'run-manifest.json').write_text(json.dumps({
            'run_id': run_id, 'mode': 'official', 'status': 'complete',
            'batch': 'A01', 'embedder': embedder,
        }))
        validation_report = {
            'run_id': run_id, 'status': 'passed',
            'counts': {'quality_rows': 228},
        }
        report_path = root / 'validation-report.json'
        report_path.write_text(json.dumps(validation_report))
        report_hash = a.file_sha(report_path)
        (root / 'batch-completion-audit.json').write_text(json.dumps({
            'run_id': run_id, 'batch': 'A01', 'status': 'passed',
            'validation_report_sha256': validation_sha_override or report_hash,
        }))
        for name in a.ARTIFACTS:
            (root / name).write_text('{}\n')

    def test_checks_real_completion_audit_and_validation_report_schema(self):
        with tempfile.TemporaryDirectory() as td:
            run = Path(td)
            self._write_minimal_official_run(run)
            with mock.patch.object(a.validate, 'validate', return_value={
                    'status': 'passed', 'counts': {'quality_rows': 228}}), \
                 mock.patch.object(a.audit_execution, 'audit', return_value={
                    'status': 'passed', 'accepted_guard_units': 228}):
                manifest, numeric, execution = a._check_one_run(run, tuple(embedder for _, embedder in a.runner.BATCHES))
            self.assertEqual(manifest['run_id'], 'acord-official-a01-test')
            self.assertEqual(numeric['counts']['quality_rows'], 228)
            self.assertEqual(execution['accepted_guard_units'], 228)

    def test_rejects_completion_report_hash_mismatch(self):
        with tempfile.TemporaryDirectory() as td:
            run = Path(td)
            self._write_minimal_official_run(run, validation_sha_override='0' * 64)
            with self.assertRaisesRegex(ValueError, 'batch completion audit failed'):
                a._check_one_run(run, tuple(embedder for _, embedder in a.runner.BATCHES))

    def test_rejects_validation_report_for_another_run(self):
        with tempfile.TemporaryDirectory() as td:
            run = Path(td)
            self._write_minimal_official_run(run)
            report_path = run / 'validation-report.json'
            report = json.loads(report_path.read_text())
            report['run_id'] = 'other-run'
            report_path.write_text(json.dumps(report))
            completion = json.loads((run / 'batch-completion-audit.json').read_text())
            completion['validation_report_sha256'] = a.file_sha(report_path)
            (run / 'batch-completion-audit.json').write_text(json.dumps(completion))
            with self.assertRaisesRegex(ValueError, 'batch validation report failed'):
                a._check_one_run(run, tuple(embedder for _, embedder in a.runner.BATCHES))

    def test_summary_csv_preserves_binary64_roundtrip(self):
        value = 0.7027368757325543
        summary = [{
            'config_id': 'qwen-4b__standalone', 'embedder': 'qwen-4b', 'reranker': 'standalone',
            'n': 57, 'failed': 0,
            'metrics': {name: {'mean': value if name == 'ndcg@10' else None, 'valid_n': 57 if name == 'ndcg@10' else 0}
                        for name in a.METRIC_COLUMNS},
            'times_ms': {name: {'mean': value, 'p50': value, 'p95': value, 'n': 57}
                         for name in a.TIME_COLUMNS},
        }]
        with tempfile.TemporaryDirectory() as td:
            out = Path(td) / 'summary.csv'
            a._write_summary_csv(out, summary)
            with out.open(encoding='utf-8') as stream:
                row = next(csv.DictReader(stream))
            self.assertEqual(float(row['ndcg@10_mean']), value)
            self.assertEqual(row['ndcg@10_valid_n'], '57')
            self.assertEqual(float(row['total_p95_ms']), value)

    def test_failure_ledger_separates_clean_accepted_rows_from_history(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td); (root / 'RUN_STATUS.json').write_text(json.dumps({
                'history': {'historical_attempts': [
                    {'stage': 'preflight', 'result': 'failed_closed', 'failure': 'guard PermissionError'},
                    {'stage': 'official A01', 'run_id': 'old-run', 'result': 'failed_closed',
                     'accepted_rows': 0, 'failed_attempts': 1, 'failure': 'NameError after HTTP 200'}]}}))
            source = root / 'run'; source.mkdir()
            (source / 'run-manifest.json').write_text(json.dumps({'run_id': 'current'}))
            (source / 'query-results.jsonl').write_text('{"status":"ok"}\n')
            (source / 'failed-attempts.jsonl').write_text('{"reason":"interference"}\n')
            ledger = a._failure_ledger(root, [source], 228)
            self.assertEqual(ledger['official_accepted_rows'], 228)
            self.assertEqual(ledger['accepted_result_errors'], 0)
            self.assertEqual(ledger['historical_failure_count'], 2)
            self.assertEqual(ledger['source_run_failure_record_count'], 1)
            self.assertEqual(ledger['historical_setup_or_execution_failures'][0]['failure_category'],
                             'guard_process_inspection_blocked')

    def test_failure_ledger_separates_superseded_preflights_and_controller_or_tooling_failures(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / 'RUN_STATUS.json').write_text(json.dumps({'history': {'historical_attempts': [
                {'stage': 'preflight', 'result': 'passed_but_stale', 'stale_reason': 'source pin changed'},
                {'stage': 'official A01', 'result': 'failed_closed', 'failure': 'input missing'},
                {'stage': 'official A01', 'result': 'failed_closed', 'failure': 'NameError'},
                {'stage': 'preflight', 'result': 'failed_closed', 'failure': 'PermissionError'},
            ]}}))
            (root / 'POSTRUN_TOOLING_HISTORY.json').write_text(json.dumps({
                'controller_schema_failures': [{'batch': 'A01'}, {'batch': 'A02'}],
                'offline_tooling_failures': [{'tool': 'aggregate'}, {'tool': 'public'},
                                              {'tool': 'public-root'}],
            }))
            ledger = a._failure_ledger(root, [], 1596)
            self.assertEqual(ledger['official_accepted_rows'], 1596)
            self.assertEqual(ledger['historical_failure_count'], 3)
            self.assertEqual(ledger['historical_failed_query_attempt_count'], 0)
            self.assertEqual(ledger['superseded_preflight_count'], 1)
            self.assertEqual(ledger['controller_schema_failure_count'], 2)
            self.assertEqual(ledger['offline_tooling_failure_count'], 3)
            self.assertEqual(ledger['historical_failure_record_count_excluding_superseded_preflights'], 8)

    def test_source_packet_preserves_required_artifact_bytes_and_uses_relative_paths(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td); src = root / 'input'; src.mkdir()
            rid = 'official-run-1'
            (src / 'run-manifest.json').write_text(json.dumps({'run_id': rid}))
            for name in a.ORIGIN_ARTIFACTS:
                (src / name).write_bytes((name + '\n').encode())
            out = root / 'aggregate'; out.mkdir()
            target = out / 'source-runs' / rid
            spec = a._copy_source_run(src, target, {'run_id': rid}, out)
            self.assertFalse(Path(spec['manifest_path']).is_absolute())
            self.assertFalse(Path(spec['artifacts'][a.ORIGIN_ARTIFACTS[0]]['path']).is_absolute())
            self.assertEqual(spec['manifest_sha256'], a.file_sha(target / 'run-manifest.json'))
            for name in a.ORIGIN_ARTIFACTS:
                self.assertEqual((src / name).read_bytes(), (target / name).read_bytes())
                self.assertEqual(spec['artifacts'][name]['sha256'], a.file_sha(target / name))


if __name__ == '__main__':
    unittest.main()
