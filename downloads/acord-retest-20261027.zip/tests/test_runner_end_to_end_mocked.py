"""Exercise measured-unit commit/aggregate/independent validation without models."""
import json
import tempfile
import time
import uuid
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np

from src import independent_validate, runner, runtime
from tests.test_independent_validate import fixture


class FakeGuard:
    epoch = 0

    def wait_idle(self, check_deadline):
        check_deadline()

    def check_deadline(self):
        return None

    def begin_unit(self, _unit_id):
        return None

    def check(self):
        return None

    def finish_unit(self, _unit_id):
        return None

    def abort_unit(self, _unit_id, _reason):
        raise AssertionError("mocked successful inference must not abort")


class RunnerEndToEndMockedTests(unittest.TestCase):
    def test_measure_commit_rebuild_and_independent_validate_with_standalone_and_rerankers(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            _fixture_scope = fixture(root)
            for name in (
                "full-retrieval-rankings.jsonl", "candidates.jsonl", "reranker-scores.jsonl",
                "query-results.jsonl", "timing-results.jsonl", "request-trace.jsonl",
                "retrieval-attempts.jsonl", "summary.json", "committed.json",
            ):
                (root / name).unlink(missing_ok=True)

            data = runner.read_json(root / "frozen-data/acord.json")
            model_manifest = runner.read_json(root / "models-manifest.json")
            models = model_manifest["models"]
            models["qwen-4b"] = models.pop("synthetic")
            runner.write_json_atomic(root / "models-manifest.json", model_manifest)
            scope = independent_validate.Scope(
                embedders=("qwen-4b",), queries=2, corpus=56, judgments=106,
                judged_range=(52, 54), five_star_queries=1)
            manifest = runner.read_json(root / "run-manifest.json")
            manifest["corpus_cache_sha256"] = {"qwen-4b": "c" * 64}
            manifest["frozen_files_sha256"]["models-manifest.json"] = runner.file_sha(
                root / "models-manifest.json")
            manifest.update({
                "mode": "official", "batch": "A01", "embedder": "qwen-4b",
                "deadline_epoch": time.time() + 3600,
                "execution": {"inference_started": False, "formal_accepted_rows": 0,
                              "error_count": 0},
            })
            runner.write_json_atomic(root / "run-manifest.json", manifest)
            commits = {}
            guard = FakeGuard()
            dimension = 2
            cache_hash = "c" * 64
            corpus = data["corpus"]
            doc_by_id = {row["id"]: row for row in corpus}
            rankings = {}
            references = {}
            for query_id, judgments in data["qrels"].items():
                ranking = []
                for index, document in enumerate(corpus):
                    ranking.append({
                        "rank": index + 1, "doc_id": document["id"],
                        "similarity": float(len(corpus) - index),
                        "judged": document["id"] in judgments,
                    })
                rankings[query_id] = ranking
                references[query_id] = [row["doc_id"] for row in ranking if row["judged"]][:50]

            current_query = [None]

            def traced_embedding(_server, *, query, prefix, dimension, model_id, model_sha,
                                 run_id, config_id, attempt_id):
                vector = np.asarray([1.0, 0.0], dtype=np.float32)
                body = {"input": [prefix + query["text"]], "encoding_format": "float"}
                request_id = str(uuid.uuid4())
                start_ns = time.monotonic_ns()
                finish_ns = time.monotonic_ns()
                while finish_ns <= start_ns:
                    finish_ns = time.monotonic_ns()
                trace = {
                    "id": request_id, "run_id": run_id, "config_id": config_id,
                    "query_id": query["id"], "kind": "query_embedding", "model_id": model_id,
                    "model_sha256": model_sha, "input_sha256": runtime.sha256_canonical(body),
                    "input_ids_sha256": runtime.sha256_canonical([query["id"]]),
                    "payload_field_names": sorted(body), "grade_fields_absent": True,
                    "started_ns": start_ns, "finished_ns": finish_ns,
                    "status": "ok", "http_status": 200, "attempt_id": attempt_id,
                    "output_vector_sha256": runtime.canonical_float32_vector_hash(vector),
                }
                return vector, trace, (finish_ns - start_ns) / 1e6

            def traced_rerank(_server, *, query, documents, model_id, model_sha,
                              run_id, config_id, attempt_id):
                body = {"query": query["text"],
                        "documents": [doc["text"] for doc in documents], "top_n": 50}
                candidate_ids = [doc["id"] for doc in documents]
                request_id = str(uuid.uuid4())
                start_ns = time.monotonic_ns()
                finish_ns = time.monotonic_ns()
                while finish_ns <= start_ns:
                    finish_ns = time.monotonic_ns()
                trace = {
                    "id": request_id, "run_id": run_id, "config_id": config_id,
                    "query_id": query["id"], "kind": "rerank", "model_id": model_id,
                    "model_sha256": model_sha, "input_sha256": runtime.sha256_canonical(body),
                    "input_ids_sha256": runtime.sha256_canonical(candidate_ids),
                    "payload_field_names": sorted(body), "grade_fields_absent": True,
                    "started_ns": start_ns, "finished_ns": finish_ns,
                    "status": "ok", "http_status": 200, "attempt_id": attempt_id,
                    "output_vector_sha256": None,
                }
                return [float(i) for i in range(50)], trace, (finish_ns - start_ns) / 1e6

            embedding_model = {**models["qwen-4b"],
                               "registry": {"query_prefix": "synthetic-prefix ", "dimension": dimension}}
            with patch.object(runner, "rank_full",
                              side_effect=lambda _matrix, _vector, _corpus: rankings[current_query[0]]), \
                 patch.object(runtime, "traced_embedding", side_effect=traced_embedding), \
                 patch.object(runtime, "traced_rerank", side_effect=traced_rerank):
                for query in data["queries"]:
                    query_id = query["id"]
                    current_query[0] = query_id
                    for reranker in runner.RERANKERS:
                        config_id = f"qwen-4b__{reranker}"
                        rerank_model = None if reranker == "standalone" else {
                            "sha256": models[reranker]["sha256"], "registry": {},
                        }
                        bundle = runner.measure_query(
                            root, manifest, commits, embedder="qwen-4b", reranker=reranker,
                            query=query, corpus=corpus, doc_by_id=doc_by_id,
                            qrels=data["qrels"][query_id],
                            corpus_matrix=np.zeros((len(corpus), dimension), dtype=np.float32),
                            corpus_hash=cache_hash, embed_server=object(),
                            rerank_server=None if reranker == "standalone" else object(),
                            embed_model=embedding_model, rerank_model=rerank_model,
                            reference_candidates=references[query_id], guard=guard,
                            ensure_servers=lambda: (object(), None if reranker == "standalone" else object()),
                        )
                        runner.commit_query(root, manifest, commits, bundle)

            runner.rebuild_aggregates(root, commits)
            result = independent_validate.validate(root, scope)
            self.assertEqual(result["status"], "passed")
            self.assertEqual(result["counts"]["quality_rows"], 8)
            self.assertEqual(result["counts"]["candidate_lists"], 2)
            self.assertEqual(result["counts"]["pair_scores"], 300)
            self.assertEqual(len(runner.read_jsonl(root / "timing-results.jsonl")), 8)
            self.assertEqual(len(runner.read_jsonl(root / "request-trace.jsonl")), 14)


if __name__ == "__main__":
    unittest.main()
