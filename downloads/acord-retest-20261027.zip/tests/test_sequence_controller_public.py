import unittest

from src.sequence_controller_v2 import resume_start_index


class PublicSequenceControllerTests(unittest.TestCase):
    def test_resume_uses_contiguous_completed_prefix(self):
        order = [f'A{i:02d}' for i in range(1, 8)]
        self.assertEqual(resume_start_index(order, []), 0)
        self.assertEqual(resume_start_index(order, ['A01', 'A02']), 2)
        self.assertEqual(resume_start_index(order, order), len(order))

    def test_resume_rejects_noncontiguous_completion(self):
        with self.assertRaisesRegex(Exception, 'contiguous prefix'):
            resume_start_index(['A01', 'A02', 'A03'], ['A01', 'A03'])


if __name__ == '__main__':
    unittest.main()
