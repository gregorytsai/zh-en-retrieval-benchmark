"""Offline tests for preflight retry classification and per-attempt preparation."""
import tempfile
import unittest
from pathlib import Path

from src import owned_guard, runner, runtime


class FakeGuard:
    def __init__(self):
        self.check_count = 0
        self.units = []
        self.aborted = []

    def wait_idle(self, check_deadline):
        check_deadline()

    def check_deadline(self):
        return None

    def begin_unit(self, unit_id):
        self.units.append(unit_id)

    def finish_unit(self, unit_id):
        return None

    def abort_unit(self, unit_id, reason):
        self.aborted.append((unit_id, reason))

    def check(self):
        self.check_count += 1
        if self.check_count == 1:
            raise owned_guard.Interference("guard killed owned server during blocked request")


class RunnerPreflightRetryTests(unittest.TestCase):
    def test_interference_http_error_reprepares_server_and_retries_whole_unit(self):
        with tempfile.TemporaryDirectory() as td:
            guard = FakeGuard()
            prepared = []
            calls = []

            def prepare():
                prepared.append(f"server-generation-{len(prepared) + 1}")

            def operation():
                calls.append(len(calls) + 1)
                if len(calls) == 1:
                    raise runtime.HttpInferenceError("connection reset", {"id": "failed-http"})
                return "ok"

            result, attempts = runner.guarded_preflight_call(
                guard, "preflight/token-audit/qwen-4b", operation,
                prepare=prepare, event_path=Path(td) / "preflight-attempts.jsonl")

            self.assertEqual((result, attempts), ("ok", 2))
            self.assertEqual(len(prepared), 2)
            self.assertEqual(len(calls), 2)
            self.assertEqual(len(guard.aborted), 1)
            failures = runner.read_jsonl(Path(td) / "preflight-attempts.jsonl")
            self.assertEqual(failures[0]["status"], "interference_retry")
            self.assertEqual(failures[0]["request_trace"], {"id": "failed-http"})

    def test_unrelated_transport_error_is_not_reclassified_or_retried(self):
        with tempfile.TemporaryDirectory() as td:
            guard = FakeGuard()
            guard.check = lambda: None
            prepared = []
            calls = []

            def operation():
                calls.append(1)
                raise OSError("ordinary transport failure")

            with self.assertRaisesRegex(OSError, "ordinary transport failure"):
                runner.guarded_preflight_call(
                    guard, "preflight/smoke/qwen-4b", operation,
                    prepare=lambda: prepared.append(1),
                    event_path=Path(td) / "preflight-attempts.jsonl")

            self.assertEqual(len(prepared), 1)
            self.assertEqual(len(calls), 1)
            self.assertFalse((Path(td) / "preflight-attempts.jsonl").exists())


if __name__ == "__main__":
    unittest.main()
