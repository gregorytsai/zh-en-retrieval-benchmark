# ACORD data attribution

ACORD: Atticus Clause Retrieval Dataset, The Atticus Project and the ACORD authors.

Dataset: https://huggingface.co/datasets/theatticusproject/acord
Revision: `7ba1c6f2e0baaa32e78c78c2b02e9c57b102af4e`
Paper: https://aclanthology.org/2025.acl-long.1206/
License: Creative Commons Attribution 4.0 International (CC BY 4.0).
License terms: https://creativecommons.org/licenses/by/4.0/legalcode.en

The source dataset card declares `license: cc-by-4.0`. The preserved original card
is retained in the private source inventory; this attribution accompanies any
redistributed frozen ACORD texts, qrels, metadata and derived dataset material.
No endorsement by the original authors is implied.

Changes: this study retains the existing 57-query test subset, 3,931-clause
corpus and 61,988 explicit qrels. JSON packaging and source/study metadata are
separated; original query/document identifiers and text are retained. New rankings,
judged-membership candidate selection, predictions and evaluation outputs are
study-derived material. Grades remain 0–4 without subtracting one. No question or
clause text is rewritten for the experiment. See PROTOCOL.md for the changes in
evaluation and candidate construction.
